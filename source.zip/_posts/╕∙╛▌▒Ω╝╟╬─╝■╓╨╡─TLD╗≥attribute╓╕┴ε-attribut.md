---
title: 根据标记文件中的TLD或attribute指令
categories: 工具使用问题
abbrlink: a0cc1c5
date: 2020-12-16 08:57:43
tags:
---

　　在做房租管理系统期间，访问出现以下错误，原来不是代码问题，而是IDEA的问题<!--more-->

**According to TLD or attribute directive in tag file, attribute items does not accept any expressions**

**解释：根据标记文件中的tld或attribute指令，attribute items不接受任何表达式****

造成错误出现可能的原因：

web.xml文件中的版本号不兼容，有两种方法可解决。

## 第一种方法：

**修改导入jstl包的引入代码**
 将jsp文件中导入jstl包语句修改一下：
 修改前：
 <%@ taglib uri=“http://java.sun.com/jstl/core” prefix=“c”%>
 修改后：
 <%@ taglib uri=“http://java.sun.com/jstl/core_rt” prefix=“c”%>

## 第二种方法：

**修改版本号**

　　主要修改在web-app中，我的版本兼容3.1的，自己可以新建一个Dynamic Web  Project，同时自动生成一个web.xml文件，将两个web.xml文件替换为自己新生成的web.xml中的web-app。新建项目时不会生成web.xml的看下图（新建项目时，一步一步来，最后一步时，将红圈处打上勾，就会自动生成web.xml了，生成的web.xml在WebContent\WEB-INF目录下）。

**修改前：**

```xml
<web-app xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
 xmlns="http://java.sun.com/xml/ns/javaee" 
 xsi:schemaLocation="http://java.sun.com/xml/ns/javaee 
 http://java.sun.com/xml/ns/javaee/web-app_3_0.xsd" 
 id="WebApp_ID" version="3.0">
12345
```

**修改后：**

```xml
<web-app xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
 xmlns="http://xmlns.jcp.org/xml/ns/javaee"
  xsi:schemaLocation="http://xmlns.jcp.org/xml/ns/javaee
   http://xmlns.jcp.org/xml/ns/javaee/web-app_3_1.xsd"
    id="WebApp_ID" version="3.1">
```