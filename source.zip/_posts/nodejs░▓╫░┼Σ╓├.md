---
title: nodejs安装配置
tags:
  - Nodejs
  - 环境配置
categories: 环境配置
abbrlink: 647e4c1a
date: 2020-11-17 09:22:44
---

　　这个是在搭建博客的时候配置nodejs的过程，记录下来<!--more-->

# 下载

下载地址：https://nodejs.org/zh-cn/download/

<img src="https://s3.ax1x.com/2020/11/20/DMwC1x.jpg" alt="DMwC1x.jpg" style="zoom:50%;" />

# 安装

双击打开安装文件：

![](https://upload-images.jianshu.io/upload_images/2267589-f40b21a6ccbebefa.png?imageMogr2/auto-orient/strip%7CimageView2/2)

安装完成之后，在dos窗口中输入”node -v“查看版本号，这里我下载的12版本

![DMwPc6.jpg](https://s3.ax1x.com/2020/11/20/DMwPc6.jpg)

# 配置环境

1.在nodejs文件夹下创建两个文件夹：node_global和node_cache

| 新建文件夹  | 作用                   |
| ----------- | ---------------------- |
| node_global | 放安装过程中的缓存文件 |
| node_cache  | 最终的模块配置位置     |

![DMwijK.jpg](https://s3.ax1x.com/2020/11/20/DMwijK.jpg)

2.创建完两个文件夹之后，打开dos窗口，输入

```
npm config set prefix "D:\Drops\NODEJS\node_global"
npm config set cache "D:\Drops\NODEJS\node_cache"
```

**注意引号之间的路径填上自己的目录路径**

![DMwknO.jpg](https://s3.ax1x.com/2020/11/20/DMwknO.jpg)

3.在”系统变量下“新建”NODE_PATH“，填入D:\Drops\NODEJS\node_global\node_modules

<img src="https://s3.ax1x.com/2020/11/20/DMw991.jpg" alt="DMw991.jpg" style="zoom:67%;" />

4.将用户变量下的“PATH”修改为D:\Drops\NODEJS\node_global

<img src="https://s3.ax1x.com/2020/11/20/DMwShR.jpg" alt="DMwShR.jpg" style="zoom:67%;" />

<img src="https://s3.ax1x.com/2020/11/20/DMdzN9.jpg" alt="DMdzN9.jpg" style="zoom:67%;" />

![DMdxAJ.jpg](https://s3.ax1x.com/2020/11/20/DMdxAJ.jpg)

5.在dos窗口中输入node回车，再输入require('cluster')出现下图，既安装成功

![DMdj74.jpg](https://s3.ax1x.com/2020/11/20/DMdj74.jpg)

参考文章：https://www.jianshu.com/p/13f45e24b1de

