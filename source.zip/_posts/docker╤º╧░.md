---
title: docker学习
tags: docker
abbrlink: 7fb3659b
date: 2021-01-16 20:09:57
categories:
---

　　在学习十次方项目的时候，这个知识点并不了解，找个视频学习总结一下，不得不说，确实比虚拟机好用<!--more-->

# 第一章 Dokcer概述

## 1.1 虚拟化技术发展史

　　在虚拟化技术出现之前，我们要想搭建一台服务器，需要如下工作：

->购买硬件服务器

->在硬件服务器安装配置操作系统

->再操作系统之上配置应用环境

->部署并运行应用

这种方式的缺点就送货车

->部署应用非常慢

->需要花费的成本非常高

->应用迁移麻烦

## 1.2 虚拟化技术是什么

　　虚拟化是一种计算机资源管理技术，是佳能计算机的各种硬件资源，比如服务器、网络、CPU、内存等，予以抽象和转化后呈现出一套新的硬件资源环境，在这一套环境下我们可以安装我们的操作系统，部署我们的应用运行环境。他打破计算机硬件资源补课切割的障碍。

## 1.3 虚拟化技术的分类

**硬件级虚拟化**

　　是运行在硬件之上的虚拟化技术，他的核心技术是Hypervisor，Hypervisor是一种运行在基础物理服务器之上的软件层，可以虚拟化硬件资源，例如CPU、硬盘、内存等、然后我们可以通过在虚拟化出来的资源之上安装操作系统，也就是所谓的虚拟机，如VMWare。通过Hypervisor层我们可以创建不同的虚拟机，并且每个虚拟机都是独立分离的。

**操作系统级虚拟化**

　　是运行在操作系统之上的虚拟化技术，它模拟的是运行在一个操作系统上的多个不同进程，并将其封装在一个密闭的容器里面，该技术也叫容器化技术。Docker是目前最流行的一种实现。

## 1.4 虚拟化技术的优缺点

　　优点：一台物理服务器可以虚拟化出多个虚拟的服务器，让计算机资源可以充分利用。

　　缺点：1.每创建一个虚拟机，会占用很多资源，资源消耗太多，2.环境兼容性问题

## 1.5 容器技术的发展

　　基于硬件级虚拟化技术的不足，后续又发展出来另一种虚拟化技术，及操作系统级虚拟化技术。Docker基于LXC技术，是Linux平台上的容器化技术实现。

注：LXC是Linux Container的间写，它是一种内核虚拟化技术，可以提供轻量级的虚拟化，以便隔离进程和资源，它与宿主机使用同一个内核，性能损耗小，这种技术是Linux提供的，但是知道Docker出世，该技术才被发挥出来。

## 1.6 Docker的发展历史

　　2010年，有几个年轻人在旧金山成立了一家做PaaS平台的创业公司，起名叫dotCloud，并且还获得了创业孵化器Y ComBinator的支持，虽然sotCloud期间还获得过一些融资，但是随着IT剧透也杀入PaaS平台，dotCloud举步维艰。

　　2013年，dotCloud的创始人，28岁的Solomon Hykes做了一个艰难的决定：将dotCloud的核心引擎开源，这项核心引擎技术能够将Linux容器中的应用代码打包，轻松地在服务器之间迁移。然而，这个基于LXC技术的核心管理引擎开源后，让全世界的技术人员感到惊艳，让所有的It巨头们也为之一颤。

　　2013年docker开源开始，Docker技术风靡全球，于是将cotCloud公司决定将Docker作为主要业务进行发展，并把公司改名Docker Inc，全身心投入到Docker开发。

## 1.7 Docker是什么

　　1.Docker 是一个开源的应用容器引擎，它是基于Google公司推出的Go语言实现。

　　2.Docker技术让开发者可以打包他们的应用以及依赖包到一个可移植的容器中，打包好的容器可以发布到任何流行的Linux服务器上运行，这样就解决了开发环境和运维环境不一致的问题，所以容器技术解决了开发和运维之间的矛盾，让开发专注与开发，运维专注与运维。

　　3.Docker彻底释放了虚拟化的为例，极大的剑光低了计算机资源供应的成本，Docker重新定义了程序开发测试、交付和部署过程、Docker提出了“构建一次，到处运行的理念“。

　　４.Docker是一种轻量级的操作系统虚拟化解决方案，Docker的基础是Linux容器技术，在LXC的基础上Docker进行了近一步封装，让用户不需要关心容器的管理，使得操作更为简便，用户操作Docker容器就像操作一个快速轻量级的虚拟机一样简单。

　　**总结**：Docker是对软件和其依赖环境的标准化打包，应用之间相互个例，共享一个OS Kernerl（解决了资源浪费问题），可以运行在很多主流的操作系统上；注意：Docker本身不是容器，Docker只是管理容器的引擎。

## 1.8 容器和虚拟机的区别

　　容器是将代码和环境关系打包在一起的集合，而虚拟机是在物理层面上，分出来一个操作系统；多个容器可以运行在同一台物理服务器上，并共享一个操作系统的内核资源。多个虚拟机也可以运行在同一台机器上，但是每个虚拟机都需要一个完整的操作系统。

![6HhSTH.jpg](https://z3.ax1x.com/2021/03/24/6HhSTH.jpg)

| 特性       | 容器               | 虚拟机             |
| ---------- | ------------------ | ------------------ |
| 启动       | 秒级               | 分钟级             |
| 硬盘空间   | 一般为几十MB       | 一般为10GB         |
| 性能       | 接近原生           | 弱于原生           |
| 系统支持量 | 单机支持上千个容器 | 一般几十个         |
| 操作系统   | 与宿主机共享OS     | 宿主机OS上运行虚拟 |

# 第二章 Docker环境搭建



## 2.1 安装Docker

> 环境准备

1.需要一些linux基础

2.CentOS7

3.使用Xshell链接远程服务器

>系统环境

```shell
[root@bogon ~]# uname -r
3.10.0-957.el7.x86_64
```

```shell
[root@bogon ~]# cat /etc/os-release
NAME="CentOS Linux"
VERSION="7 (Core)"
ID="centos"
ID_LIKE="rhel fedora"
VERSION_ID="7"
PRETTY_NAME="CentOS Linux 7 (Core)"
ANSI_COLOR="0;31"
CPE_NAME="cpe:/o:centos:centos:7"
HOME_URL="https://www.centos.org/"
BUG_REPORT_URL="https://bugs.centos.org/"

CENTOS_MANTISBT_PROJECT="CentOS-7"
CENTOS_MANTISBT_PROJECT_VERSION="7"
REDHAT_SUPPORT_PRODUCT="centos"
REDHAT_SUPPORT_PRODUCT_VERSION="7"
```

> 安装

```shell
#判断是否安装了docker
yum list installed | grep docker
# 1.卸载旧的版本
yum remove docker \
docker-client \
docker-client-latest \
docker-common \
docker-latest \
docker-latest-logrotate \
docker-logrotate \
docker-engine

# 2.安装yum
yum install -y yum-utils

# 3.设置镜像仓库
#以下是默认的.默认是国外镜像源
#yum-config-manager \
#--add-repo \
#https://download.docker.com/linux/centos/docker-ce.repo 

#推荐使用阿里云
yum-config-manager \
--add-repo \
https://mirrors.aliyun.com/docker-ce/linux/centos/docker-ce.repo 

# 4.安装docker相关的		docker-ce 社区	ee 企业版
yum install docker-ce docker-ce-cli containerd.io

# 5.启动docker
systemctl start docker

# 6.使用docker version判断是否安装成功

# 7.hello-world
docker run hello-world
```

>卸载docker

```shell
# 1.卸载依赖
yum remove docker-ce docker-ce-cli containerd.io
# 2.删除资源
rm -rf /var/lib/docker
```

### 2.1.1 阿里云镜像加速

登录阿里云的容器镜像服务

```shell
sudo mkdir -p /etc/docker

sudo tee /etc/docker/daemon.json <<-'EOF'
{
  "registry-mirrors": ["https://lmdwf9h2.mirror.aliyuncs.com"]
}
EOF

sudo systemctl daemon-reload

sudo systemctl restart docker
```

### 2.1.2 底层原理

**Docker是怎么工作的**

　　Docker是一个Client-Server结构的系统，Docker的守护进程运行在主机上，通过Socket从客户端访问！新建一个容器的时候，docker不需要像虚拟机一样重新加载一个操作系统内核。

## 2.2 Docker的常用命令

### 2.2.1 帮助命令

```shell
docker -v
docker info
docker --help  #帮助命令
```

### 2.2.2 服务启动

```shell
systemctl start docker  #启动
systemctl stop docker   #停止
systemctl restart docker#重启

# 检查运行状态
systemctl status docker

ps -ef | grep docker #查看docker进程
```

启动已经创建的images

```shell
docker ps -a
docker start ID
```

**基本命令**

```shell
查看所有镜像 docker images

删除镜像(会提示先停止使用中的容器) docker rmi 镜像name/镜像id

查看所有容器 docker ps -a

查看容器运行日志 docker logs 容器名称/容器id

停止容器运行 docker stop 容器name/容器id

终止容器后运行 docker start 容器name/容器id

容器重启 docker restart 容器name/容器id

删除容器 docker rm 容器name/容器id

修改启动 docker update 容器id --restart=always
```

## 2.3 Docker使用体验

### 2.3.1 第一个Docker容器

1.将Docker服务启动

2.下载一个镜像，Docker 运行一个容器前需要本地存在有对应的镜像，如果镜像不存在本地，Docker会从镜像仓库下载

CentOS如何下载镜像？

* 从[docker hub](https://hub.docker.com/)官网上搜索所需要的镜像，然后使用命令下载

```shell
#下载镜像：
docker pull tomcat
#运行镜像：前台运行
doker run tomcat
#运行镜像：后台运行
docker run -d tomcat
#显示本地已有镜像：
docker images
```

* 可以使用`docker search ***`搜索

### 2.3.2 进入Docker容器

进入docker容器：`docker exec -it ID bash`其中-i表示交互式的，也就是保持标准输入流打开；t表示虚拟控制台，分配到一个控制台

进入容器：`docker exec -it ID bash`

其中i表示交互式的，也就是保持标准输入流打开；

t表示虚拟控制台，分配到一个虚拟控制台；

退出容器：`exit`

### 2.3.3  客户机访问容器

从客户机上访问容器，需要有端口映射，docker容器默认采用桥接模式月宿主机通信，需要将宿主机的ip端口映射到容器的ip端口上；

停止容器：`docker stop ID`

启动容器：`docker run -d -p 8080:8080 docker.io/tomcat`

# 第三章 Docker核心组件

## 3.1 Doker的底层运行原理

Docker使用客户端-服务器（C/S）架构模式，Docker服务启动->下载镜像->启动该镜像得到一个容器->容器里运行着我们想要的程序：

![6Hfz0e.jpg](https://z3.ax1x.com/2021/03/24/6Hfz0e.jpg)



## 3.2 Docker的核心要素

**镜像（images）：**

　　docker镜像，就好比一个模版，可以通过这个模版来创建容器服务，最终服务运行或项目运行在容器中。

**容器（Container）：**

　　docker利用容器技术，独立运行一个或者一个组应用，通过镜像来创建

　　启动、停止、删除、基本命令，容器可以简单理解为一个简易的Linux系统

**仓库（Registry）：**

　　仓库就是存放镜像的地方，仓库分为公有仓库和私有仓库

## 3.3 镜像

### 3.3.1 镜像的基本概念

Docker镜像就是一个只读的模板，可以用来创建Docker容器。

例如：一个镜像可以包含一个完整的centos操作系统环境，里面仅安装了mysql或者用户需要的其他应用程序。

Docker提供了一个非常简单的机制来创建镜像或者更新现有镜像，用户甚至可以直接从其他人那里下载一个已经做好的镜像来直接使用。

### 3.3.2 镜像的组成结构

镜像由许多层的文件系统叠加构成，最下面是一个引导文件系统bootfs，第二层是一个root文件系统rootfs，root文件系统通常是某种操作系统，比如centos，ubuntu，在root文件系统之上又有很多层文件系统，这些文件系统叠加在一起，构成docker中的镜像。

![image-20210420163406173](https://cdn.jsdelivr.net/gh/qnjy/images/data/1618907646-image-20210420163406173.png)

### 3.3.3 镜像的日常操作

1.下载镜像，比如下载redis镜像：`docker pull redis:latest`

redis是查询到的镜像名称，latest是镜像的标签tag

安装一个镜像有两种方式，一种是从官方镜像仓库下载，一种是自己通过dockerfile文件构建。

2.列出已经下载的镜像：`docker images`或者`docker images redis`

3.运行镜像：`docker run -d redis`其中-d表示在后台运行

然后通过 `ps -ef|grep redis`可以查到redis进程

4.查看容器状态：`docker ps`

通过`docker exec -it ID bash`进入redis容器

5.删除镜像`docker rmi ID`，rm是删除容器，rmi是删除镜像。

## 3.4 容器

### 3.4.1 容器的基本概念

容器是从镜像创建的运行实例。他可以被启动、停止、删除。每个容器都是相互隔离的、保证安全平台。可以把它看做一个简易版的Linux环境，包括root用户权限、进程空间、用户空间和网络空间和运行在其中的应用程序。

Docker利用容器来运行应用，镜像是只读的，容器再启动的时候创建一层可写层作为最上层。

![image-20210420163406173](https://cdn.jsdelivr.net/gh/qnjy/images/data/1618907646-image-20210420163406173.png)

### 3.4.2 容器的日常操作

启动容器有两种方式，一种是基于镜像新建一个容器并启动，另外一个是将在终止状态的容器重新启动。

通过镜像启动容器：`docker run -d redis`

查看运行中的容器：`docker ps`

查看所有的容器：`docker ps -a`

进入容器：`docker exec -it ID bash`

停止容器：`docker stop ID`

启动容器：`docker start ID`

获取容器更多信息：`docker inspect ID`

停用全部运行中的容器：`docker stop $(docker ps -q)`

删除全部容器：`docker rm $(docker ps -aq)`

## 3.5 仓库

### 3.5.1 仓库的基本概念

仓库是集中存放镜像文件的地方，有时候会把仓库和仓库注册服务器看做同一个事物，不作严格区分。实际上，仓库注册服务器上存放着许多仓库，每个仓库中又包含了多个镜像，每个镜像有不同的标签：

仓库分为公开仓库和私有仓库两种形式：

最大的公开仓库是[DockerHub](https://hub.docker.com)，存放了数量庞大的镜像给用户下载；

当用户创建了自己的镜像后就可以使用push命令将它上传到公有或者私有仓库，这样下次在另外一台机器上使用这个镜像的时候，只需要从仓库上pull下来就可以。

### 3.5.2 仓库的日常操作

用户通过`docker search`命令查找官方仓库中的镜像

# 第四章 Docker使用示例

## 4.1 Docker安装MySQL

1.下载MySQL镜像：

```shell
docker pull mysql
docker run -p 3306:3306 -e MYSQL_DATABASE=workdb -e MYSQL_ROOT_PASSWORD=root -d mysql
```

其中-e是指定环境变量

2.进入容器

```shell
docker exec -it d19117e55e68 bash
```

3.登陆MySQL

```shell
mysql -uroot -p
```

如果需要修改密码等操作

修改密码

```shell
alter user 'root'@'localhost' identified by '123456'
```

授权远程登录访问：

```shell
create user 'wkcto'@'%' identified with mysql_native_password by 'root';

grant all privileges on *.* to 'wkcto'@'%';
```

## 4.2 Docker安装Nginx

1.下载Nginx镜像：

```shell
docker pull nginx

docker run -p 80:80 -d nginx
```

2.进入容器：

```bash
docker exec -it 687e44a10f08 bash
```

3.浏览器访问Nginx：

```bash
http://192.168.200.133:80
```

4.Ngnix部署静态网站：

```bash
#将虚拟机下的文件传到容器下
docker cp /root/test.html 687e44a10f08:/usr/share/nginx/html
```

## 4.3 Docker安装Zookeeper

1.下载Zookeeper镜像：

```bash
docker pull zookeeper

docker run  -p 2181:2181 -d zookeeper
```

2.进入容器：

```bash
docker exec -it 3e8bf7392b4e base
```

## 4.4 Docker下安装Redis

1.下载redis镜像

```bash
docker pull redis
```

2.redis.conf文件

创建本机的挂载目录

```bash
mkdir -p /usr/docker/redis/data
```

到官网下载redis.conf文件并把它放在`/usr/docker/redis`下

然后修改redis.conf

- bind 127.0.0.1 # 注释掉这部分，否则只能本地访问
- protected-mode no # 不开启保护模式，否则只能本地访问
- appendonly yes # 使redis持久化

3.启动容器

```bash
docker run -di -p 6379:6379 --name tenqsuare_redis -v /usr/docker/redis/redis.conf:/etc/redis/redis.conf  -v /usr/docker/redis/data:/data  redis
```

> -p 6379:6379：端口映射
>
>  --name tenqsuare_redis ： 命名为tensquare_redis
>
> -v /usr/docker/redis/redis.conf:/etc/redis/redis.conf  ：将docker容器中的redis.conf挂载到刚才修改的redis.conf
>
> -v /usr/docker/redis/data:/data ：将docker容器中的data挂载到本地
>
> -d：后台启动

4.启动连接Redis

<img src="https://cdn.jsdelivr.net/gh/qnjy/images/data/1621927427-image-20210525152347616.png" alt="image-20210525152347616" style="zoom: 50%;" />

# 第五章 Docker自定义镜像

## 5.1 认识Dockerfile文件

Dockerfile是用于构建Dockerj镜像，Dockerfile文件是由一行行命令语句组成，基于这些命令就可以构建一个镜像。

```dockerfile
from XXX/jdk:8
maintainer docker_user
env java_home /usr/local/java
add apache-tomcat-8.0.32.tar.gz /usr/local/
run mv apache-tomcat-8.0.32 tomcat8
expose 8080
run chmod u+x /usr/local/tomcat8/bin/*.sh
cmd /usr/local/tomcat8/bin/catalina.sh start
```

## 5.2 Dockerfile的基本结构

一般的，Dockerfile分为四个部分

基础镜像信息；

维护者信息；

镜像操作指令；

容器启动时的指令；

## 5.3 Dockerfile指令

**FROM**

格式为`from <image>`或者`from <image>:<tag>`

Dockerfile文件的第一条指令必须为from指令。并且，如果在同一个Dockerfile中创建多个镜像时，可以使用多个from指令；

**MAINTAINER**

格式为`maintainer <name>`，指定维护者信息；

**ENV**

格式为`env <key><value>`，指定一个环境变量，会被后续run指令使用，并在容器运行时保持；

**ADD**

格式为`add <src><dest>`；

复制指定的`<src>`到容器中的`<dest>`

**EXPOSE**

格式为`expose <port>[<port>...]`

告诉Docker服务端容器暴露的端口号，供互联系统使用，在启动容器时需要通过-p映射端口，Docker主机会自动分配一个端口转发到指定的端口；

**RUN**

格式为`run <command>`

指定启动容器是执行的命令，每个Dockerfile只能有一条cmd命令。若果指定了多条命令，只有最后一条会被执行。

如果用户启动容器的时候指定了运行的命令，则会覆盖掉cmd指定的命令。

## 5.4 Dockerfile自定义镜像

### 5.4.1 自定义JDK镜像

```dockerfile
from centos:latest
maintainer qnjy
add jdk-8u121-lunux-x64.tar.gz/usr/local
env JAVA_HOME /usr/local/jdk1.8.0_121
env CLASSPATH $JAVA_HOME/lib/dt.jar:$JAVA_HOME/lib/tools.jar
env PATH $PATH:$JAVA_HOME/bin
cmd java-version
```

构建镜像：`docker build -t qnjy_jdk1.8.0_121`

运行容器：`docker run -d ac1928798dfr`

### 5.4.2 自定义Redis镜像

```dockerfile
from centos:centos6
maintainer qnjy
run yum install epel-release -y && yum install redis -y && yum install net-tools -y
expose 6379
cmd /usr/bin/redis-server
```

构建镜像：`docker build -t qnjy-redis`

运行镜像：`docker run -d -p 6379:6379 390583cf0531`

## 5.5 镜像发布到仓库

### 5.5.1 阿里云容器镜像仓库

网址：https://dev.aliyun.com

### 5.5.2 发布镜像到阿里云仓库
