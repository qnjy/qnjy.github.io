---
title: JPA框架学习
abbrlink: 9af0416b
date: 2021-03-08 20:47:18
tags:
categories:
---

# 1 orm思想

　　就是相当于操作实体类就是操作数据库表，需要先建立两个映射关系（实体类和表、实体类中的属性和表中字段），实现了orm思想的框架：mybatis、hibernate<!--more-->

# 2 Hibernate框架介绍

　　Hibernate是一个开放源代码的对象关系映射框架，它对JDBC进行了非常轻量级的对象封装，他将POJO与数据库表建立映射关系，是一个全自动的ORM框架

# 3 JPA规范

　　内部是由接口和抽象类组成

# 4 代码实战

## 4.1 maven依赖

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-data-jpa</artifactId>
</dependency>
```

## 4.2 XML配置

```xml
<?xml version="1.0" encoding="UTF-8"?>
<persistence xmlns="http://java.sun.com/xml/ns/persistence" version="2.0">

    <!--需要配置persistence-unit节点
        持久化单元
            name：持久化单元名称
            transaction-type：事务管理方式-->
    <persistence-unit name="myJpa" transaction-type="RESOURCE_LOCAL">

        <!--JPA的实现方式-->
        <provider>org.hibernate.jpa.HibernatePersistenceProvider</provider>

        <!--可选配置：配置JPA实现方式的配置信息-->
        <properties>
            <!--数据库信息
                    1.用户名       javax.persistence.jdbc.user
                    2.密码         javax.persistence.jdbc.password
                    3.驱动         javax.persistence.jdbc.driver
                    4.数据库地址   javax.persistence.jdbc.url -->
            <property name="javax.persistence.jdbc.user" value="root"/>
            <property name="javax.persistence.jdbc.password" value="root"/>
            <property name="javax.persistence.jdbc.driver" value="com.mysql.cj.jdbc.Driver"/>
            <property name="javax.persistence.jdbc.url" value="jdbc:mysql:///jpa"/>

            <!--配置JPA实现方（hibernate）的配置信息
                    显示sql   false|true
                    自动创建数据库表    hibernate.hbm2ddl.auto
                        create      此程序运行时创建数据库表（如果有表，删除表在创建）
                        update      程序运行时创建表（有表就不会创建）
                        none        不创建表-->
            <property name="hibernate.show_sql" value="true"/>
            <property name="hibernate.hbm2ddl.auto" value="create"/>

        </properties>

    </persistence-unit>

</persistence>
```

# 五 JPA注解

| 注解            | 解释                                                         |
| --------------- | ------------------------------------------------------------ |
| @Entity         | 声明类为实体或表                                             |
| @Table          | 声明表名                                                     |
| @Basic          | 指定非约束明确的各个字段                                     |
| @Embedded       |                                                              |
| @GeneratedValue | 配置主键生成策略（IDENTITY自增，SEQUENCE序列，TABLE通过数据库表的形式完成自增，AUTO自动选择） |
| @Column         | 配置属性和字段的映射关系                                     |
|                 |                                                              |
|                 |                                                              |
|                 |                                                              |

