---
title: FastDFS的安装
abbrlink: e3e169b4
date: 2021-12-08 13:51:30
tags:
categories:
---

# 1.Linux下使用FastDFS

## 1.1 单节点FastDFS

### 1.1.1 安装gcc

GCC用来对C语言代码进行编译运行，使用以下命令：

`yum -y install gcc`

后面会用到解压命令，也把unzip安装一下

`yum install -y unzip zip`

### 1.1.2 安装libevent<!--more-->

`yumm -y install libevent`

### 1.1.3 安装libfastcommon-master

```shell
解压刚刚上传的libfastcommonmaster
unzip libfastcommon-master.zip

进入解压完成的目录
cd libfastcommon-master

编译并且安装：
./make.sh
./make.sh install
```

### 1.1.4 安装fastdfs

```shell
tar -zxvf FastDFS_v5.08.tar.gz

cd FastDFS

./make.sh

./make.sh install
```

如果安装成功，会看到/etc/init.d/下看到提供的脚本文件:

```shell
ll /etc/init.d/ | grep fdfs
```

![image-20211208141057992](https://cdn.jsdelivr.net/gh/qnjy/giteeimg/img/20211208-image-20211208141057992.png)

* fdfs_trackerd是tracker启动脚本
* fdfs_storaged是storage启动脚本



能够在/etc/fdfs/目录下看到默认的配置文件模板：

```
ll /etc/fdfs/
```

### 1.1.5 配置并启动tracker服务

FastDFS的tracker和storage在刚刚的安装过程中，都已经被安装了，因此我们安装这两种角色的方式是一样的。不同的是，两种需要不同的配置文件。

我们要启动tracker，就修改刚刚看到的tarcker.conf，并且启动fdfs_trackerd脚本即可。

1）首先将模板文件复制

```cp
cp /etc/fdfs/tracker.conf.sample /etc/fdfs/tracker.conf
```

2）修改复制后的配置文件：

```
vim /etc/fdfs/tracker.conf
```

#修改的内容如下：

```shell
base_path=/leyou/tracker
```

3）新建目录

```
mkdir -p /leyou/tracker
```

注意关闭防火墙

4）启动和停止

启动tracker服务器：`/etc/init.d/fdfs_trackerd start`

停止tracker服务器：`/etc/init.d//fdfs_trackerd stop`

不过安装过程中，fdfs已经被设置为系统服务，我们可以采用熟悉的服务启动

```shell
service fdfs_trackerd start #地洞fdfs——trackerd服务，停止用stop
```



检查FastDFS Tracker Server是否启动成功

```shell
ps -ef | grep fdfs_trackerd
```



设置tracker服务开机启动

```
chkconfig fdfs_trackerd on
```

### 1.1.6 配置并启动storage服务

1）首先将模板文件复制

```
cp /etc/fdfs/storage.conf.sample /etc/fdfs/storage.conf
```

2）修改复制后的配置文件

```
vi /etc/fdfs/storage.conf
```

 修改的内容如下：

```shell
base_path=/leyou/storage              #数据和日志文件存储根目录

store_path0=/leyou/storage			  #第一个存储目录

tracker_server=192.168.200.133:22122
```

3）新建目录

```
mkdir -p /leyou/storage
```

4）启动和停止

启动storage服务：`/etc/init.d/fdfs_storaged start`

停止storage服务：`etc/init.d/fdfs_storaged stop`



设置开机启动

```
chkconfig fdfs_storaged on
```



ps -ef | grep fdfs

![image-20211208142953065](https://cdn.jsdelivr.net/gh/qnjy/giteeimg/img/20211208-image-20211208142953065.png)
