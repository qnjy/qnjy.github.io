---
title: SSM实训-第四天
abbrlink: 8a355baa
date: 2022-06-22 10:24:24
tags:
categories:
---

# 1 实现已缴费模块

<!--more-->

![image-20220622102616836](C:\Users\86138\AppData\Roaming\Typora\typora-user-images\image-20220622102616836.png)

分步实现

1 在payrecord和fee表中查出缴费单号相同的所有数据：

```mysql
select * from payrecord,fee where payrecord.feecode=fee.feecode
```

但是这样查询到的数据只是匹配的记录，只有十条

2 使用外连接解决

```mysql
select * from fee left join payrecord on payrecord.feecode=fee.feecode
```

3 分组求和

```mysql
SELECT
	fee.*,
	sum( payamount ) AS payedsum 
FROM
	fee
	LEFT JOIN payrecord ON payrecord.feecode = fee.feecode 
GROUP BY
	fee.feeid
```

# group by 知识点

<font color="#ff8600">**group by的使用</font>**

**<font color="#ff8600">如果group by 主键字段，那么select后可以查询所有的字段</font>**

**<font color="#ff8600">如果group by的不是主键字段，那么select后的字段和group by的字段要统一。</font>**

![image-20220622103328379](C:\Users\86138\AppData\Roaming\Typora\typora-user-images\image-20220622103328379.png)

# 2 存储查询数据

为了sm数据的存储，在实体类Fee中添加payedsum字段

![image-20220622103513875](C:\Users\86138\AppData\Roaming\Typora\typora-user-images\image-20220622103513875.png)

mapper中的sql

![image-20220622103529239](C:\Users\86138\AppData\Roaming\Typora\typora-user-images\image-20220622103529239.png)

# 3 页面展示

![image-20220622103721480](https://qnjy.coding.net/p/githubimg/d/githubimg/git/raw/master/img/20220622-image-20220622103721480.png)

这里有一种新的思路(**太难未实现**)：

List\<Fee> + Map<String,Double>【键：feecode，值：已缴费金额】

费用对象Fee中有一个feecode值

map中可以根据feecode（键）找到对应的已缴费金额

------

# 4 修改缴费状态

在新增缴费记录时，动态的判断该feecode的缴费是否已经完成，如果完成了，那修改fee中的记录的paystatus为2 ；如果没完成，确认fee中的记录的paystatus为1

PayRecordController：

![image-20220622105549449](C:\Users\86138\AppData\Roaming\Typora\typora-user-images\image-20220622105549449.png)

FeeMapper.xml

![image-20220622113231278](https://qnjy.coding.net/p/githubimg/d/githubimg/git/raw/master/img/20220622-image-20220622113231278.png)

# 5 业主动态模块编写

1 数据表设计

```mysql
CREATE TABLE `moving` (
  `movingid` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键自增',
  `movingcreatedtime` varchar(255) DEFAULT NULL COMMENT '发布时间',
  `movingcontent` text COMMENT '动态内容',
  `checkstatus` varchar(255) DEFAULT '0' COMMENT '审核状态 0未审核 1通过 2失败',
  `checkadminid` int(11) DEFAULT NULL COMMENT '审核人',
  `userid` int(11) DEFAULT NULL COMMENT '业主编号',
  `toplevel` int(11) DEFAULT NULL COMMENT '加急置顶，0 1加急',
  PRIMARY KEY (`movingid`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4;
```

**2 插入初始化数据**

**3 功能设计**

列表展示：

编号、内容、发布时间、发布者姓名、发布者手机号、审核状态、审核人 操作

多条件查询：

手机号、审核状态、时间（开始~结束）

新增：【不需要】

删除：【保留】

查看详情 ： ---》  审核通过/失败
