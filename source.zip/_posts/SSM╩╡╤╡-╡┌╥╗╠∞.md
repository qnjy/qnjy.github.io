---
title: SSM实训-第一天
abbrlink: 40100d45
date: 2022-06-22 09:20:38
tags:
categories:
---

一年一度的实训又开始了<!--more-->

# 任务

任务一：

实现楼房管理模块

![image-20220622092308962](https://qnjy.coding.net/p/githubimg/d/githubimg/git/raw/master/img/20220622-image-20220622092308962.png)

1 dao已完成（model层）

2 页面：在已有的静态页面html（view层）上调通

​	view：html+ajax+js 或jsp

3 servlet或SpringMVC（Controller层）

JDBC--->SQLSessionUtil

任务二：

mybatis动态sql

多条件查询：根据用户传入的查询条件，在xml配置sql时，利用for、if、where等标签查出所需要数据。

![image-20220622092819942](https://qnjy.coding.net/p/githubimg/d/githubimg/git/raw/master/img/20220622-image-20220622092819942.png)

重点：要将分页和条件查询结合起来

![image-20220622092830607](https://qnjy.coding.net/p/githubimg/d/githubimg/git/raw/master/img/20220622-image-20220622092830607.png)

目前完成了较为完成的楼房信息管理：

​	列表功能、分页功能、查询功能、删除功能、新增功能

​	【待完成：批量、编辑--依赖js】

需要模仿楼房管理完成业主管理、维修员管理、收费项目管理

# 1 设计表的结构

1 user表

```mysql
CREATE TABLE `charge` (
  `chargeid` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键自增',
  `chargename` varchar(255) DEFAULT NULL COMMENT '收费项目名字',
  `createdtime` varchar(255) DEFAULT NULL COMMENT '创建时间',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`chargeid`)
) ENGINE=InnoDB AUTO_INCREMENT=1001 DEFAULT CHARSET=utf8mb4;
```

2 staff表

```mysql
CREATE TABLE `staff` (
  `staffid` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键自增',
  `staffname` varchar(255) DEFAULT NULL COMMENT '姓名',
  `phone` varchar(255) DEFAULT NULL COMMENT '手机号',
  `sex` varchar(255) DEFAULT NULL COMMENT '性别',
  `createdtime` varchar(255) DEFAULT NULL COMMENT '创建时间',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`staffid`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4;
```

3 charge表

```mysql
CREATE TABLE `charge` (
  `chargeid` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键自增',
  `chargename` varchar(255) DEFAULT NULL COMMENT '收费项目名字',
  `createdtime` varchar(255) DEFAULT NULL COMMENT '创建时间',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`chargeid`)
) ENGINE=InnoDB AUTO_INCREMENT=1001 DEFAULT CHARSET=utf8mb4;
```

# 2 填充数据

navicat premium16可以自行生成数据，填充50条数据即可

# 3 页面展示要求

**业主管理**

id、用户名、手机号、roomname（9-1-1052）、创建时间

多条件查询：

​	手机号、楼栋、单元、房间号

**维修员管理**

id、姓名、手机号、性别、创建时间

多条件查询：

​	姓名模糊、手机号

**收费项目**

id、收费名称、创建时间

多条件查询

​	开始时间、结束时间

# 4 功能要求

列表功能、分页功能、查询功能、删除功能、新增功能
