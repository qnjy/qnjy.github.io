---
title: Java集合继承结构
tags:
  - Java
categories: Java
abbrlink: cb9bdb06
date: 2020-12-13 15:15:19
---

　　集合这部分只是很杂乱，这个是搜集的一些资料，很清楚的梳理了集合知识和各个集合类型的特点<!--more-->

![reBQmt.png](https://s3.ax1x.com/2020/12/13/reBQmt.png)

![reBKOI.png](https://s3.ax1x.com/2020/12/13/reBKOI.png)