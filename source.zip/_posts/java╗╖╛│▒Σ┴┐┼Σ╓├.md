---
title: java环境变量配置
tags:
  - Java
  - 环境配置
categories: 环境配置
abbrlink: a1cef01a
date: 2020-11-11 14:24:09
---

　　网上有很多java的配置，但是总结在这里，以后就不用再去搜索了<!--more-->

# 1.下载安装jdk

https://www.oracle.com/java/technologies/javase-downloads.html

# 2.配置环境变量

1.在电脑桌面 右键点击 “此电脑”的“属性”选项<!--more-->

![DityHH.jpg](https://s3.ax1x.com/2020/11/15/DityHH.jpg)

2.选择“高级系统设置”

<img src="https://s3.ax1x.com/2020/11/15/DitruD.jpg" alt="DitruD.jpg" style="zoom:67%;" />

3.点击下面的“环境变量”

![DitBjO.jpg](https://s3.ax1x.com/2020/11/15/DitBjO.jpg)

4.点击“系统变量”下面的”新建“选项

![Dit24I.jpg](https://s3.ax1x.com/2020/11/15/Dit24I.jpg)

5.在”变量名“处填上”Java_Home“，在“变量值”文本框输入JDK的安装路径

![DitgUA.jpg](https://s3.ax1x.com/2020/11/15/DitgUA.jpg)

6.在上一级“系统变量”中查看PATH变量，在“变量值”文本框的起始位置添加“%JAVA_HOME%\bin;%JAVA_HOME%\jre\bin;”

![DitWCt.jpg](https://s3.ax1x.com/2020/11/15/DitWCt.jpg)

7.在上一级“系统变量”中查看CLASSPATH 变量，若无则新建变量CLASSPATH，在“变量值”文本框添加“.;%JAVA_HOME%\lib\dt.jar;%JAVA_HOME%\lib\tools.jar;”

![DitcEd.jpg](https://s3.ax1x.com/2020/11/15/DitcEd.jpg)

8.最后再dos命令窗口中输入javac

![DitsDe.jpg](https://s3.ax1x.com/2020/11/15/DitsDe.jpg)