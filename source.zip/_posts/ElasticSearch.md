---
title: ElasticSearch
abbrlink: d48132d3
date: 2021-05-10 10:26:04
tags:
categories:
---

重新复习一下elasticsearch的内容。

# 1 ElasticSearch简介

## 1.1 什么是ElasticSearch

　　The Elastic Stack, 包括 Elasticsearch、Kibana、Beats 和Logstash（也称为 ELK Stack）。 能够安全可靠地获取任何来源、任何格式的数据，然后实时地对数据进行搜索、分析和可视 化。Elaticsearch，简称为 ES，ES 是一个开源的高扩展的分布式全文搜索引擎，是整个 Elastic Stack 技术栈的核心。它可以近乎实时的存储、检索数据；本身扩展性很好，可以扩展到上 百台服务器，处理PB 级别的数据。
　　ElasticSearch是一个基于Lucene的、RESTful风格的搜索和数据分析引擎。是当前流行的企业级搜索引擎。<!--more-->

## 1.2  Elasticsearch特点

（1）可以作为一个大型分布式集群（数百台服务器）技术，处理PB级数据，服务大公司；也可以运行在单机上

（2）将全文检索、数据分析以及分布式技术，合并在了一起，才形成了独一无二的ES；

（3）开箱即用的，部署简单

（4）全文检索，同义词处理，相关度排名，复杂数据分析，海量数据的近实时处理

## 1.3 Elasticsearch应用案例

* GitHub：2013年初，GitHub将solr缓存改为es，以便用户搜索20TB的数据
* 维基百科：启动以es为基础的核心搜索架构SoundCloud
* 百度：以es作为数据分析引擎，20多个业务线采集服务器上的各类数据以及用户自定义数据，通过对各种数据进行多维分析，辅助定位异常。其单集群最大100台机器，200个es节点，每天导入超过30TB的数据
* 新浪、阿里、携程、苏宁等各大公司的站内搜索、数据分析中使用

## 1.4 Elasticsearch体系结构

　　Elasticsearch 是面向文档型数据库，一条数据在这里就是一个文档。 我们将 Elasticsearch 里存储文档数据和关系型数据库MySQL 存储数据的概念进行一个类比

![image-20210511195817096](https://cdn.jsdelivr.net/gh/qnjy/images/data/1620734297-image-20210511195817096.png)

# 2 安装Elasticsearch

## docker下无法使用vi命令解决方法

## 2.1 Windows下安装

　　参考

## 2.2 Docker环境下安装ElasticSearch

### docker下无法使用vi命令解决方法

　　我们会碰到修改容器配置文件的，但是在容器下vi命令不可用，所以进入每个容器后安装vim命令就可以修改配置文件，进入容器内部，执行以下命令 

```
apt-get update
apt-get install vim
```

### 2.2.1 es容器创建

**1、下载镜像**

```
docker pull elasticsearch:7.6.2
```

**2、创建容器**

```
docker run -d --name myes -e "discovery.type=single-node" -p 9200:9200 -p 9300:9300 elasticsearch:7.6.2
```

如果虚拟机内存过小建议执行以下，就不需要在进行系统调优：

```
docker run --name myes -d -e ES_JAVA_OPTS="-Xms512m -Xmx512m" -e "discovery.type=single-node" -p 9200:9200 -p 9300:9300  elasticsearch:7.6.2
```

**3、浏览器输入地址：**

192.168.200.133:9200，即可看到以下信息

```json
{
    "name": "Q6z1-G-",
    "cluster_name": "elasticsearch",
    "cluster_uuid": "kSGG2E7QQCm3SXyHLpQy1g",
    "version": {
        "number": "5.6.12",
        "build_hash": "cfe3d9f",
        "build_date": "2018-09-10T20:12:43.732Z",
        "build_snapshot": false,
        "lucene_version": "6.6.1"
    },
    "tagline": "You Know, for Search"
}
```

**4、重新启动**

```
docker restart myes
```

　　重启之后发现重启失败？这与我们刚才修改的配置有关，因为elasticsearch在启动的时候会进行一些检查，比如最多打开的文件的个数以及虚拟内存区域数量等，如果放开了此配置，以为这需要打开更多的文件以及虚拟内存，所以我们需要调优。

**5、系统调优**

我们一共需要修改两处

修改/etc/security/limits.conf，追加内容

```
* soft nofile 65536
* hard nofile 65536
```

nofile是单个进程允许打开的最大文件个数

soft nofile是软限制，hard nofile是硬限制

修改/etc/sysctl.conf，追加内容

```
vm.max_map_count=655360
```

限制一个进程可以拥有的VMA（虚拟内存区域）的数量

执行下面命令，修改内核参数马上生效：

```
sysctl -p
```

之后重启虚拟机和容器

### 2.2.2 IK分词器安装

**1、首先确定ES版本，**然后到github上下载对应版本的IK分词器，https://github.com/medcl/elasticsearch-analysis-ik

![image-20210510153715459](https://cdn.jsdelivr.net/gh/qnjy/images/data/1620632235-image-20210510153715459.png)

**2、通过docker命令将zip包复制到ES容器指定位置**

```
docker cp /tmp/elasticsearch-analysis-ik-7.6.2.zip myes:/usr/share/elasticsearch/plugins
```

**3、进入docker容器对其进行解压操作，<font color="ff000">注意解压完将zip包删除，ik文件夹下没有子目录</font>**

```
# 进入容器
docker exec -it myes /bin/bash
#进入目录
cd plugins
#创建目录
mkdir ik
#移动压缩包到ik文件夹
mv elasticsearch-analysis-ik-7.6.2.zip ik
# 解压
unzip elasticsearch-analysis-ik-7.6.2.zip
# 删除压缩包
rm -rf elasticsearch-analysis-ik-7.6.2.zip
```

**4、重启docker容器**

```
docker restart myes
```

### 2.2.3 HEAD插件

**1、跨域配置**

进入容器

```
docker exec -it myes /bin/bash
```

7.6.2好像可以直接使用vi命令

```
vi config/elasticsearch.yml
```

使用vi命令编辑config/elasticsearch.yml，增加以下命令：

```bash
#任何人都可以连接
network.host: 0.0.0.0 

http.cors.enabled: true
http.cors.allow-origin: "*"
```

其中：
**http.cors.enabled: true：**此步为允许elasticsearch跨域访问，默认是false。
**http.cors.allow-origin: “\*”：**表示跨域访问允许的域名地址（\*表示任意）。

**2、重新启动elasticseach容器**

**3、下载head镜像（此步省略）**

```
docker pull mobz/elasticsearch-head:5
```

**4、创建head容器**

```
docker run ‐di ‐‐name=myhead ‐p 9100:9100 容器ID
```

如果网页不显示索引数据

修改head容器里面/usr/src/app/_site/vendor.js

共有两处

1）6886行
contentType: "application/x-www-form-urlencoded
改成
contentType: "application/json;charset=UTF-8"
2）7573行

```
var inspectData = s.contentType === "application/x-www-form-urlencoded" &&
```

改成

```
var inspectData = s.contentType === "application/json;charset=UTF-8" &&
```

### 2.2.4 Kibana安装

<font color="ff000">kibana版本和es版本要一致</font>

**1、下载镜像**

```
docker pull kibana:7.6.2
```

**2、创建容器**

首先要使用`docker inspect es`查看docker给es容器分配的地址

<img src="https://cdn.jsdelivr.net/gh/qnjy/images/data/1620997268-image-20210514210108285.png" alt="image-20210514210108285" style="zoom: 67%;" />

之后创建kibana容器

```
docker run -d --name kibana  -e ELASTICSEARCH_URL=http://172.17.0.2:9200 -p 5601:5601 kibana:7.6.2
```

在之后进入容器

```
docker exec -it kibana /bin/bash
```

修改kibana.yml文件

```
vi /etc/kibana/kibana.yml
```

```yml
server.name: kibana
server.host: "0"
#修改
elasticsearch.hosts: [ "http://172.17.0.2:9200" ]
xpack.monitoring.ui.container.elasticsearch.enabled: true
#添加，如果是6.0以上的可以添加，变成中文界面
i18n.locale: "zh-CN"
```

之后就可以浏览器访问http://192.168.200.133:5601

## 2.3 RestFul风格

| method | url地址                                         | 描述                   |
| ------ | ----------------------------------------------- | ---------------------- |
| PUT    | localhost:9200/索引名称/类型名称/文档id         | 创建文档〔指定文档id ) |
| POST   | localhost:9200/索引名称/类型名称                | 创建文档〔随机文档id ) |
| POST   | localhost:9200/索引名称/类型名称/文档id/_update | 修改文档               |
| DELETE | localhost:9200/索引名称/类型名称/文档id         | 删除文档               |
| GET    | localhost:9200/索引名称/类型名称/文档id         | 查询文档通过文档id     |
| POST   | localhost:9200/索引名称/类型名称/_search        | 查询所有数据           |

### 2.3.1 关于索引的基本操作

1、创建一个索引

```
PUT /索引名/类型名/文档id
{请求体}
```

<img src="https://cdn.jsdelivr.net/gh/qnjy/images/data/1621130701-image-20210516100501074.png" alt="image-20210516100501074" style="zoom:67%;" />

2、name这个字段需要指定类型

* 字符串类型

  text、keyword

* 数值类型

  long、integer、short、byte、double、float、half float、scaled float

* 日期类型

  date

* 布尔值类型

  boolean

* 二进制类型

  binary

<img src="https://cdn.jsdelivr.net/gh/qnjy/images/data/1621130728-image-20210516100528808.png" alt="image-20210516100528808" style="zoom:67%;" />

3、指定字段类型

<img src="https://cdn.jsdelivr.net/gh/qnjy/images/data/1621130899-image-20210516100819310.png" alt="image-20210516100819310" style="zoom:67%;" />![image-20210516100858933](https://cdn.jsdelivr.net/gh/qnjy/images/data/1621130939-image-20210516100858933.png)

4、获取具体信息

<img src="https://cdn.jsdelivr.net/gh/qnjy/images/data/1621130899-image-20210516100819310.png" alt="image-20210516100819310" style="zoom:67%;" />![image-20210516100858933](https://cdn.jsdelivr.net/gh/qnjy/images/data/1621130939-image-20210516100858933.png)

### 2.3.2 关于文档的操作

> **基本操作**

1、添加数据

```java
put /kuangshen/user/1
{
  "name": "狂神说",
  "age":"23",
  "desc":"一顿操作猛如虎，一看工资2500",
  "tags":["技术宅","直男"]
}
```

<img src="https://cdn.jsdelivr.net/gh/qnjy/images/data/1621047224-image-20210515105344634.png" alt="image-20210515105344634" style="zoom:67%;" />

2、获取数据

<img src="https://cdn.jsdelivr.net/gh/qnjy/images/data/1621047421-image-20210515105701265.png" alt="image-20210515105701265" style="zoom:67%;" />

3、更新操作

如果使用put会改变version版本，这个可以联想到乐观锁

<img src="https://cdn.jsdelivr.net/gh/qnjy/images/data/1621047554-image-20210515105914487.png" alt="image-20210515105914487" style="zoom:67%;" />

推荐使用POST _update

<img src="https://cdn.jsdelivr.net/gh/qnjy/images/data/1621047687-image-20210515110127905.png" alt="image-20210515110127905" style="zoom:67%;" />

> **复杂操作搜索 select（排序、分页、高亮、模糊查询、精准查询）**

<img src="https://cdn.jsdelivr.net/gh/qnjy/images/data/1621048672-image-20210515111751957.png" alt="image-20210515111751957" style="zoom:67%;" />

输出结果太多，不想要那么多！

<img src="https://cdn.jsdelivr.net/gh/qnjy/images/data/1621048726-image-20210515111846452.png" alt="image-20210515111846452" style="zoom:67%;" />

> **分页查询**

![image-20220504110226956](https://qnjy.coding.net/p/githubimg/d/githubimg/git/raw/master/img/20220504-image-20220504110226956.png)

> **布尔值查询**

多条件精确查询：must(相当于mysql里面and)，must_not不必须，就是返回除此之外的结果集 

![image-20220504110926265](https://qnjy.coding.net/p/githubimg/d/githubimg/git/raw/master/img/20220504-image-20220504110926265.png)

should(or)相当于模糊查询

![image-20220504111058950](https://qnjy.coding.net/p/githubimg/d/githubimg/git/raw/master/img/20220504-image-20220504111058950.png)

筛选

![image-20220504111538759](https://qnjy.coding.net/p/githubimg/d/githubimg/git/raw/master/img/20220504-image-20220504111538759.png)

> 匹配多个条件

使用空格

![image-20220504112612771](https://qnjy.coding.net/p/githubimg/d/githubimg/git/raw/master/img/20220504-image-20220504112612771.png)

> 精确查询

term查询是直接通过倒排索引指定的词条进行精确查询

**关于分词：**

* term，直接查询精确的

* match，会使用分词器解析（先分析文档，然后通过分析的文档进行查询）

**两个类型 text和keyword**

==keyword是整体，不能被分开==

> 多个值匹配的精确查询

![image-20220504120315281](https://qnjy.coding.net/p/githubimg/d/githubimg/git/raw/master/img/20220504-image-20220504120315281.png)

> 高亮查询

![image-20220504130341353](https://qnjy.coding.net/p/githubimg/d/githubimg/git/raw/master/img/20220504-image-20220504130341353.png)

自定义高亮条件

![image-20220504130545859](https://qnjy.coding.net/p/githubimg/d/githubimg/git/raw/master/img/20220504-image-20220504130545859.png)

# 3 集成SpringBoot

学会查看文档https://www.elastic.co/guide/en/elasticsearch/client/index.html