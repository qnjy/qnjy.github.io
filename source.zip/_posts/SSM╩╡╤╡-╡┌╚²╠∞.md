---
title: SSM实训-第三天
abbrlink: 3d1842cf
date: 2022-06-22 10:06:27
tags:
categories:
---

Mybatis框架的核心理解：映射和ORM

SpringMVC框架的核心理解：拦截+分发 DispatcherServlet



基础Servlet时：一个路径url---->一个servlet--->一个类

SpringMVC：

只有一个Servlet（DispatcherServlet）--->匹配请求路径【拦截】

具体的请求url【分发】--->一个controller中的方法--->方法

<!--more-->

------

# 任务：

1 springmvc框架的学习和使用IOC

2 完成收费模块的开发

------

当前问题：

![image-20220622101223795](https://qnjy.coding.net/p/githubimg/d/githubimg/git/raw/master/img/20220622-image-20220622101223795.png)

在项目中引入Spring框架，就是为了解决这样的问题

简单理解IOC：

​			Inverse of control 控制反转

​			在使用Spring之前，所有的类对象都需要通过程序员手动new（或get），来获取。

​			有了Spring的IOC，类对象都提前在Spring容器中创建好了，用户直接用就可以

# 1 项目引入Spring框架

1 导入jar（mybatis-spring包、额外的jar:c3p0连接池）

2 导入配置文件

​	Spring-config.xml

​			(1)bea容器初始化，创建对象放入容器

​			(2)事务管理

​	web.xml:通过listener监听，加载spring配置文件，启动SpringIOC容器

IOC容器的初始化和使用：

（1）初始化，可以使用两种方式创建bean对象，放入ioc容器

​			I.bean标签手动创建

```xml
<bean class="com.xja.model.Room">
    <property name="building" value="ADong"/>
    <property name="unit" value="1"/>
</bean>
```

​			II.**自动检测context:component-scan**

```xml
<!--    检测包，自动创建bean-->
<!--   目标：将包中的类都创建对象，放入ioc容器-->
<context:component-scan base-package="com.xja.model" />
<!--   context:component-scan：自动检测 ，对包中的类是有要求，不是说所有的类都创建对象-->
<!--将需要创建对象的类，使用【@Controller(控制器)、@Service（服务）、@Component（组件）、@Repository（资源）】这四个注解之一标注。-->

```

（2）使用

@Autowired：自动从IOC容器中取出相关类型的对象给变量值

------

# 2 缴费模块编写

1 数据表设计

费用表fee

```mysql
CREATE TABLE `fee` (
    `feeid` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键自增',
    `feecode` varchar(255) DEFAULT NULL COMMENT '费用编号',
    `roomid` int(11) DEFAULT NULL COMMENT '房间id',
    `roomname` varchar(255) DEFAULT NULL COMMENT '房间名',
    `amount` double(11,2) DEFAULT NULL COMMENT '金额',
    `chargename` varchar(255) DEFAULT NULL COMMENT '费用项目',
    `chargeinfo` varchar(255) DEFAULT NULL COMMENT '费用说明',
    `feecreatedtime` varchar(255) DEFAULT NULL COMMENT '记录生成时间',
    `paystatus` int(11) DEFAULT NULL COMMENT '0未交费 1部分缴费 2已缴费',
    `feeremark` varchar(255) DEFAULT NULL COMMENT '备注',
    PRIMARY KEY (`feeid`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4;
```

缴费记录表payrecord

```mysql
CREATE TABLE `payrecord` (
  `payrecordid` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键自增',
  `userid` int(11) DEFAULT NULL COMMENT '业主id',
  `paycreatedtime` varchar(255) DEFAULT NULL COMMENT '缴费时间',
  `payamount` double(11,2) DEFAULT NULL COMMENT '缴费金额',
  `feecode` varchar(255) DEFAULT NULL COMMENT '费用编号',
  `payremark` varchar(255) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`payrecordid`)
) ENGINE=InnoDB AUTO_INCREMENT=104 DEFAULT CHARSET=utf8mb4;
```

2 插入50条数据，这两个数据表之间是有关联的

3 功能设计

I.费用模块

列表展示：

费用编号、房间名、金额、费用类型、费用说明、生成时间、缴费状态、已缴费金额、操作



**多条件查询：**

费用类型、缴费状态、房间号



新增【点击按钮新增一条数据---》草率，不能这么做】【做好费用excel表，一起导入（管理员操作）】（需要有，延迟实现）

修改、删除【不要】

额外功能：Excel报表导出（将缴费、待缴费或其他筛选出来的内容，导出到excel中）（延迟实现）

II.缴费模块

列表展示：

id、业主姓名、房间号、手机号、缴费金额、缴费时间、费用编号、备注



**多条件查询：**

费用编号、手机号、时间（开始~结束）



新增：

​		特殊人群需要新增（填写：金额、费用编号、备注）

修改：

​		保留

额外的功能：Excel报表导出

