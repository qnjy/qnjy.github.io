---
title: cloacked-pixel艰难使用
tags:
  - cloacked-pixel
categories: 第一届DMCTF夺旗赛
abbrlink: 387a909
date: 2020-11-27 17:08:29
---

python2下载安装，安装成功后，尝试使用<!--more-->

![DyZcfU.jpg](https://s3.ax1x.com/2020/11/28/DyZcfU.jpg)

见到没有这个包

之后开始安装缺少的包

```
pip2 install numpy -i https://pypi.tuna.tsinghua.edu.cn/simple/
```

[![DyZW6J.jpg](https://s3.ax1x.com/2020/11/28/DyZW6J.jpg)

最后终于能够成功使用，拿到flag

![DyZ6YT.jpg](https://s3.ax1x.com/2020/11/28/DyZ6YT.jpg)

