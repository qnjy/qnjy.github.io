---
title: CSRF攻击
tags:
  - CSRF
categories: 网络安全知识学习
abbrlink: 44b0db89
date: 2020-11-23 18:55:49
---

　　学习了这部分之后，我感觉之前qq空间链接的那种盗号方式，应该就是这个原理<!--more-->

# 1.什么是CSRF

　　跨站请求伪造（Cross-site request forgery，CSRF），也被称为one click attack/session riding，通常缩写是CSRF/XSRF。

# 2.CSRF可以做些什么

　　可以简单理解为：<font color="ff0000">攻击者盗用了你的身份，以你的名义发送恶意请求</font>，它利用网站对用户网页浏览器的信任。如：转移资金、修改电子邮件地址、密码。	

# 3.CSRF原理

　　<font color="ff0000">受害者 Bob 在银行有一笔存款，通过对银行的网站发送请求 http://bank.example/withdraw?account=bob&amount=1000000&for=bob2 可以使 Bob 把 1000000 的存款转到 bob2 的账号下。通常情况下，该请求发送到网站后，服务器会先验证该请求是否来自一个合法的 session，并且该 session 的用户 Bob 已经成功登陆。</font>

　　<font color="ff0000">黑客 Mallory 自己在该银行也有账户，他知道上文中的 URL 可以把钱进行转帐操作。Mallory 可以自己发送一个请求给银行：http://bank.example/withdraw?account=bob&amount=1000000&for=Mallory。但是这个请求来自 Mallory 而非 Bob，他不能通过安全认证，因此该请求不会起作用。</font>

　　<font color="ff0000">这时，Mallory 想到使用 CSRF 的攻击方式，他先自己做一个网站，在网站中放入如下代码： src=”http://bank.example/withdraw?account=bob&amount=1000000&for=Mallory ”，并且通过广告等诱使 Bob 来访问他的网站。当 Bob 访问该网站时，上述 url 就会从 Bob 的浏览器发向银行，而这个请求会附带 Bob 浏览器中的 cookie 一起发向银行服务器。大多数情况下，该请求会失败，因为他要求 Bob 的认证信息。但是，如果 Bob 当时恰巧刚访问他的银行后不久，他的浏览器与银行网站之间的 session 尚未过期，浏览器的 cookie 之中含有 Bob 的认证信息。这时，悲剧发生了，这个 url 请求就会得到响应，钱将从 Bob 的账号转移到 Mallory 的账号，而 Bob 当时毫不知情。等以后 Bob 发现账户钱少了，即使他去银行查询日志，他也只能发现确实有一个来自于他本人的合法请求转移了资金，没有任何被攻击的痕迹。而 Mallory 则可以拿到钱后逍遥法外。 </font>

![s1xb59.png](https://s3.ax1x.com/2021/01/11/s1xb59.png)

```
1.Bob打开浏览器，访问受信任银行网站，输入用户名和密码请求登录网站；
2.在Bob信息通过验证后，银行网站产生Cookie信息并返回给浏览器，此时Bob登录网站成功，可以正常发送请求到网站；
3.Bob未退出银行网站之前，在同一浏览器中，打开一个TAB页访问其他网站B
4.这时候网站B 已被黑客注入诱导信息，加入是一张图片,图片地址指向
   src=”http://bank.example/withdraw?account=bob&amount=1000000&for=hacker
  点击之后转账给黑客这个账户
5.浏览器在接收到这些攻击性代码请求后，根据网站B的请求，在Bob不知情的情况下携带Cookie信息，根据用户的Cookie信息以Bob的权限处理该请求，导致来自黑客请求恶意代码被执行。 
```

# 4.CSRF攻击类型

## 4.1 GET类型的CSRF

GET类型的CSRF利用非常简单，只需要HTTP请求，一般这样利用：

```
 ![](https://awps-assets.meituan.net/mit-x/blog-images-bundle-2018b/ff0cdbee.example/withdraw?amount=10000&for=hacker)
```

在受害者访问含有这个img的页面后，浏览器会自动向`http://bank.example/withdraw?account=xiaoming&amount=10000&for=hacker`发出一次HTTP请求。bank.example就会收到包含受害者登录信息的一次跨域请求。

## 4.2 POST类型的CSRF

这种类型的CSRF利用起来通常使用的是一个自动提交的表单，如：

```jsp
 <form action="http://bank.example/withdraw" method=POST>
    <input type="hidden" name="account" value="xiaoming" />
    <input type="hidden" name="amount" value="10000" />
    <input type="hidden" name="for" value="hacker" />
</form>
<!--自动提交表单-->
<script> document.forms[0].submit(); </script> 
```

访问该页面后，表单会自动提交，相当于模拟用户完成了一次POST操作。POST类型的攻击通常比GET要求更加严格一点，但扔并不复杂。任何个人网站、博客，被黑客上传页面的往回走哪都有可能是发起攻击的来源。

## 4.3 链接类型的CSRF

这种需要用户点击链接才会触发。这种类型通常是杂论坛中发布的图片中嵌入恶意链接，或者以广告的形式诱导用户中招，例如：

```php
<a href="http://test.com/csrf/withdraw.php?amount=1000&for=hacker" taget="_blank">
  重磅消息！！
  <a/>
```

由于之前用户登陆的信任的网站A，并且保存登录状态，只要用户主动访问上面的这个PHP页面，就表示攻击成功。

# 5.CSRF的特点

* 攻击一般发起在第三方网站，而不是被攻击的网站。
* 攻击利用受害者在被攻击网站的登陆凭证，冒充受害者提交操作。
* 整个过程攻击者并不能获取到受害者的登陆凭证，仅仅是冒用。

# 6.防护措施

## 6.1 验证HTTP Referer字段

HTTP头中有一个Referer的字段，它记录了该HTTP请求的来源网址

![s1xHUJ.png](https://s3.ax1x.com/2021/01/11/s1xHUJ.png)

　　也就是说，服务器会验证客户端的请求来源，如果是本网站请求的就响应，否则不响应。

　　正如上文所提到的，Bob必须登录银行网站，通过页面上的按钮触发转账事件。当用户提交请求时，该转账请求的Referer值就会是转账按钮所在页面的URL。黑客只能在自己网站构造请求，当用户通过攻击者的网站发送请求到银行时，该请求的Referer是指向黑客的网站。所以不能响应。

但是这种方式仍然<font color="ff000">存在安全隐患</font>

```
1.对于某些浏览器，比如IE6或FF2，目前已经有一些方法可以篡改Referer值
2.用户自己可以这只浏览器使其请求时不再提供Referer
```

## 6.2 使用token（Anti CSRF Token）

可以理解为防伪

例子：

1.用户访问某个表单页面。

2.服务端生成一个Token，放在用户的Session中，或者浏览器的Cookie中。

3.在页面表单附带上Token参数。

4.用户提交请求后， 服务端验证表单中的Token是否与用户Session（或Cookies）中的      Token一致，一致为合法请求，不是则非法请求。

　　这个Token的值必须是随机的。由于Token的存在，攻击者无法再构造一个带有合法Token的请求实施CSRF攻击。另外使用Token时应注意Token的保密性，尽量把敏感操作由GET改为`POST`，以form或AJAX形式提交，避免Token泄露。