---
title: Linux虚拟机网络配置
tags:
  - Linux
abbrlink: f05f2e38
date: 2021-01-19 09:00:36
categories:
---

　　每次新建完虚拟机之后忘记快照，都得重新安装虚拟机并且配置网络，把配置过程记录在这里。<!--more-->

**1.VMware选择NAT模式**

一定要确保虚拟机选择的是NAT模式

**2.在虚拟机中操作**

需要点击虚拟机的“虚拟网络编辑器”

<img src="https://cdn.jsdelivr.net/gh/qnjy/images/data/1621571249-image-20210521122728538.png" alt="image-20210521122728538" style="zoom: 50%;" />

<img src="https://cdn.jsdelivr.net/gh/qnjy/images/data/1621571363-image-20210521122922933.png" alt="image-20210521122922933" style="zoom:67%;" />

`vi /etc/sysconfig/network-scripts/ifcfg-ens33`

根据IP修改为以下内容

```sh
TYPE=Ethernet #网络类型

#1.将这个更改为none
BOOTPROTO=none #IP获取方式，有dhcp自动获取和静态IP（none/static）

NAME=ens33 #网络名称
UUID=d1755a41-8026-42f1-871d-9cd78fa2aa3c 
DEVICE=ens33 #驱动名称

#2.更改为yes
ONBOOT=yes #设置开机启动

#3.添加以下内容
IPADDR=192.168.137.3 #设置静态IP地址，结合上图填写
NETMASK=255.255.255.0 #子网掩码
GATEWAY=192.168.137.254 #网关，结合上图填写
DNS1=114.114.114.114 #DNS
DNS2=202.96.134.133
```

保存退出后重启网络服务

`systemctl restart network.service`

