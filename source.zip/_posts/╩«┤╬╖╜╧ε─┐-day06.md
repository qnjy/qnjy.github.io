---
title: 十次方项目-day06
abbrlink: eaa21e2
date: 2021-06-21 16:42:59
tags:
categories:
---

# 1 配置tensquare_base微服务

<!--more-->

在pom.xml文件中添加

```xml
    <dependency>
            <groupId>com.tensquare</groupId>
            <artifactId>tensquare_common</artifactId>
            <version>1.0-SNAPSHOT</version>
        </dependency>

        <dependency>
            <groupId>mysql</groupId>
            <artifactId>mysql-connector-java</artifactId>
            <version>5.1.47</version>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-data-jpa</artifactId>
        </dependency>
        
```

编写启动类

```java
@SpringBootApplication
public class BaseApplication {
    public static void main(String[] args) {
        SpringApplication.run(BaseApplication.class);
    }
    @Bean
    public IdWorker idWorker(){
        return new IdWorker(1,1);
    }
}
```

配置yml

```yml
server:
  port: 9001
spring:
  application:
    name: tensquare-base

  datasource:
    driver-class-name: com.mysql.jdbc.Driver
    url: jdbc:mysql://8.140.127.197:3306/tensquare_base?characterEncoding=utf-8&serverTimezone=GMT%2B8
    username: root
    password: root

  jpa:
    database: mysql
    show-sql: true
    generate-ddl: true
```

## 1.1 表结构分析

表名称：tb_label



| 字段名称  | 字段含义 | 字段类型 | 备注              |
| --------- | -------- | -------- | ----------------- |
| id        | ID       | 文本     |                   |
| labelname | 标签名称 | 文本     |                   |
| state     | 状态     | 文本     | 0：无效  1：有效  |
| count     | 使用数量 | 整型     |                   |
| fans      | 关注数   | 整型     |                   |
| recommend | 是否推荐 | 文本     | 0：不推荐 1：推荐 |

## 1.2 CRUD实现

1. 实体类

   创建com.tensquare.base包，包下创建pojo包 ，包下创建实体类Label

   ```java
   /**
     * 标签实体类
     */
   @Entity
   @Table(name="tb_label")
   public class Label {
       @Id
       private String id;//
       private String labelname;//标签名称
       private String state;//状态
       private Long count;//使用数量
       private Long fans;//关注数
       private String recommend;//是否推荐
       
       //setter and getter ···
   }
   ```

2. 创建数据访问接口

   com.tensquare.base包下创建dao包，包下创建LabelDao接口

   ```java
   /**
     * 标签数据访问接口
     */
   public interface LabelDao extends JpaRepository<Label,String>,JpaSpecificationExecutor<Label>{
   }
   ```

   JpaRepository提供了基本的增删改查
   JpaSpecificationExecutor用于做复杂的条件查询

3. 业务逻辑类

   com.tensquare.base包下创建service包，包下创建LabelService类。 在这个类中，我们
   实现基本的增删改查功能

   ```java
   /**
    * 标签业务逻辑类
    */
   @Service
   public class LabelService {
       @Autowired
       private LabelDao labelDao;
       @Autowired
       private IdWorker idWorker;
   
       /**
        * 查询全部标签
        *
        * @return
        */
       public List<Label> findAll() {
           return labelDao.findAll();
       }
   
       /**
        * 根据ID查询标签
        *
        * @return
        */
       public Label findById(String id) {
           return labelDao.findById(id).get();
       }
   
       /**
        * 增加标签
        *
        * @param label
        */
       public void add(Label label) {
           label.setId(idWorker.nextId() + "");//设置ID
           labelDao.save(label);
       }
   
       /**
        * 修改标签
        *
        * @param label
        */
       public void update(Label label) {
           labelDao.save(label);
       }
   
       /**
        * 删除标签
        *
        * @param id
        */
       public void deleteById(String id) {
           labelDao.deleteById(id);
       }
   }
   ```

4. 控制器类

   com.tensquare.base包下创建controller包，创建LabelController

   ```java
   @RestController
   @CrossOrigin
   @RequestMapping("/label")
   public class LabelController {
   
       @Autowired
       private LabelService labelService;
   
       //查询全部列表
       @GetMapping
       public Result findAll() {
           List list = labelService.findAll();
           return new Result(true, StatusCode.OK, "查询成功", list);
       }
   
       //根据id查询标签
       @GetMapping("/{labelId}")
       public Result findById(@PathVariable String labelId) {
           return new Result(true, StatusCode.OK, "查询成功", labelService.findById(labelId));
       }
   
       //增加标签
       @PostMapping
       public Result save(@RequestBody Label label) {
           labelService.save(label);
           return new Result(true, StatusCode.OK, "添加成功");
       }
   
       //修改标签
       @PutMapping("/{labelId}")
       public Result update(@PathVariable String labelId, @RequestBody Label label) {
           label.setId(labelId);
           labelService.update(label);
           return new Result(true, StatusCode.OK, "更新成功");
       }
   
       //删除标签
       @PostMapping("/{labelId}")
       public Result deleteById(@PathVariable String labelId) {
           labelService.deleteById(labelId);
           return new Result(true, StatusCode.OK, "删除成功");
       }
   
       @PostMapping("/search")
       public Result findSearch(@RequestBody Label label) {
           List<Label> list = labelService.findSearch(label);
           return new Result(true, StatusCode.OK, "查询成功", list);
       }
   
       @PostMapping("/search/{page}/{size}")
       public Result pageQuery(@RequestBody Label label, @PathVariable int page, @PathVariable int size) {
           Page<Label> pageData = labelService.pageQuery(label, page, size);
           return new Result(true, StatusCode.OK, "查询成功", new PageResult<>(pageData.getTotalElements(), pageData.getContent()));
       }
   }
   ```


## 1.3 公共异常处理

为了使我们的代码更容易维护，我们创建一个类集中处理异常
在com.tensquare.user.controller包下创建公共异常处理类BaseExceptionHandler

```java
/**
* 统一异常处理类
*/
@ControllerAdvice
public class BaseExceptionHandler {
    @ExceptionHandler(value = Exception.class)
    @ResponseBody
    public Result error( Exception e) {
        e.printStackTrace();
        return new Result(false, StatusCode.ERROR, e.getMessage());
    }
}
```

## 1.4 跨域处理

　　跨域是什么？浏览器从一个域名的网页去请求另一个域名的资源时，域名、端口、协议任一不同，都是跨域 。我们是采用前后端分离开发的，也是前后端分离部署的，必然会存在跨域问题。 怎么解决跨域？很简单，只需要在controller类上添加注解@CrossOrigin 即可！这个注解其实是CORS的实现。
　　CORS(Cross-Origin Resource Sharing, 跨源资源共享)是W3C出的一个标准，其思想是使用自定义的HTTP头部让浏览器与服务器进行沟通，从而决定请求或响应是应该成功，还是应该失败。因此，要想实现CORS进行跨域，需要服务器进行一些设置，同时前端也需要做一些配置和分析。本文简单的对服务端的配置和前端的一些设置进行分析。

# 2 招聘微服务开发

## 2.1 表结构分析

招聘微服务主要有两块：企业信息和招聘信息

| 企业表     | tb_enterprise |          |                    |
| ---------- | ------------- | -------- | ------------------ |
| 字段名称   | 字段含义      | 字段类型 | 备注               |
| id         | ID            | 文本     |                    |
| name       | 企业名称      | 文本     |                    |
| summary    | 企业简介      | 文本     |                    |
| address    | 企业地址      | 文本     |                    |
| labels     | 标签列表      | 文本     | 用逗号分隔         |
| coordinate | 企业位置坐标  | 文本     | 经度，纬度         |
| ishot      | 是否热门      | 文本     | 0：非热门，1：热门 |
| logo       | LOGO          | 文本     |                    |
| jobcount   | 职位教        | 数字     |                    |
| url        | URL           | 文本     |                    |

## 2.2 代码生成

