---
title: python基础
tags:
  - Python
categories: 网络安全知识学习
abbrlink: 81b2f4bf
date: 2020-11-12 19:20:22
---

　　基本了解Python能读懂别人的程序<!--more-->

# Python简介

* 解释型语言
* 交互式语言
* 面向对象语言

## 1.特点

1.易于学习

2.易于阅读

3.易于维护

4.有丰富的库

5.可移植

6.可扩展

7.数据库

8.GUI编程

9.可嵌入

# 环境搭建

## 1.下载

python官网：https://www.python.org/

## 2.安装

<img src="https://s3.ax1x.com/2020/11/12/BzyPJI.jpg" alt="BzyPJI.jpg" style="zoom:67%;" />

<img src="https://s3.ax1x.com/2020/11/12/BzyCFA.jpg" alt="BzyCFA.jpg" style="zoom:67%;" />

<img src="https://s3.ax1x.com/2020/11/12/Bzypod.jpg" alt="Bzypod.jpg" style="zoom:67%;" />

安装完成之后，打开dos命令窗口输入python，出现以下字样安装成功：

<img src="https://s3.ax1x.com/2020/11/12/BzySdH.jpg" alt="BzySdH.jpg" style="zoom:50%;" />

# Python运算符

## 1.算术运算符

与C、Java基本没有差别，多了2**6，表示2的6次方。

## 2.位运算符

a（60）= 0011 1100，b（13）= 0000 1101

| 运算符 | 描述                                                         | 实例                                                         |
| :----- | :----------------------------------------------------------- | :----------------------------------------------------------- |
| &      | 按位与运算符：参与运算的两个值相应位都为1，则该位的结果为1，否则为0 | (a & b) 输出结果 12 ，二进制解释： 0000 1100                 |
| \|     | 按位或运算符：只要对应的两个二进位有一个为1，结果位就是1     | (a\|b)输出为61，二进制解释：0011 1101                        |
| ^      | 按位异或运算符：当两个对应的二进位相异时，结果为1            | (a ^ b) 输出结果 49 ，二进制解释： 0011 0001                 |
| ~      | 按位取反运算符                                               | (~a ) 输出结果 -61 ，二进制解释： 1100 0011， 在一个有符号二进制数的补码形式。 |
| <<     | 左移动运算符：左移动若干位                                   | a << 2 输出结果 240 ，二进制解释： 1111 0000                 |
| >>     | 右移动运算符：右移动若干位                                   | a >> 2 输出结果 15 ，二进制解释： 0000 1111                  |

## 3.逻辑运算符

a=10，b=20

| 运算符 | 逻辑表达式 | 描述                                                         | 实例                    |
| ------ | ---------- | ------------------------------------------------------------ | ----------------------- |
| and    | x and y    | 布尔"与" - 如果 x 为 False，x and y 返回 False，否则它返回 y 的计算值。 | (a and b) 返回 20。     |
| or     | x or y     | 布尔"或" - 如果 x 是 True，它返回 x 的值，否则它返回 y 的计算值。 | (a or b) 返回 10。      |
| not    | not x      | 布尔"非" - 如果 x 为 True，返回 False 。如果 x 为 False，它返回 True。 | not(a and b) 返回 False |

## 4.成员运算符

| 运算符 | 描述                                                    | 实例                                              |
| ------ | ------------------------------------------------------- | ------------------------------------------------- |
| in     | 如果在指定的序列中找到值返回 True，否则返回 False。     | x 在 y 序列中 , 如果 x 在 y 序列中返回 True。     |
| not in | 如果在指定的序列中没有找到值返回 True，否则返回 False。 | x 不在 y 序列中 , 如果 x 不在 y 序列中返回 True。 |

## 5.身份运算符

| 运算符 | 描述                                        | 实例                                                         |
| ------ | ------------------------------------------- | ------------------------------------------------------------ |
| is     | is 是判断两个标识符是不是引用自一个对象     | **x is y**, 类似 **id(x) == id(y)** , 如果引用的是同一个对象则返回 True，否则返回 False |
| is not | is not 是判断两个标识符是不是引用自不同对象 | **x is not y** ， 类似 **id(a) != id(b)**。如果引用的不是同一个对象则返回结果 True，否则返回 False。 |

**注意：is判断引用对象是否是同一个，==判断值是否相等**

# Python中的基本数据类型

## 1.不可变数据

### 1.Number（数字）

* int
* float
* bool
* complex（复数）:a+bj或complex(a,b)表示

### 2.String（字符串）

1.索引值正向从0开始，反向从-1开始

![](https://static.runoob.com/wp-content/uploads/123456-20200923-1.svg)

2.str[0:5]：遵循**左闭右开**原则

### 3.Tuple（元组）

```python
tuple = ("Google", "Runoob", "Taobao")
```

当元组中只有一个元素时，需要在后面加逗号，否则括号被当做运算符使用

```python
>>> tup1 = (50)
>>> type(tup1)   # 不加逗号，类型为整型
<**class** 'int'>

>>> tup1 = (50,)
>>> type(tup1)   # 加上逗号，类型为元组
<**class** 'tuple'>
```

## 2.可变数据

### 4.List（列表）

```python
list = ['red', 'green', 'black', 'white']
```

索引值和String类型一样

### 5.Set（集合）

集合是无序的不重复的元素序列

可以使用{}或set()函数创建集合，**创建空集合必须用set()而不是{}，因为{}用来创建空字典**

parame = {1, 2, 3, 4, 5}

或

set(1, 2, 3, 4, 5)

### 6.Dictionary（字典）

```python
dict = {'name': 'runoob', 'likes': 123, 'url': 'www.runoob.com'}
```

![](https://www.runoob.com/wp-content/uploads/2016/04/py-dict-2.png)

# Python的条件控制

## 1.基本格式

```python
age = int(input("请输入你家狗狗的年龄: "))
print("")
if age <= 0:
    print("你是在逗我吧!")
elif age == 1:
    print("相当于 14 岁的人。")
elif age == 2:
    print("相当于 22 岁的人。")
elif age > 2:
    human = 22 + (age -2)*5
    print("对应人类年龄: ", human)
 
### 退出提示
input("点击 enter 键退出")
```

## 2.if嵌套

```python
num=int(input("输入一个数字："))
if num%2==0:
    if num%3==0:
        print ("你输入的数字可以整除 2 和 3")
    else:
        print ("你输入的数字可以整除 2，但不能整除 3")
else:
    if num%3==0:
        print ("你输入的数字可以整除 3，但不能整除 2")
    else:
        print  ("你输入的数字不能整除 2 和 3")
```

```
输入一个数字：6
你输入的数字可以整除 2 和 3
```

# Python的循环语句

## 1.while循环

```python
n = 100

sum = 0
counter = 1
while counter <= n:
    sum += counter
    counter += 1
print("1到%d的总和：%d" % (n, sum))  
```

## 2.while循环使用else语句

条件语句为false时，执行else语句块

```python
count = 0
while count < 5:
   print (count, " 小于 5")
   count = count + 1
else:
   print (count, " 大于或等于 5")
```

## 3.for循环

### 1.一般遍历

```python
sites = ["Baidu", "Google","Runoob","Taobao"]
for site in sites:
    if site == "Runoob":
        print("菜鸟教程!")
        break
    print("循环数据 " + site)
else:
    print("没有循环数据!")
print("完成循环!")
```

执行脚本后，在循环到“Runoob”时跳出循环体：

```
循环数据 Baidu
循环数据 Google
菜鸟教程!
完成循环!
```

### 2.range()函数遍历

```python
for i in range(5,9) :
    print(i)
    
5
6
7
8
```

```python
for i in range(0, 10, 3)

0
3
6
9
```

### 3.range()和len()遍历一个序列的索引

```python

a = ['Google', 'Baidu', 'Runoob', 'Taobao', 'QQ']
for i in range(len(a)):
...     print(i, a[i])
... 
0 Google
1 Baidu
2 Runoob
3 Taobao
4 QQ
```

### 4.range()函数创建一个列表

```python
list(range(5))
```

[0, 1, 2, 3, 4]

## 4.break和continue

break是跳出这次循环

continue是跳过这次循环

