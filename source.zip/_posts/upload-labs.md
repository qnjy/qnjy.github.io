---
title: upload-labs
tags:
  - upload-labs
categories: 网络安全知识学习
abbrlink: 80f02bc5
date: 2020-11-17 08:40:11
---

　　BBUCTF的upload-labs关卡<!--more-->

# 概述

下图为upload-labs的上传漏洞分类

<img src="https://s3.ax1x.com/2020/11/17/DEhkS1.png" alt="DEhkS1.png" style="zoom:67%;" />

# PASS-01（JS检查）

## 1.分析

```php
function checkFile() {
    var file = document.getElementsByName('upload_file')[0].value;
    if (file == null || file == "") {
        alert("请选择要上传的文件!");
        return false;
    }
    //定义允许上传的文件类型
    var allow_ext = ".jpg|.png|.gif";
    //提取上传文件的类型
    var ext_name = file.substring(file.lastIndexOf("."));
    //判断上传文件类型是否允许上传
    if (allow_ext.indexOf(ext_name + "|") == -1) {
        var errMsg = "该文件不允许上传，请上传" + allow_ext + "类型的文件,当前文件类型为：" + ext_name;
        alert(errMsg);
        return false;
    }
}
```

选择php文件之后，上传显示

![DETazd.jpg](https://s3.ax1x.com/2020/11/17/DETazd.jpg)

数据还没有发送，就开始检测，说明是客户端检测

## 2.绕过思路

1.将php文件后缀名改为jpg

2.打开burpsuite->Proxy->intercept->Option，开启Remove all JavaScript

<img src="https://s3.ax1x.com/2020/11/17/DETwQA.jpg" alt="DETwQA.jpg" style="zoom:67%;" />

2.开始上传并使用burpsuite拦截

<img src="https://s3.ax1x.com/2020/11/17/DET0sI.jpg" alt="DET0sI.jpg" style="zoom:50%;" />

3.将文件后缀名改为php

<img src="https://s3.ax1x.com/2020/11/17/DETURH.jpg" alt="DETURH.jpg" style="zoom:67%;" />

# PASS-02（MIME验证）

## 1.分析

```php
$is_upload = false;
$msg = null;
if (isset($_POST['submit'])) {
    if (file_exists(UPLOAD_PATH)) {
        if (($_FILES['upload_file']['type'] == 'image/jpeg') || ($_FILES['upload_file']['type'] == 'image/png') || ($_FILES['upload_file']['type'] == 'image/gif')) {
            $temp_file = $_FILES['upload_file']['tmp_name'];
            $img_path = UPLOAD_PATH . '/' . $_FILES['upload_file']['name']            
            if (move_uploaded_file($temp_file, $img_path)) {
                $is_upload = true;
            } else {
                $msg = '上传出错！';
            }
        } else {
            $msg = '文件类型不正确，请重新上传！';
        }
    } else {
        $msg = UPLOAD_PATH.'文件夹不存在,请手工创建！';
    }
}
```

代码中定义MIME类型为image/jpeg的才能上传

```php
if (($_FILES['upload_file']['type'] == 'image/jpeg') || ($_FILES['upload_file']['type'] == 'image/png') || ($_FILES['upload_file']['type'] == 'image/gif'))
```

## 2.绕过思路

使用burpsuite修改content-type类型

<img src="https://s3.ax1x.com/2020/11/17/DEzGP1.jpg" alt="DEzGP1.jpg" style="zoom:67%;" />

# PASS-03（黑名单绕过）

## 1.分析

```php
$is_upload = false;
$msg = null;
if (isset($_POST['submit'])) {
    if (file_exists(UPLOAD_PATH)) {
        $deny_ext = array('.asp','.aspx','.php','.jsp');
        $file_name = trim($_FILES['upload_file']['name']);
        $file_name = deldot($file_name);//删除文件名末尾的点
        $file_ext = strrchr($file_name, '.');
        $file_ext = strtolower($file_ext); //转换为小写
        $file_ext = str_ireplace('::$DATA', '', $file_ext);//去除字符串::$DATA
        $file_ext = trim($file_ext); //收尾去空

        if(!in_array($file_ext, $deny_ext)) {
            $temp_file = $_FILES['upload_file']['tmp_name'];
            $img_path = UPLOAD_PATH.'/'.date("YmdHis").rand(1000,9999).$file_ext;            
            if (move_uploaded_file($temp_file,$img_path)) {
                 $is_upload = true;
            } else {
                $msg = '上传出错！';
            }
        } else {
            $msg = '不允许上传.asp,.aspx,.php,.jsp后缀文件！';
        }
    } else {
        $msg = UPLOAD_PATH . '文件夹不存在,请手工创建！';
    }
}
```

服务器端检测asp、aspx、php、jsp

## 2.绕过方法

除了以上四个后缀不能上传，我们可以上传其他任意后缀，比如：.phtml .phps ,.php3.php5 .pht。所以，将文件后缀名改为php3开始上传。

# PASS-04（.htaccess绕过）

## 1.分析

黑名单限制了更多的后缀不允许上传，但是并没有限制.htaccess文件。

## 2.htaccess文件

这类文件是apache服务器的一个配置文件，他负责相关目录下的网页配置。通过htaccess文件，可以实现：网页301重定向、自定义404错误页面、改变文件扩展名、允许/阻止特定的用户或者目录的访问、禁止目录列表、配置默认文档等功能IIS平台上不存在该文件，该文件默认开启，启用和关闭在httpd.conf文件中配置。

## 3.绕过方法

1.首先上传一个内容为`SetHandler application/x-httpd-php`的.htaccess文件，让之后上传的所有文件解析成php文件。

![DVARsI.jpg](https://s3.ax1x.com/2020/11/17/DVARsI.jpg)

2.之后开始上传php文件

<img src="https://s3.ax1x.com/2020/11/17/DVAWLt.jpg" alt="DVAWLt.jpg" style="zoom:67%;" />

# PASS-05（大小写绕过）

## 1.分析

```php
$is_upload = false;
$msg = null;
if (isset($_POST['submit'])) {
    if (file_exists(UPLOAD_PATH)) {
        $deny_ext = array(".php",".php5",".php4",".php3",".php2",".html",".htm",".phtml",".pht",".pHp",".pHp5",".pHp4",".pHp3",".pHp2",".Html",".Htm",".pHtml",".jsp",".jspa",".jspx",".jsw",".jsv",".jspf",".jtml",".jSp",".jSpx",".jSpa",".jSw",".jSv",".jSpf",".jHtml",".asp",".aspx",".asa",".asax",".ascx",".ashx",".asmx",".cer",".aSp",".aSpx",".aSa",".aSax",".aScx",".aShx",".aSmx",".cEr",".sWf",".swf",".htaccess");
        $file_name = trim($_FILES['upload_file']['name']);
        $file_name = deldot($file_name);//删除文件名末尾的点
        $file_ext = strrchr($file_name, '.');
        $file_ext = str_ireplace('::$DATA', '', $file_ext);//去除字符串::$DATA
        $file_ext = trim($file_ext); //首尾去空

        if (!in_array($file_ext, $deny_ext)) {
            $temp_file = $_FILES['upload_file']['tmp_name'];
            $img_path = UPLOAD_PATH.'/'.date("YmdHis").rand(1000,9999).$file_ext;
            if (move_uploaded_file($temp_file, $img_path)) {
                $is_upload = true;
            } else {
                $msg = '上传出错！';
            }
        } else {
            $msg = '此文件类型不允许上传！';
        }
    } else {
        $msg = UPLOAD_PATH . '文件夹不存在,请手工创建！';
    }
}
```

查看源码还是黑名单限制，也加上了.htaccess，但是没有将后缀大小写统一，所以大小写绕过

## 2.绕过方法

将文件后缀改换大小写

# PASS-06（空格绕过）

## 1.分析

```php
$is_upload = false;
$msg = null;
if (isset($_POST['submit'])) {
    if (file_exists(UPLOAD_PATH)) {
        $deny_ext = array(".php",".php5",".php4",".php3",".php2",".html",".htm",".phtml",".pht",".pHp",".pHp5",".pHp4",".pHp3",".pHp2",".Html",".Htm",".pHtml",".jsp",".jspa",".jspx",".jsw",".jsv",".jspf",".jtml",".jSp",".jSpx",".jSpa",".jSw",".jSv",".jSpf",".jHtml",".asp",".aspx",".asa",".asax",".ascx",".ashx",".asmx",".cer",".aSp",".aSpx",".aSa",".aSax",".aScx",".aShx",".aSmx",".cEr",".sWf",".swf",".htaccess");
        $file_name = $_FILES['upload_file']['name'];
        $file_name = deldot($file_name);//删除文件名末尾的点
        $file_ext = strrchr($file_name, '.');
        $file_ext = strtolower($file_ext); //转换为小写
        $file_ext = str_ireplace('::$DATA', '', $file_ext);//去除字符串::$DATA
        
        if (!in_array($file_ext, $deny_ext)) {
            $temp_file = $_FILES['upload_file']['tmp_name'];
            $img_path = UPLOAD_PATH.'/'.date("YmdHis").rand(1000,9999).$file_ext;
            if (move_uploaded_file($temp_file,$img_path)) {
                $is_upload = true;
            } else {
                $msg = '上传出错！';
            }
        } else {
            $msg = '此文件不允许上传';
        }
    } else {
        $msg = UPLOAD_PATH . '文件夹不存在,请手工创建！';
    }
}
```

## 2.绕过方法

黑名单中添加了更多的后缀名，但是没有对后缀名去除空格，所以可以才后缀名中添加空格。

<img src="https://s3.ax1x.com/2020/11/17/DVmGvQ.jpg" alt="DVmGvQ.jpg" style="zoom:67%;" />

# PASS-07（点绕过）

## 1.分析

```php
$is_upload = false;
$msg = null;
if (isset($_POST['submit'])) {
    if (file_exists(UPLOAD_PATH)) {
        $deny_ext = array(".php",".php5",".php4",".php3",".php2",".html",".htm",".phtml",".pht",".pHp",".pHp5",".pHp4",".pHp3",".pHp2",".Html",".Htm",".pHtml",".jsp",".jspa",".jspx",".jsw",".jsv",".jspf",".jtml",".jSp",".jSpx",".jSpa",".jSw",".jSv",".jSpf",".jHtml",".asp",".aspx",".asa",".asax",".ascx",".ashx",".asmx",".cer",".aSp",".aSpx",".aSa",".aSax",".aScx",".aShx",".aSmx",".cEr",".sWf",".swf",".htaccess");
        $file_name = trim($_FILES['upload_file']['name']);
        $file_ext = strrchr($file_name, '.');
        $file_ext = strtolower($file_ext); //转换为小写
        $file_ext = str_ireplace('::$DATA', '', $file_ext);//去除字符串::$DATA
        $file_ext = trim($file_ext); //首尾去空
        
        if (!in_array($file_ext, $deny_ext)) {
            $temp_file = $_FILES['upload_file']['tmp_name'];
            $img_path = UPLOAD_PATH.'/'.$file_name;
            if (move_uploaded_file($temp_file, $img_path)) {
                $is_upload = true;
            } else {
                $msg = '上传出错！';
            }
        } else {
            $msg = '此文件类型不允许上传！';
        }
    } else {
        $msg = UPLOAD_PATH . '文件夹不存在,请手工创建！';
    }
}
```

从代码上看，虽然加上了首位去空，但是缺少尾部去点，因此可以利用windows文件命名规则绕过。

## 2.绕过方法

burpsuite中改包加上.

<img src="https://s3.ax1x.com/2020/11/17/DVm8gg.jpg" alt="DVm8gg.jpg" style="zoom:67%;" />

# PASS-08（::$DATA绕过）

## 1.分析

```php
$is_upload = false;
$msg = null;
if (isset($_POST['submit'])) {
    if (file_exists(UPLOAD_PATH)) {
        $deny_ext = array(".php",".php5",".php4",".php3",".php2",".html",".htm",".phtml",".pht",".pHp",".pHp5",".pHp4",".pHp3",".pHp2",".Html",".Htm",".pHtml",".jsp",".jspa",".jspx",".jsw",".jsv",".jspf",".jtml",".jSp",".jSpx",".jSpa",".jSw",".jSv",".jSpf",".jHtml",".asp",".aspx",".asa",".asax",".ascx",".ashx",".asmx",".cer",".aSp",".aSpx",".aSa",".aSax",".aScx",".aShx",".aSmx",".cEr",".sWf",".swf",".htaccess");
        $file_name = trim($_FILES['upload_file']['name']);
        $file_name = deldot($file_name);//删除文件名末尾的点
        $file_ext = strrchr($file_name, '.');
        $file_ext = strtolower($file_ext); //转换为小写
        $file_ext = trim($file_ext); //首尾去空
        
        if (!in_array($file_ext, $deny_ext)) {
            $temp_file = $_FILES['upload_file']['tmp_name'];
            $img_path = UPLOAD_PATH.'/'.date("YmdHis").rand(1000,9999).$file_ext;
            if (move_uploaded_file($temp_file, $img_path)) {
                $is_upload = true;
            } else {
                $msg = '上传出错！';
            }
        } else {
            $msg = '此文件类型不允许上传！';
        }
    } else {
        $msg = UPLOAD_PATH . '文件夹不存在,请手工创建！';
    }
}
```

依然是黑名单，但是没有对后缀名去“::$DATA”处理，利用windows特性，在后缀名中加上“::$DATA”绕过。

## 2.DATA为什么能绕过

NTFS文件系统包括对备用数据流的支持。这不是众所周知的功能，主要包括提供与Macintosh文件系统中的文件的兼容性。备用数据流允许文件包含多个数据流。每个文件至少有一个数据流。在Windows中，此默认数据流称为：$
DATA。
简单讲就是在php+windows的情况下：如果文件名+"::$DATA" 会把::DATA之后的数据当成文件流处理,不会检测后缀名.且保持"::$DATA"之前的文件名。

## 3.绕过方法

使用burpsuite改包，在后缀名中加上"::$DATA"

![DV4eQ1.jpg](https://s3.ax1x.com/2020/11/17/DV4eQ1.jpg)

# PASS-09（点空格点绕过）

## 1.分析

```php
$is_upload = false;
$msg = null;
if (isset($_POST['submit'])) {
    if (file_exists(UPLOAD_PATH)) {
        $deny_ext = array(".php",".php5",".php4",".php3",".php2",".html",".htm",".phtml",".pht",".pHp",".pHp5",".pHp4",".pHp3",".pHp2",".Html",".Htm",".pHtml",".jsp",".jspa",".jspx",".jsw",".jsv",".jspf",".jtml",".jSp",".jSpx",".jSpa",".jSw",".jSv",".jSpf",".jHtml",".asp",".aspx",".asa",".asax",".ascx",".ashx",".asmx",".cer",".aSp",".aSpx",".aSa",".aSax",".aScx",".aShx",".aSmx",".cEr",".sWf",".swf",".htaccess");
        $file_name = trim($_FILES['upload_file']['name']);
        $file_name = deldot($file_name);//删除文件名末尾的点
        $file_ext = strrchr($file_name, '.');
        $file_ext = strtolower($file_ext); //转换为小写
        $file_ext = str_ireplace('::$DATA', '', $file_ext);//去除字符串::$DATA
        $file_ext = trim($file_ext); //首尾去空
        
        if (!in_array($file_ext, $deny_ext)) {
            $temp_file = $_FILES['upload_file']['tmp_name'];
            $img_path = UPLOAD_PATH.'/'.$file_name;
            if (move_uploaded_file($temp_file, $img_path)) {
                $is_upload = true;
            } else {
                $msg = '上传出错！';
            }
        } else {
            $msg = '此文件类型不允许上传！';
        }
    } else {
        $msg = UPLOAD_PATH . '文件夹不存在,请手工创建！';
    }
}
```

黑名单类型，有大小写处理，去::$DATA处理，首尾去空处理，去点处理。但是这里的代码逻辑是先删除文件末尾的点，再进行首尾去空。都只进行一次。所以可以在后缀名中加上点空格点绕过。

上传时，代码会先将末尾的.去除，剩余.+空格，利用windows文件命名规则，windows会忽略文件末尾的.和空格。

## 2.绕过方法

使用burpsuite改包

<img src="https://s3.ax1x.com/2020/11/17/DV4VzR.jpg" alt="DV4VzR.jpg" style="zoom:67%;" />

# PASS-10（双写绕过）

## 1.分析

```php
$is_upload = false;
$msg = null;
if (isset($_POST['submit'])) {
    if (file_exists(UPLOAD_PATH)) {
        $deny_ext = array("php","php5","php4","php3","php2","html","htm","phtml","pht","jsp","jspa","jspx","jsw","jsv","jspf","jtml","asp","aspx","asa","asax","ascx","ashx","asmx","cer","swf","htaccess");

        $file_name = trim($_FILES['upload_file']['name']);
        $file_name = str_ireplace($deny_ext,"", $file_name);
        $temp_file = $_FILES['upload_file']['tmp_name'];
        $img_path = UPLOAD_PATH.'/'.$file_name;        
        if (move_uploaded_file($temp_file, $img_path)) {
            $is_upload = true;
        } else {
            $msg = '上传出错！';
        }
    } else {
        $msg = UPLOAD_PATH . '文件夹不存在,请手工创建！';
    }
}
```

| str_ireplace()函数 |                                          |
| ------------------ | ---------------------------------------- |
| 功能               | 替换字符串中的一些字符（不区分大小写）。 |

这里将文件的后缀名替换为空，于是可以利用双写绕过。

## 2.绕过方法

我们可以使用双写后缀绕过，如果将后缀改为pphphp，服务器端检出到中间的php会替换为空，剩下的正好组成php，但是改为pphhpp就不行，源代码只会把第一次出现相连的php替换为空。

<img src="https://s3.ax1x.com/2020/11/17/DZr4Zd.jpg" alt="DZr4Zd.jpg" style="zoom: 67%;" />

# 前十关总结

做了十关，我得到了一些结论，如果想要做好防御，开发的时候必须考虑：

|                                                          |      |
| -------------------------------------------------------- | ---- |
| 1.使用trim()函数移除字符串两端的空白字符或其他预定义字符 |      |
| 2.使用deldot()函数删除文件名末尾的点                     |      |
| 3.使用strtolow()函数将字符转为小写                       |      |
| 4.去除::$DATA字符串                                      |      |
| 5.使用trim()首尾去空                                     |      |

