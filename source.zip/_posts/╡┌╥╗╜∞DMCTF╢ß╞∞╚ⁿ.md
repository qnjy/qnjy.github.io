---
title: 第一届DMCTF夺旗赛题解
categories: writeup
abbrlink: f497d7e2
date: 2020-11-25 20:48:58
tags:
---

　　学网络安全，快一个月了，第一次参加的学校的网络安全比赛所做出来的题目<!--more-->

# Misc

## 1.fakezip

打开压缩包显示

<img src="https://s3.ax1x.com/2020/11/29/D6LwZj.jpg" alt="D6LwZj.jpg" style="zoom:50%;" />

使用ZipCenOp解密

<img src="https://s3.ax1x.com/2020/11/29/D6L0ds.jpg" alt="D6L0ds.jpg" style="zoom:50%;" />

打开压缩包里的文件查看是一串音乐符号

♬♬♬♭♬§¶♭♬♪♩♩♯=

使用以下网站解密

https://www.qqxiuzi.cn/bianma/wenbenjiami.php?s=yinyue

## 2.Base family

首先要了解{% post_link 常见的密码类型 %}

打开见到是一串

```
XUZbB{fp}U)=ql[n%GCbk9RZ7!XD$D)f1G{011LN(TSlXCJT:4nxQ[8Y#I:=k.Qi4t3/S!,N/%[I}^8jjP|0&whvi88gpQce(2lKt9ZHiT^g1.nZH,k=kjTT16pHJ_DrW,Td"^w$Q8+8T])e.llK?*z`gS:+C]llUG:z1=ekEN}8DmJf&GP<Rk:o_Jk<J.zp8%H0g7sYSTJ9p."duRBGj`g0!I+xjm(fh)]IF:>omN8=m+Xp(X0:U*8Sj5|8p._o[i0:%.qu}%_=<D
```

这种类型是base91类型的编码，于是开始解码

```
3G6MzYGwFwTsqcb3MWzTdQBTHZWBZ2LUBprZ3P62T2nsbt1R7o6a7PEsXsBvSFvoexeZJEkhW9Wv1VusvpWK1nfWsVHDypW2j3MMEygzSYLmwxKV5kNwWomvXc5ohX2Jgj6bMRnu6JXkasXdbbw3Aw8Pvh6vWwPfTZ4mpkpNU9fDhyNi1bciCZMXeLiCWL67BVupHPobQcFWkpftgLPggB8wgwW
```

这里我卡了很长时间，我在网站上搜base家族的所有编码类型都不能解码，然后下载工具[basecrack](http://www.360doc.com/content/20/1003/09/11604731_938617176.shtml)才通过base58解码得到

```
JZVFSMSZPJMXQTTKMMZVS2TDGVGXUQJTJZKFM3KONJCTEWL2MN4U26SNGJGVIWJQJZ5GWMK2NJNGSTTNKV5E2RDDGNHFOWJTJZCFSNCNPJGTCWTKKF4U42SFGNGXUWJRJZVFSMSNKRNGWTL2IUZFS6TDGVHDEUJ5
```

然后继续base32解码

```
NjY2YzYxNjc3Yjc5MzA3NTVmNjE2YzcyMzM2MTY0Nzk1ZjZiNmUzMDc3NWY3NDY4MzM1ZjQyNjE3MzY1NjY2MTZkMzE2Yzc5N2Q=
```

继续base64解码

```
666c61677b7930755f616c72336164795f6b6e30775f7468335f4261736566616d316c797d
```

继续base16解码

```
flag{y0u_alr3ady_kn0w_th3_Basefam1ly}
```

## 3.编码之王

打开显示的是一串社会主义价值观字符

http://ctf.ssleye.com/cvencode.html

使用这个网址解码

<img src="https://s3.ax1x.com/2020/11/29/D6OFOg.jpg" alt="D6OFOg.jpg" style="zoom:50%;" />

得到一串如是我闻什么的，继续使用

http://www.keyfc.net/bbs/tools/tudoucode.aspx

<img src="https://s3.ax1x.com/2020/11/29/D6Oi6S.jpg" alt="D6Oi6S.jpg" style="zoom:50%;" />

又得到新佛曰开头的字符串

http://hi.pcmoe.net/buddha.html

<img src="https://s3.ax1x.com/2020/11/29/D6LzFI.jpg" alt="D6LzFI.jpg" style="zoom:50%;" />

最后控制台输入这段字符

<img src="https://s3.ax1x.com/2020/11/29/D6OPl8.jpg" alt="D6OPl8.jpg" style="zoom:50%;" />

## 4.SSTV

先来看什么是sstv，百度搜索是：

**慢扫描电视**（**Slow-scan television**）是[业余无线电](https://baike.baidu.com/item/业余无线电)爱好者的一种主要图片传输方法，慢扫描电视通过[无线电](https://baike.baidu.com/item/无线电)传输和接收单色或彩色静态图片。

首先要安装工具QSSTV

```
apt-get install qsstv
```

用qsstv打开文件，根据下图操作

<img src="https://s3.ax1x.com/2020/11/27/DDgEEn.jpg" alt="DDgEEn.jpg" style="zoom:50%;" />

开始

<img src="https://s3.ax1x.com/2020/11/27/DDgVNq.jpg" alt="DDgVNq.jpg" style="zoom:50%;" />

## 5.SlientEye

使用工具slienteye，解码出来之后得到htmlentity字符，再解码得到flag

## 6.Steghide

在kali使用steghide工具

查看文件中的信息

```
steghide info 1.jpg
```

<img src="https://s3.ax1x.com/2020/11/27/DDgmCV.jpg" alt="DDgmCV.jpg"  />

输入密码后可以看到嵌入的flag.txt，提取图片中的隐藏文件

```
steghide extract -sf 1.jpg
```

<img src="https://s3.ax1x.com/2020/11/27/DDgZ40.jpg" alt="DDgZ40.jpg"  />

<img src="https://s3.ax1x.com/2020/11/27/DDglDJ.jpg" alt="DDglDJ.jpg" style="zoom:50%;" />

但是并不知道这是什么意思，之后就没有思路了

## 7.Whitespace

使用ZipCenOp检测是否伪加密

```
java -jar ZipCenOp.jar r XXX.zip
```

![DDgQu4.jpg](https://s3.ax1x.com/2020/11/27/DDgQu4.jpg)

成功

## 8.outguess

在kali使用outguess工具

```
outguess -r xxx.jpg xxx.txt
```

![DDgKvF.jpg](https://s3.ax1x.com/2020/11/27/DDgKvF.jpg)

文件信息成功读取

![DDgugU.jpg](https://s3.ax1x.com/2020/11/27/DDgugU.jpg)

上面的开始也没有头绪，但是推测应该是句话，所以使用[凯撒解码](https://www.qqxiuzi.cn/bianma/kaisamima.php)解码位移量为13得到

![DDgn3T.jpg](https://s3.ax1x.com/2020/11/27/DDgn3T.jpg)

所以AES解密

http://tool.chacuo.net/cryptaes

<img src="https://s3.ax1x.com/2020/11/27/DDgkHs.jpg" alt="DDgkHs.jpg" style="zoom:50%;" />



## 9.ARCHPR

打开安装包

<img src="https://s3.ax1x.com/2020/11/29/D6OSYt.jpg" alt="D6OSYt.jpg" style="zoom:50%;" />

设置好参数

<img src="https://s3.ax1x.com/2020/11/29/D6OpfP.jpg" alt="D6OpfP.jpg" style="zoom:50%;" />

拿到

<img src="https://s3.ax1x.com/2020/11/29/D6OCSf.jpg" alt="D6OCSf.jpg" style="zoom:50%;" />

拿到这个题其中的txt文件，显示

<img src="https://s3.ax1x.com/2020/11/28/DyZRl4.jpg" alt="DyZRl4.jpg" style="zoom:50%;" />

这个是很常见的摩斯电码，解码就是PASSWORD，但是第一行文字提醒将他转换成小写

提示lsb隐写，所以使用[cloacked-pixel](https://github.com/livz/cloacked-pixel)工具

这里我卡了很长时间，运行这个工具总是提醒下面信息

<img src="https://s3.ax1x.com/2020/11/28/DyZ2pF.jpg" alt="DyZ2pF.jpg" style="zoom:50%;" />

后来搜寻了一番之后才知道，这个工具是在python2下面编写的，而我电脑上安装的是python3，所以又在环境变量上花了很长时间，具体见{%post_link cloacked-pixel艰难使用%}

成功装好之后，拿到flag

![DyZDwq.jpg](https://s3.ax1x.com/2020/11/28/DyZDwq.jpg)

## 10.Collision

看到名字是碰撞的意思，然后在百度搜索ctf碰撞，出来很多信息，然后拿来大佬写的脚本，结果不能用，但是可以看到flag

<img src="https://s3.ax1x.com/2020/11/28/DyZykV.jpg" alt="DyZykV.jpg" style="zoom:50%;" />

猜测应该是字符集不够，之后又加了字符，

[![DyZrT0.jpg](https://s3.ax1x.com/2020/11/28/DyZrT0.jpg)](https://imgchr.com/i/DyZrT0)

拿到flag

<img src="https://s3.ax1x.com/2020/11/28/DyZBmn.jpg" alt="DyZBmn.jpg" style="zoom:50%;" />

以下是完整脚本

```python
import datetime
import binascii

def crack(crc_in):
	crcs = set([crc_in])

	r = '0123456789abcdefghijklmnopqrstuvwxyz*+/.-()ABCDEFGHIJKLMNOPQRSTUVWXYZ{}_[]\^`|~'
	for a in r:
		for b in r:
			for c in r:
				for d in r:
					txt = a+b+c+d
					crc = binascii.crc32(txt)
					if(crc & 0xFFFFFFFF) in crcs:
						return txt

if __name__ == "__main__":
	s = [0xD1F4EB9A,0x1E59A66E,0x77E8FD00,0x6C4A558B,0xFF92876D]
	password=''
	for x in s:
		passw = crack(x)
		password+=str(passw)
		print(password)
```

