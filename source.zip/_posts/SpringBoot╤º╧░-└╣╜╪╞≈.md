---
title: SpringBoot-拦截器
tags:
  - SpringBoot学习
categories: SpringBoot学习
abbrlink: e3a97206
date: 2021-01-12 20:44:23
---

　　SpringBoot学习，主要内容是拦截器，可以实现网站的登录功能<!--more-->

# 1.实现登录拦截

　　首先需要编写相应模块的类实现HandlerInterceptor，然后再拦截配置类里面编辑要拦截胡页面。

## 1.1 编写类实现HandlerInterceptor类

```java
public class UserInterceptor implements HandlerInterceptor{
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        //编写业务拦截的规则
        //从session中获取用户的信息
        User user = (User) request.getSession().getAttribute("user");

        //判断用户是否登录
        if (null == user) {
            //未登录
            response.sendRedirect(request.getContextPath() + "/nologin");
            return false;
        }
        return true;
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {

    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {

    }
}
```

　　实现HanderInterceptor，重写preHandle、postHandle、afterCompletion三个方法，先获取session的用户信息，然后判断是否登录。

## 1.2 声明拦截配置类

```java
@Configuration
//定义此类为配置文件
public class InterceptorConfig implements WebMvcConfigurer {

    @Override
    public void addInterceptors(InterceptorRegistry registry) {

        //要拦截user下的所有访问请求，必须用户登录后才能访问
        String[] addPathPatterns = {
            "/user/**"
        };

        //排除路径，排除的路径说明不需要用户登录也可以访问
        String[] excludePathPatterns = {
            "/user/out","/user/error","/user/login"
        };

        registry.addInterceptor(new UserInterceptor()).addPathPatterns(addPathPatterns).excludePathPatterns(excludePathPatterns);
    }
}
```

　　需要实现WebMvcConfigurer，重写addInterceptors方法，在里面配置需要拦截的请求和排除的请求。

## 1.3 编写Controller类进行验证

```java
@Controller
@RequestMapping(value = "/user")
public class UserController {

    @RequestMapping(value = "/login")
    public @ResponseBody Object login(HttpServletRequest request, HttpServletResponse response){
        //将user用户存入session
        User user = new User();
        user.setId(1001);
        user.setUsername("zhangsan");
        request.getSession().setAttribute("user",user);

        return "login SUCCESS";
    }

    //登录成功才能看到的信息
    @RequestMapping(value = "/center")
    public @ResponseBody Object center(){
        return "See Center Message";
    }

    //不用登录就能看到的信息
    @RequestMapping(value = "/out")
    public @ResponseBody Object out(){
        return "See Out Message";
    }

    //如果用户未登录访问了需要登录才可访问的请求，才会出错
    @RequestMapping(value = "/error")
    public @ResponseBody Object error(){
        return "error";
    }
}
```

# 2.在SpringBoot框架下使用Servlet

* 第一种方式

  在主程序入口处加上@ServletComponentScan注解，然后正常使用@WebServlet注解

* 第二种方式

  使用@Configuration注解定义一个配置类

  