---
title: Hadoop集群环境搭建2
categories: 环境搭建
abbrlink: 4496e9f0
date: 2020-11-30 13:04:48
tags:
---

　　之前写过一篇hadoop的搭建，见{%post_link Hadoop集群环境搭建1%}，但是这个是先安装好每台虚拟机再配置文件。所以，这篇文章采用的是克隆虚拟机的方法，但是还是踩了很多坑，主要就是配置文件的问题，这个搭建完之后，能够简单计算PI的值和运行hadoop自带的包。但是在配置过程中仍然忘记设置虚拟机为静态，踩了很多坑，很烦！不过也了解了很多。<!--more-->

# 1.JDK和Hadoop环境安装

## (1) 新建目录存放JDK和Hadoop

在master中新建目录bigdata

```
# mkdir -p /opt/bigdata
```

将下载好的JDK包和Hadoop包上传至master主机中/opt/bigdata下

[![rPQrM6.jpg](https://s3.ax1x.com/2020/12/09/rPQrM6.jpg)](https://imgchr.com/i/rPQrM6)

## (2) 解压JDK和Hadoop

在bigdata目录下执行以下命令

```
# tar -zxvf jdk-8u131-linux-x64.tar.gz
```

[![rPQUIJ.jpg](https://s3.ax1x.com/2020/12/09/rPQUIJ.jpg)](https://imgchr.com/i/rPQUIJ)

```
# tar -zxvf hadoop.tar.gz
```

## (3) 配置JDK和Hadoop环境变量

```
vi /etc/profile
```

根据自己的路径在末尾添加以下内容

```
export JAVA_HOME=/opt/bigdata/jdk1.8.0_131
export CLASSPATH=.:$JAVA_HOME/lib/dt.jar:$JAVA_HOME/lib/tools.jar
export HADOOP_HOME=/opt/bigdata/hadoop-3.1.3
export PATH=.:$HADOOP_HOME/sbin:$HADOOP_HOME/bin:$JAVA_HOME/bin:$PATH
```

[![rPQ0R1.jpg](https://s3.ax1x.com/2020/12/09/rPQ0R1.jpg)](https://imgchr.com/i/rPQ0R1)

:wq保存退出

```
source /etc/profile
java -version #检验java是否配置成功
hadoop version #检验hadoop是否配置成功
```

[![rPQwGR.jpg](https://s3.ax1x.com/2020/12/09/rPQwGR.jpg)](https://imgchr.com/i/rPQwGR)



# 2.修改配置文件

首先创建以下目录，方便配置hadoop文件

```
mkdir /opt/bigdata/hadoop-3.1.3/tmp  		#用来存放临时文件
mkdir /opt/bigdata/hadoop-3.1.3/logs 		#用来存放日志文件
mkdir /opt/bigdata/hadoop-3.1.3/hdfs 		#用来存储集群数据
mkdir /opt/bigdata/hadoop-3.1.3/hdfs/name 	#用来存储文件系统元数据
mkdir /opt/bigdata/hadoop-3.1.3/hdfs/data 	#用来存储真正的数据
```

<font color="ff0000">进入目录，以下6个步骤文件都在此目录中</font>

```
cd /opt/bigdata/hadoop-3.1.3/etc/hadoop
```

我们需要  core-site.xml、hadoop-env.sh、hdfs-site.xml、mapred-site.xml进行配置

## (1) 配置hadoop-env.sh

```
vi hadoop-env.sh
```

查找JAVA_HOME配置的位置

```
:/export JAVA_HOME
```

输入JAVA_HOME的绝对路径

export JAVA_HOME=/opt/bigdata/jdk1.8.0_131（把前面的#注释去掉）

[![rPQdi9.jpg](https://s3.ax1x.com/2020/12/09/rPQdi9.jpg)](https://imgchr.com/i/rPQdi9)

## (2) 配置core-site.xml

```
vi core-site.xml
```

在修改为

```xml
<configuration>

<property>
<name>hadoop.tmp.dir</name>
<value>file:/opt/bigdata/hadoop-3.1.3/tmp</value>
<description>节点上本地的hadoop临时文件夹</description>
</property>

<property>
<name>fs.defaultFS</name>
<value>hdfs://master:9000</value>
<description>HDFS的默认名称</description>
</property>

</configuration>
```

## (3) 配置hdfs-site.xml

```
vi hdfs-site.xml
```

```xml
<configuration>
    
<property>
<name>dfs.replication</name>
<value>3</value>  
<description>副本个数，默认是3,应小于datanode机器数量</description>
</property>

<property>
<name>dfs.namenode.name.dir</name>
<value>file:/opt/bigdata/hadoop-3.1.3/hdfs/name</value>
<description>namenode上存储hdfs名字空间元数据 </description>
</property>

<property>
<name>dfs.datanode.data.dir</name>
<value>file:/opt/bigdata/hadoop-3.1.3/hdfs/data</value>
<description>datanode上数据块的物理存储位置</description>
</property>

<property>
<name>dfs.namenode.secondary.http-address</name>
<value>node2:9001</value>
</property>

</configuration>
```

## (4) 配置mapred-site.xml

```xml
<configuration>
    
<property>
<name>mapreduce.framework.name</name>
<value>yarn</value>
<description>指定mapreduce使用yarn框架</description>
</property>
    
<property>
<name>mapreduce.application.classpath</name>
<value>/opt/bigdata/hadoop-3.1.3/share/hadoop/mapreduce/*, /opt/bigdata/hadoop-3.1.3/share/hadoop/mapreduce/lib/*</value>
</property>
    
<property>
    <name>mapreduce.map.memory.mb</name>
    <value>1500</value>
    <description>每个Map任务的物理内存限制</description>
</property>
 
<property>
    <name>mapreduce.reduce.memory.mb</name>
    <value>3000</value>
    <description>每个Reduce任务的物理内存限制</description>
</property>
 
<property>
    <name>mapreduce.map.java.opts</name>
    <value>-Xmx1200m</value>
</property>
 
<property>
    <name>mapreduce.reduce.java.opts</name>
    <value>-Xmx2600m</value>
</property>
    
    
</configuration>
```

## (5) 配置yarn-site.xml

```xml
<configuration>
    
<property>
<name>yarn.resourcemanager.hostname</name>
<value>master</value>
<description>指定resourcemanager所在的hostname</description>
</property>
    
<property>
<name>yarn.nodemanager.aux-services</name>
<value>mapreduce_shuffle</value>
<description>NodeManager上运行的附属服务。需配置成mapreduce_shuffle，才可运行 MapReduce程序</description>
</property>
    
<property>
<name>yarn.log-aggregation-enable</name>
<value>false</value>
</property>
    
<property>
    <name>yarn.nodemanager.resource.memory-mb</name>
    <value>22528</value>
    <discription>每个节点可用内存,单位MB</discription>
</property>
 
<property>
    <name>yarn.scheduler.minimum-allocation-mb</name>
    <value>1500</value>
    <discription>单个任务可申请最少内存，默认1024MB</discription>
</property>
 
<property>
    <name>yarn.scheduler.maximum-allocation-mb</name>
    <value>16384</value>
    <discription>单个任务可申请最大内存，默认8192MB</discription>
</property>
    
</configuration>
```

## (6) 配置slavers

如果没有配置hosts，必须输入相应主机的ip地址，这里可以先填主机名，后面会配置hosts，hadoop会把配置在这里的主机当作datanode。hadoop3.0以后slaves更名为workers了，所以我们使用如下命令：

```
vi workers
```

删除

localhost

增加

node1

node2

node3

## (7) 修改start-dfs.sh等文件

需要进入hadoop安装目录下的sbin文件夹

1.对于start-dfs.sh和stop-dfs.sh文件，添加下列参数：

```
HDFS_DATANODE_USER=root  
HDFS_DATANODE_SECURE_USER=hdfs  
HDFS_NAMENODE_USER=root  
HDFS_SECONDARYNAMENODE_USER=root 
```

[![rPQnaQ.jpg](https://s3.ax1x.com/2020/12/09/rPQnaQ.jpg)](https://imgchr.com/i/rPQnaQ)

2.同样地，对于start-yarn.sh和stop-yarn.sh文件，添加下列参数：

```
#!/usr/bin/env bash
YARN_RESOURCEMANAGER_USER=root
HADOOP_SECURE_DN_USER=yarn
YARN_NODEMANAGER_USER=root
```

# 3.克隆虚拟机

<font color="ff0000">这里建议先使用以下vmware快照，在继续往下进行</font>

首先先关闭防火墙，再使用vmware的克隆功能，完整克隆master

```
systemctl status firewalld.service 		  #查看防火墙状态

systemctl stop firewalld.service	 	  #关闭防火墙

systemctl disable firewalld.service 	  #禁止防火墙
```

# 4.修改虚拟机host

## (1) 更改各主机名字

为了能够更方便的识别主机，将四台虚拟机的名字分别修改为master、node1、node2、node3

注意切换到root账户下

```
vi /etc/hostname  #编程hostname配置文件
```

[![rPQ1x0.jpg](https://s3.ax1x.com/2020/12/09/rPQ1x0.jpg)](https://imgchr.com/i/rPQ1x0)

点击Esc，再:wq保存退出

另外三个虚拟机同样操作更改名字

## (2) 开启主机的DHCP模式，自动获取ip地址

<font color="ff0000">不建议使用这个方法，使用静态IP配置的方法参考以下链接，动态IP的地址会改变，hosts文件得重新配置</font>

https://blog.csdn.net/weixin_42792088/article/details/107139833?utm_medium=distribute.pc_relevant.none-task-blog-baidulandingword-2&spm=1001.2101.3001.4242

```
vi /etc/sysconfig/network-scripts/ifcfg-ens33
```

[![rPQGrT.jpg](https://s3.ax1x.com/2020/12/09/rPQGrT.jpg)](https://imgchr.com/i/rPQGrT)

重启网卡

```
service network restart
```

在四台虚拟机中分别进行以上操作

之后输入ip addr，记下四个虚拟机的ip地址

[![rPQ8MV.jpg](https://s3.ax1x.com/2020/12/09/rPQ8MV.jpg)](https://imgchr.com/i/rPQ8MV)

| 主机名 | ip地址          |
| ------ | --------------- |
| master | 192.168.136.131 |
| node1  | 192.168.136.133 |
| node2  | 192.168.136.134 |
| node3  | 192.168.136.135 |

## (3) 配置hosts

在每台虚拟机上

配置hosts主要是为了让机器能够相互识别

*注：hosts文件是域名分析文件，在hosts文件内配置了ip地址和主机名的对应关系，配置之后，通过主机名，电脑就可以定位到相应的ip地址*

```
vi /etc/hosts
```

在hosts文件中输入一下内容：

[![rPQZqS.jpg](https://s3.ax1x.com/2020/12/09/rPQZqS.jpg)](https://imgchr.com/i/rPQZqS)

<font color="ff0000">注意要与实际ip和主机名对应</font>

## (4) SSH配置

```
ssh-keygen
```

ssh一路回车

[![rPQMPs.jpg](https://s3.ax1x.com/2020/12/09/rPQMPs.jpg)](https://imgchr.com/i/rPQMPs)

使用如下命令将公钥复制到node1、node2和node3节点中：

```
ssh-copy-id root@node1
ssh-copy-id root@node2
ssh-copy-id root@node3
```

[![rPQQGn.jpg](https://s3.ax1x.com/2020/12/09/rPQQGn.jpg)](https://imgchr.com/i/rPQQGn)

在master节点下输入试实验是否能免密登陆，第一次登陆可能需要输入密码

```
ssh node1
ssh node2
ssh node3
```

# 5.检查hadoop运行情况

<font color="ff0000">在master节点下执行以下操作</font>

1.格式化namenode

第一次启动集群，在master虚拟机的hadoop-3.1.3目录下执行

```
bin/hdfs namenode -format
```

如果多次格式化会出现错误，参考这篇文章https://blog.csdn.net/qq_41059374/article/details/80695581

2.启动

```
start-all.sh
```

3.检查进程

master

[![rPQVr8.jpg](https://s3.ax1x.com/2020/12/09/rPQVr8.jpg)](https://imgchr.com/i/rPQVr8)

node1

[![rPQF2t.jpg](https://s3.ax1x.com/2020/12/09/rPQF2t.jpg)](https://imgchr.com/i/rPQF2t)

node2

[![rPQi8I.jpg](https://s3.ax1x.com/2020/12/09/rPQi8I.jpg)](https://imgchr.com/i/rPQi8I)

node3

20

4. 进入管理页面

在浏览器地址栏中输入以下命令

| 界面         | 地址                  |
| ------------ | --------------------- |
| 管理页面     | http://localhost:8088 |
| NameNode界面 | http://localhost:9870 |

[![rPQu5j.jpg](https://s3.ax1x.com/2020/12/09/rPQu5j.jpg)](https://imgchr.com/i/rPQu5j)

[![rPQmVg.jpg](https://s3.ax1x.com/2020/12/09/rPQmVg.jpg)](https://imgchr.com/i/rPQmVg)

# 6.Hadoop运行实例

## (1) 运行wordcount

进入hadoop-3.1.3目录

(1) 创建Input文件夹

```
# hdfs dfs -mkdir /Input
```

(2) 将hadoop-3.1.3下已经存在的LICENSE.txt文件上传到hdfs的/Input目录下

```
# hdfs dfs -put LICENSE.txt /Input
```

查看已经上传成功

```
hdfs dfs -ls /Input
```

[![rPQEKf.jpg](https://s3.ax1x.com/2020/12/09/rPQEKf.jpg)](https://imgchr.com/i/rPQEKf)

(3) 运行hadoop安装包中自带的wordcount程序

运行share/hadoop/mapreduce/hadoop-mapreduce-examples-3.1.3.jar这个java程序，调用wordcount方法

```
# hadoop jar share/hadoop/mapreduce/hadoop-mapreduce-examples-3.1.3.jar wordcount /Input/LICENSE.txt /Input/Output
```

[![rPr5qg.jpg](https://s3.ax1x.com/2020/12/10/rPr5qg.jpg)](https://imgchr.com/i/rPr5qg)

(4) 查看云端的/Output/part-r-00000文件

```
hdfs dfs -cat /Output/part-r-00000
```

[![rPrRRP.jpg](https://s3.ax1x.com/2020/12/10/rPrRRP.jpg)](https://imgchr.com/i/rPrRRP)

## (2) 计算PI的值

start-all.sh启动集群后

<font color="ff0000">进入hadoop-3.1.3的目录</font>

```
hadoop jar share/hadoop/mapreduce/hadoop-mapreduce-examples-3.1.3.jar pi 1 1
```

Hadoop计算PI的方法属于是采用大量采样的统计学方法，还是属于数据密集型的工作，如果最后两个1改的越大，计算的越慢，但是结果越准确。

[![rPrhM8.jpg](https://s3.ax1x.com/2020/12/10/rPrhM8.jpg)](https://imgchr.com/i/rPrhM8)

[![rPrWxf.jpg](https://s3.ax1x.com/2020/12/10/rPrWxf.jpg)](https://imgchr.com/i/rPrWxf)

