---
title: JDBC使用
tags:
  - JDBC
categories: JavaWeb学习
abbrlink: b6296e7c
date: 2020-11-15 21:18:45
---

　　全称为：Java Data Base Connectivity（java数据库连接），可以为多种数据库提供填统一的访问。JDBC是sun开打的一套数据库访问编程接口。<!--more-->

# JDBC的主要功能

* 建立与数据库或者其他数据源的连接
* 向数据库发送SQL命令
* 处理数据库的返回结果

# JDBC中常用类和接口

## 1.连接到数据库（Connection）

Connection对象代表与数据库的连接。连接过程包括所执行的SQL语句和在改连接上所返回的结果。一个应用程序可与单个数据库有一个或多个连接，或者可与很多数据库有链接。打开连接与数据库建立连接的标准方法是调用DriverManager.getConnection()方法。

```java
String url="jdbc:mysql://127.0.0.1:3306/bjpowernode";

String user="root";

String password="root";

DriverManager.getConnection(url,user,password);
```

## 2.建立操作指令（Statement）

Statement对象用于将SQL语句发送到数据库中。实际上有三种Statement对象，他们都作为在给定连接上执行SQL语句的包容器：Statement、PreparedStatement（继承Statement）和CallableStatement（继承PreparedStatement）。他们都用于发送特定类型的SQL语句：

（1）Statement对象用于执行不带参数的简单的SQL语句；Statement接口提供了执行语句和获取结果的基本方法。

（2）PreparedStatement对象用于执行带或不带IN参数的预编译SQL语句；PreparedStatement接口添加处理IN参数的方法。

（3）CallableStatement对象用于执行对数据库已存储过程的调用；CallableStatement添加处理OUT参数的方法。

**Statement提供了许多方法，最常用的方法如下：**

| 方法            | 作用                                                 |
| --------------- | ---------------------------------------------------- |
| execute()       | 运行语句，返回是否有结果集                           |
| executeQuery()  | 运行查询（select）语句，返回ResultSet对象            |
| executeUpdata() | 运行更新（update/insert/delete）语句，返回更新的行数 |
| addBatch()      | 增加批处理语句                                       |
| executeBatch()  | 执行批处理语句                                       |
| clearBatch()    | 清楚批处理语句                                       |

## 3.结果集合类（ResultSet）

ResultSet包含符合SQL语句中条件的所有行记录，并且它通过一套get方法提供了对这些行中数据的访问。ResultSet.next()方法用于移动到ResultSet中的下一行，使下一行成为当前行。

# JDBC编程步骤

## 1.加载驱动程序：Class.forName(DriverClass)

加载mysql驱动：

```java
Class.forName("com.mysql.jdbc.Driver")
```

<font color="ff0000">注意mysql8.0以上版本的是:</font> com.mysql.cj.jdbc.Driver

## 2.获得数据库链接：DriverManager.gerConnection()

```java
DriverManager.getConnection("jdbc:mysql://localhost:3306/bjpowernode?useUnicode=true&characterEncoding=utf-8&useSSL=false&serverTimezone=GMT%2B8","root","root");
```

## 3.创建Statement对象：conn.createStatement()

## 4.向数据库发送SQL命令，执行SQL语句

## 5.处理查询结果集（只有第四步执行select语句，才有这一步）

## 6.释放资源（java和数据库之间的通信，一定关闭）

# 代码实例演示

## 1.编程步骤的具体代码

<font color="ff0000">我的mysql版本是8.0，注意5.0版本和8.0版本之间的变化</font>

****

```java
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class javaTest {

    public static void main(String[] args) throws ClassNotFoundException, SQLException  {
        String URL="jdbc:mysql://127.0.0.1:3306/imooc?useUnicode=true&characterEncoding=utf-8";
        String USER="root";
        String PASSWORD="tiger";
        //1.加载驱动程序
        Class.forName("com.mysql.jdbc.Driver");
        //2.获得数据库链接
        Connection conn=DriverManager.getConnection(URL, USER, PASSWORD);
        //3.通过数据库的连接操作数据库，实现增删改查（使用Statement类）
        Statement st=conn.createStatement();
        ResultSet rs=st.executeQuery("select * from user");
        //4.处理数据库的返回结果(使用ResultSet类)
        while(rs.next()){
            System.out.println(rs.getString("user_name")+" "
                          +rs.getString("user_password"));
        }

        //关闭资源
        rs.close();
        st.close();
        conn.close();
    }
}
```

## 2.JDBC工具类

```java

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * JDBC工具类？
 *      一、增删改的通用方法
 *      二、查询的通用方法
 *      三、关闭的通用方法
 */
public class DBUtil {

    static {
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

     public static Connection getConnection(){
         try {
             return DriverManager.getConnection("jdbc:mysql://localhost:3306/qy66?characterEnconding=UTF-8", "root", "root");
         } catch (SQLException e) {
             e.printStackTrace();
         }
         return null;
     }
     /** 增删改的通用方法
     * @paramString sql  要执行的sql
      * @paramObject[] obj    对象类型的数组  里面存放着 sql执行的占位符参数
      *               【name，age，id】
     *                【id】
      *               【name，age】
      *         Object... 可变参数
     * */
    public static boolean executeUpdate(String sql,Object... args){
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            conn = getConnection();
            ps = conn.prepareStatement(sql);

            for (int i=0;i<args.length;i++){
                ps.setObject(i+1,args[i]);
            }
            int i = ps.executeUpdate();

            if (i>0)
                return true;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            //关闭
            close(conn,ps,null);
        }
        return false;
    }

    /**
     * 查询的通用方法
     * @param sql
     * @param args
     * @return
     */
    public static List<Map<String,Object>> executeQuery(String sql,Object... args){ //可变参数  Object... args
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet set = null;
        try {
            conn = DBUtil.getConnection();
            ps = conn.prepareStatement(sql);
            /* 有可能有参数 */
            for (int i=0;i<args.length;i++){
                ps.setObject(i+1,args[i]);
            }
            /*执行*/
            set = ps.executeQuery();
            /*需要将所有数据都存放到 List中    每一行 用一个 map存放*/
            List<Map<String,Object>> list = new ArrayList<>();
            /*获取本次查询结果集有多少列*/
            int count = set.getMetaData().getColumnCount();

            while(set.next()){
                Map<String, Object> map = new HashMap<>();//一行数据 用一个map 接收
                /*
                我们不用在乎数据库表中有几列
                通过  getMetData().getColumnLabel() 获取列
                因为用的map键值对集合  得到了列  就能得到相应的values值

                 */
                for(int i=0;i<count;i++){
                    String name = set.getMetaData().getColumnLabel(i+1);
                    map.put(name,set.getObject(name));
                }
                /*将每行的map存放到 List中*/
                list.add(map);
            }
            return list;
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            close(conn,ps,set);
        }
        return null;
    }

    /** 关闭的通用方法
    *       先进后出的原则
    * */
    private static void close(Connection conn,PreparedStatement st,ResultSet set){
        try {
            if(set!=null){
                set.close();
            }
            if(st!=null){
                st.close();
            }
            if(conn != null){
                conn.close();
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }
】
}
```

## 3.JDBC增删改查功能的实现

```java
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class JDBCTest06 {
    public static void main(String[] args) {
        Connection conn = null;
        PreparedStatement ps = null;
        try{
            //1.驱动注册
            Class.forName("com.mysql.cj.jdbc.Driver");
            //2.获取连接
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bjpowernode?useUnicode=true&characterEncoding=utf-8&useSSL=false&serverTimezone=GMT%2B8","root","root");
            //3.获取预编译的数据库操作对象

            //增
/*
            String sql = "insert into dept(deptno,dname,loc) values(?,?,?)";
            ps = conn.prepareStatement(sql);
            ps.setInt(1,60);
            ps.setString(2,"销售部");
            ps.setString(3,"上海");
*/


            //改
/*
            String sql = "update dept set dname = ?, loc = ? where deptnp = ?";
            ps = conn.prepareStatement(sql);
            ps.setString(2,"研发一部");
            ps.setString(3,"北京");
            ps.setInt(1,60);

 */

            //删
/*
            String sql = "delete from dept where deptno = ?";
            ps = conn.prepareStatement(sql);
            ps.setInt(1,60);
 */

            //4.执行SQL语句
            int count = ps.executeUpdate();
            System.out.println(count);

        }catch(Exception e){
            e.printStackTrace();
            //6.释放资源
        }finally{
            if (ps != null){
                try{
                    ps.close();
                }catch (SQLException e){
                    e.printStackTrace();
                }
            }

            if(conn != null){
                try{
                    conn.close();
                }catch (SQLException e){
                    e.printStackTrace();
                }
            }
        }
    }
}
```

## 4.使用配置文件工具类

需要在文件名为db.properties的文件写入以下信息：

```properties
driverClassName=com.mysql.cj.jdbc.Driver
url=jdbc:mysql://localhost:3306/bjpowernode?useUnicode=true&charaterEncoding=utf-8&useSSL=false&serverTimezone=GMT%2B8
user=root
password=root
```

<font color="ff0000">注意：</font>5.0版本和8.0版本之间的变化</font>

```java
public class JDBCUtil {
    private static String driver;
    private static String url;
    private static String username;
    private static String password;

    //静态代码块，在程序编译的时候执行
    static {
        try {
            //创建Properties对象
            Properties p = new Properties();
            //获取文件输入流
            InputStream in = new FileInputStream("db.properties");
            //加载输入流
            p.load(in);
            //获取数据库连接驱动名字
            driver = p.getProperty("driverClassName",null);
            //获取数据库连接地址
            url = p.getProperty("url",null);
            //获取数据库连接用户名
            username = p.getProperty("username",null);
            //获取数据库连接密码
            password = p.getProperty("password",null);
            if(driver != null && url != null
                    && username != null && password != null){
                //加载驱动
                Class.forName(driver);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 获取连接对象
     * @return Connection连接对象
     */
    public static Connection getConn(){
        Connection conn = null;
        try {
            conn = DriverManager.getConnection(url,username,password);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return conn;
    }

    /**
     * 关闭连接（Connection连接对象必须在最后关闭）
     * @param conn Connection连接对象
     * @param st 编译执行对象
     * @param rs 结果集
     */
    public static void close(Connection conn, Statement st, ResultSet rs){
        try {
            if(rs != null){
                rs.close();
            }
            if(st != null){
                st.close();
            }
            if(conn != null){
                conn.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
```

# mysql8.0和mysql5.7链接时候的区别

```java
//mysql5.7
jdbc.river=com.mysql.jdbc.Driver

jdbc.url="jdbc:mysql://ip:3306/db?characterEncoding=utf-8"
//mysql8.0
jdbc.driver=com.mysql.cj.jdbc.Driver
    
Jdbc.url="jdbc：mysql：//ip:3306/db?useUnicode=true&characterEncoding=utf-8&useSSL=false&serverTimezone=GMT%2B8"
```

![DFcxPK.jpg](https://s3.ax1x.com/2020/11/15/DFcxPK.jpg)

