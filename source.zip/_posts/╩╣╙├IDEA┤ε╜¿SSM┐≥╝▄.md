---
title: 使用IDEA搭建SSM框架
tags:
  - SSM
categories: javaWeb学习
abbrlink: e2e0c666
date: 2020-11-29 10:24:20
---

　　刚学习过SSM，记录一下如何创建项目<!--more-->

# IDEA新建项目

## 1.创建Maven工程

![DcELCT.md.jpg](https://s3.ax1x.com/2020/11/29/DcELCT.md.jpg)

## 2.填写GroupID和ArtifactId

![DcEO8U.jpg](https://s3.ax1x.com/2020/11/29/DcEO8U.jpg)

## 3.填写项目名称

![DcEX2F.md.jpg](https://s3.ax1x.com/2020/11/29/DcEX2F.md.jpg)

## 4.刚建好的只是一个Maven目录

![DcEjv4.jpg](https://s3.ax1x.com/2020/11/29/DcEjv4.jpg)

最后再完善目录结构，添加webapp、WEB-INF、web.xml文件就可以了

