---
title: MyBatis框架
abbrlink: 669b9acc
date: 2021-03-04 17:09:59
tags:
categories:
---

# 第一章

## 1.1 三层架构

| 架构层     | 作用                                                         | 对应的包                  | 对应的处理框架 |
| ---------- | :----------------------------------------------------------- | ------------------------- | -------------- |
| 界面层     | 和用户打交道的，接受用户的请求参数，显示处理结果（jsp，html，servlet） | controller包（servlet）   | springmvc      |
| 业务逻辑层 | 接受了界面层传递的数据，计算逻辑，调用数据库，获取数据       | service包（XXXService类） | spring         |
| 数据访问层 | 访问数据库，执行对数据的查询，修改，删除等的等等             | dao包（XXXDao）           | mybatis        |

<!--more-->三层中类的交互：用户使用界面层-->业务逻辑层-->数据访问层（持久层）-->数据库（mysql）

## 1.2 JDBC编程

### 1.2.1 JDBC编程的回顾

```java
public void fidStudent(){
    Connection conn = null;
    Statement stmt = null;
    ResultSet rs = null;
    try{
        //注册mysql驱动
        Class.forName("com.mysql.jdbc.Driver");
        //连接数据库的基本信息url，username，password
        String url = "jdbc:mysql://localhost:3306/springdb";
        String username = "root";
        String password = "root";
        //创建连接对象
        conn = DriverManager.getConnection(url,username,password);
        //保存查询结果
        List<Student> stuList = new ArrayList<>();
        //创建Statement，用来执行sql语句
        stmt = conn.createStatement();
        //执行查询，创建记录集
        rs = stmt.executeQuery("select * from student");
        while(rs.next()){
            Student stu = new Student();
            stu.setId(rs.getInt("id"));
            stu.setName(rs.getString("name"));
            //从数据库取出数据转为Student对象，封装到List集合
            stuList.add(stu);
        }
    }catch(Exception e){
        e.printStackTrace();
    }finally{
        try{
            //关闭资源
            if(rs != null){
                rs.close();
            }

            if(stmt != null){
                stmt.close();
            }

            if(conn != null){
                conn.close();
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
```

### 1.2.2 使用JDBC的缺陷

1.代码比较多，开发效率低

2.需要关注Connection，Statement，ResultSet对象的创建和销毁

3.对ResultSet查询的结果，需要自己封装为List

4.代码重复高

5.业务代码和数据库操作混在一起