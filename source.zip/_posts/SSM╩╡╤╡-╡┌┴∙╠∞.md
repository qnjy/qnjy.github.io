---
title: SSM实训-第六天
abbrlink: 80a5d534
date: 2022-06-22 11:51:50
tags:
categories:
---

# 1 管理员模块编写

1 数据表设计<!--more-->

```mysql
CREATE TABLE `admin` (
  `adminid` int(11) NOT NULL AUTO_INCREMENT,
  `adminusername` varchar(255) DEFAULT NULL COMMENT '账号 名字缩写+id',
  `adminname` varchar(255) DEFAULT NULL COMMENT '姓名',
  `adminphone` varchar(255) NOT NULL COMMENT '手机号',
  `adminpassword` varchar(255) NOT NULL DEFAULT '123456' COMMENT '密码 初始123456',
  `adminbirth` varchar(255) DEFAULT NULL COMMENT '出生年月',
  `adminage` int(11) DEFAULT NULL COMMENT '年龄',
  `adminemail` varchar(255) DEFAULT NULL COMMENT '邮箱',
  `adminsex` varchar(255) DEFAULT NULL COMMENT '性别',
  `admincreatedtime` varchar(255) DEFAULT NULL COMMENT '创建时间',
  `adminrole` varchar(255) NOT NULL COMMENT '角色 超级管理：所有功能 普通管理 维修员（业主报修，接单维修，反馈维修结果）',
  `adminlogo` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`adminid`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4;
```

2 插入一些初始数据

3 管理功能设计

列表展示：

id、账号、姓名、手机号、角色、年龄、性别、账号创建时间、操作

多条件查询：

手机号、账号、角色

新增：【姓名、拼音缩写、手机号、角色】

删除：

编辑：【延迟实现，js+ajax】

【重置密码】

![image-20220622115329464](https://qnjy.coding.net/p/githubimg/d/githubimg/git/raw/master/img/20220622-image-20220622115329464.png)

# 2 登陆功能

目标：

**@1 登录页面---账户号/密码---》index页面（后续也需要做成jsp）**

**@2 如果不登录，无法进行系统操作（模块管理）**

@3 根据用户的角色不同，登录到系统后，看到的模块也不同

【 超级管理员（物业主管）：所有功能

​    普通管理员（普通物业人员）：不能进行管理员管理

​    维修员（维修人员）：（业主报修、接单维修、反馈维修结果）】

目前发起请求的方式： *超链接或表单提交，不涉及异步Ajax*



【登录校验】：

1在用户访问所有路径时，都需要判断一下当前用户是否在登录状态

技术基础：

​		Session会话技术 +  Filter过滤器技术

# 知识点Session会话和过滤器

**Session会话**，又称为HttpSession，程序员可以 存/取 B+S在请求和响应过程中产生的一些数据。

生命周期： 从会话开始（打开浏览器第一次访问服务器）  到  会话结束（浏览器关闭或服务器关闭）。

关键点：HttpSession可以**跨越**多次请求和响应

方法：

​		存入：setAttribute  取出：getAttribute

使用： 在登录成功时，将成功标志（例如，user对象）放入到会话中；

​     		然后用户访问其他的路径时，我们判断会话中是否有登录标志（例如，user对象）：

​					**如果有**说明之前登录成功了，可以访问；

​					**如果没有**，说明用户没有登录，是直接访问的路径，不可以访问，让用户去登录。

**过滤器**

然后：

将 index.html ---> index.jsp，并通过managecontroller来访问，动态显示当前登录账号的信息。

# 3 注销功能

点击注销-->效果：登录页面

​				-->隐藏：需要将session的数据清空 

​									session.invalidate()

![image-20220622115836038](https://qnjy.coding.net/p/githubimg/d/githubimg/git/raw/master/img/20220622-image-20220622115836038.png)
