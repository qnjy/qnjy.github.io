---
title: IDEA使用$符号失效问题
tags:
  - IDEA使用问题
categories: 工具使用问题
abbrlink: 7fbc5666
date: 2020-12-15 16:37:13
---

　　今天在使用IDEA开发maven项目的时候遇到不加载EL表达式的问题<!--more-->
![rMuP41.png](https://s3.ax1x.com/2020/12/15/rMuP41.png)]

结果却显示为

![rMuF9x.png](https://s3.ax1x.com/2020/12/15/rMuF9x.png)]

<font color="ff0000">解决办法</font>

在jsp开头添加

```
<%@page isELIgnored="false"%>
```

isELIgnored是指是否忽略EL表达式

之所以形成这种问题，是因为JSP2.0以上isELIgnored默认是true

isELIgnored 属性JSP 2.0 新引入的属性，在只支持 JSP 1.2  及早期版本的服务器中，使用这项属性是不合法的。这个属性的默认值依赖于 Web 应用所使用的 web.xml 的版本。如果 web.xml 指定  servlet 2.3（对应JSP 1.2）或更早版本，默认值为 true（但变更默认值依旧是合法的，JSP 2.0  兼容的服务器中都允许使用这项属性，不管 web.xml 的版本如何）

查看Servlet版本

打开web.xml文件就可以看到

```xml
<!DOCTYPE web-app PUBLIC
 "-//Sun Microsystems, Inc.//DTD Web Application 2.3//EN"
 "http://java.sun.com/dtd/web-app_2_3.dtd" >
```

按住Ctrl点击链接，到78行左右就可以看到一段注释

```jsp
<!--
This is the XML DTD for the Servlet 2.3 deployment descriptor.
All Servlet 2.3 deployment descriptors must include a DOCTYPE
of the following form:
 <!DOCTYPE web-app PUBLIC
  "-//Sun Microsystems, Inc.//DTD Web Application 2.3//EN"
  "http://java.sun.com/dtd/web-app_2_3.dtd">
-->
```

翻译一下就是

“这是Servlet 2.3部署描述符的XML DTD。所有的Servlet 2.3部署描述符必须包含于下面的DOCTYPE”
 很明显这就是Servlet 2.3版本

所以

isELIgnored的属性默认为true