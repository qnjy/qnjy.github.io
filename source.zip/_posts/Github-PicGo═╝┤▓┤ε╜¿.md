---
title: Github+PicGo图床搭建
abbrlink: febc4fee
date: 2021-05-26 17:35:48
tags:
categories:
---

　　github+PicGo图床配置简单教程<!--more-->

# 1.Github新建仓库

点击new repository新建仓库

![image-20210526175629464](https://cdn.jsdelivr.net/gh/qnjy/images/data/20210526-image-20210526175629464.png)

仓库名可以随便取，我这里取得是cdn，Initialize this repository with a README 可点可不点，我这里没点

然后点击 create repository即可

![image-20210526175747194](https://cdn.jsdelivr.net/gh/qnjy/images/data/20210526-image-20210526175747194.png)

![image-20210526175756052](https://cdn.jsdelivr.net/gh/qnjy/images/data/20210526-image-20210526175756052.png)

找到页面最下面的`Developer settings`，点击进入；

![image-20210526175911572](https://cdn.jsdelivr.net/gh/qnjy/images/data/20210526-image-20210526175911572.png)

创建token；

![image-20210526175949415](https://cdn.jsdelivr.net/gh/qnjy/images/data/20210526-image-20210526175949415.png)

填 description（也是随心填），勾选复选框 repo ，接着到页面底部 `Generate token` 就完成了；

![image-20210526180007585](https://cdn.jsdelivr.net/gh/qnjy/images/data/20210526-image-20210526180007585.png)

然后复制生成一串字符 token，这个 token 只出现一次，所以要保存一下（我一般记在微信收藏）。

![image-20210526180023130](https://cdn.jsdelivr.net/gh/qnjy/images/data/20210526-image-20210526180023130.png)

# 2.PicGo配置

![image-20210526180142878](https://cdn.jsdelivr.net/gh/qnjy/images/data/20210526-image-20210526180142878.png)

仓库名 即你的仓库名

分支名 默认 master

Token 就是刚刚复制的那一串字符

存储路径 这个可以填也可以不填，填了的话图片就上传到 git 中 data 这个文件夹

域名 https://raw.githubusercontent.com/qnjy/images/main这个要改一下 格式 https://raw.githubusercontent.com/[username]/[仓库名]/main

**cdn加速访问**

> 将上面的域名改为：
> 原 https://raw.githubusercontent.com/qnjy/images/main
> 现 https://cdn.jsdelivr.net/gh/qnjy/images@main

**安装插件rename-file**

可以自定义图片的名称的名称，保存图片的路径 等，方便自己查找

命名规则：

{y} 年，4位

{m} 月，2位

{d} 日期，2位

{h} 小时，2位

{i} 分钟，2位

{s} 秒，2位

{ms} 毫秒，3位(v1.0.4)

{timestamp} 时间戳(秒)，10位(v1.0.4)

{hash}，文件的md5值，32位

{origin}，文件原名（会去掉后缀）

{rand:}, 随机数，表示个数，默认为6个，示例：{rand：32}、{rand}

{localFolder:}, 表示层级 ，默认为1，示例：{localFolder:6}、{localFolder}

我的使用的是 时间戳+原名

![image-20210526180509507](https://cdn.jsdelivr.net/gh/qnjy/images/data/20210526-image-20210526180509507.png)

gitee的配置图：

![image-20210802231317873](https://cdn.jsdelivr.net/gh/qnjy/giteeimg/img/20210802-image-20210802231317873.png)

参考链接：https://segmentfault.com/a/1190000038610252

# 3.Typora配置

![image-20210526180402751](https://cdn.jsdelivr.net/gh/qnjy/images/data/20210526-image-20210526180402751.png)