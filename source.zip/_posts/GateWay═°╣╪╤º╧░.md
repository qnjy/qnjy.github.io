---
title: GateWay网关学习
abbrlink: afb0e332
date: 2022-04-10 16:26:33
tags:
categories:
---

# 1 API网关

## 1.1 什么是API网关

> 在微服务架构里，服务的粒度被进一步细分，各个业务服务可以被独立的设计、开发、测试、部署和管理。这时，各个独立部署单元可以用不同的开发测试团队维护，可以使用不同的编程语言和技术平台进行设计，这就要求必须使用一种语言和平 台无关的服务协议作为各个单元间的通讯方式。

　　API网关作用就是用来保护、增强和控制对于API服务的访问，让外界看起来是一个统一的接口。同时也可在网关中提供额外的功能。

　　总结：网关就是所有项目的一个统一入口。<!--more-->

## 1.2 API网关作用

| 作用     | 描述                                   |
| -------- | -------------------------------------- |
| 请求接入 | 作为所有API接口服务请求的接入点        |
| 业务聚合 | 作为所有后端业务服务的聚合点           |
| 中介策略 | 实现安全、验证、路由、过滤、流控等策略 |
| 统一管理 | 对所有API服务和策略进行统一管理        |

## 1.3 API网关开源实现

用于实现API网关的技术有很多，大致分为：

通过反向代理：nginx、haproxy等

网络编程框架：netty、servlet等

API网关架构：Spring Cloud Gateway、Zuul等

## 1.4 Gateway网关介绍

> Spring Cloud Gateway是Spring官方基于Spring 5.0，Spring Boot 2.0和Project Reactor等技术开发的网关，Spring Cloud Gateway旨在为微服务架构提供一种简单而有效的统一的API路由管理方式。Spring Cloud Gateway作为Spring Cloud生态系中的网关，目标是替代ZUUL，其不仅提供统一的路由方式，并且基于Filter链的方式提供了网关基本的功能，例如：安全，监控/埋点，和限流等。

### 1.4.1 为什么使用Gateway网关

> Gateway可以看做Zuul1.x的升级品和替代品，比Zuul2更早的使用Netty实现异步IO，从而实现了一个简单、比Zuul更高效、与Spring Cloud紧密配合的API网关。Spring Cloud Gateway 里明确的区分了 Router 和 Filter，并且一个很大的特点是内置了非常多的开箱即用功能，并且都可以通过 SpringBoot 配置或者手工编码链式调用来使用。
> 比如内置了 10 种 Router，使得我们可以直接配置一下就可以随心所欲的根据 Header、或者 Path、或者 Host、或者 Query 来做路由。
> 比如区分了一般的 Filter 和全局 Filter，内置了 20 种 Filter 和 9 种全局 Filter，也都可以直接用。当然自定义 Filter 也非常方便。

### 1.4.2 几个基本概念

* Route（路由）：这是网关的基本构建块。它由一个ID，一个目标URI，一组断言和一组过滤器定义。如果断言为真，则路由匹配。
* Predicate（断言）：输入类型是一个ServerWebExchange。我们可以使用它来匹配来自HTTP请求的任何内容，例如headers或参数
* filter（过滤器）：Gateway中的Filter分为两种类型的Filter，分别是Gateway Filter和Global Filter。它将会对请求和响应进行修改处理。

# 2 Gateway工作原理

![image-20220410192512211](https://qnjy.coding.net/p/githubimg/d/githubimg/git/raw/master/img/20220410-image-20220410192512211.png)

网关处理程序映射确定请求与路由匹配，则将其发送到网关Web处理程序。该处理程序通过特定于请求的过滤器链来运行请求。

# 3 Gateway入门案例

我们搞两个服务，分别是product和order，搞一个网关，同意对path请求地址管理

gateway依赖

```yml
<dependency>
    <groupId>org.springframework.cloud</groupId>
    <artifactId>spring-cloud-starter-gateway</artifactId>
    <version>2.2.5.RELEASE</version>
</dependency>
```

# 4 路由规则

## 4.1 路由断言工厂

　　Spring Cloud Gateway将路由作为Spring WebFlux HandlerMapping基础架构的一部分进行匹配。Spring Cloud Gateway包括许多内置的路由断言工厂。所有这些断言都与HTTP请求的不同属性匹配。可以将多个路由断言工厂与and语句结合使用。

![image-20220410210910433](https://qnjy.coding.net/p/githubimg/d/githubimg/git/raw/master/img/20220410-image-20220410210910433.png)

## 4.2 日期时间路由匹配规则

匹配指定日期时间之后的请求`After`

```yml
spring:
  application:
    name: hdnj-gateway

  cloud:
    gateway:
      routes:
        - id: after_route
          uri: http://localhost:8080/
          predicates:
            - After=2022-04-23T06:06:06+08:00[Asia/Shanghai]
```

匹配指定日期时间之前的请求`Before`

```yml
spring:
  application:
    name: hdnj-gateway

  cloud:
    gateway:
      routes:
        - id: before_route
          uri: http://localhost:8080/
          predicates:
            - Before=2022-04-23T06:06:06+08:00[Asia/Shanghai]
```

匹配指定日期时间之间的请求`Between`

```yml
spring:
  application:
    name: hdnj-gateway

  cloud:
    gateway:
      routes:
        - id: between_route
          uri: http://localhost:8080/
          predicates:
            - Between=2022-04-23T06:06:06+08:00[Asia/Shanghai],2022-04-25T06:06:06+08:00[Asia/Shanghai]
```

## 4.3 cookie路由匹配规则

所述cookie路由断言工厂采用两个参数，该cookie name和regexp。该断言匹配具有给定名称且其值域正则表达式匹配的cookie以下示例：

```yml
spring:
  application:
    name: hdnj-gateway

  cloud:
    gateway:
      routes:
        - id: cookie_route
          uri: http://localhost:8080/
          predicates:
           - Cookie=token, \d+
```

## 4.4 Header路由匹配规则

`Header`：路由断言工厂采用两个参数，报头name和regexp。该断言与具有给定名称的头信息匹配，该标头的值与正则表达式匹配。示例：

```yml
spring:
  application:
    name: hdnj-gateway

  cloud:
    gateway:
      routes:
        - id: header_route
          uri: http://localhost:8080/
          predicates:
           - Header=X-Request-Id,\d+
```



## 4.5 Host路由匹配规则

该`Host`路由断言工厂需要一个参数：主机名的列表patterns，该模式是带有.分隔符的Ant样式的模式。断言与`Host`匹配模式的标头匹配，以下示例：

```yml
spring:
  application:
    name: hdnj-gateway

  cloud:
    gateway:
      routes:
        - id: host_route
          uri: http://localhost:8080/
          predicates:
           - Host=**.somehost.org,**.anotherhost.org
```

## 4.6 Method路由匹配规则

所述Method路由断言工厂需要`methods`的参数，他是一个或多个参数：HTTP方法来匹配。示例：

```yml
spring:
  application:
    name: hdnj-gateway

  cloud:
    gateway:
      routes:
        - id: method_route
          uri: http://localhost:8080/
          predicates:
           - Method=GET,POST
```

## 4.7 Path路由匹配规则

该`Path`路由断言工厂有两个参数：Spring的列表`PathMatcher` `patterns`和一个可选的标志叫`matchOptionalTrailingSeparator`。以下示例

```yml
spring:
  application:
    name: hdnj-gateway

  cloud:
    gateway:
      routes:
        - id: path_route
          uri: http://localhost:8080/
          predicates:
           - Path=/product/{segment}
```

## 4.8 Query路由匹配规则

所述`Query`路由断言工厂采用两个参数：所要求的`param`和可选的`regexp`，示例：

```yml
spring:
  application:
    name: hdnj-gateway

  cloud:
    gateway:
      routes:
        - id: query_route
          uri: http://localhost:8080/
          predicates:
           - Query=green
```

如果请求包含green查询参数，则前面的路由匹配。

## 4.9 RemoteAddr路由匹配规则

`RemoteAddr`路由断言工厂需要的列表`sources`，其是CIDR的表示法（IPv4或IPv6）的字符串，如`192.168.200.1/16`（其中`192.168.200.1/16`是一个ip地址和16一个子网掩码 ），示例：

```yml
spring:
  application:
    name: hdnj-gateway

  cloud:
    gateway:
      routes:
        - id: RemoteAddr_route
          uri: http://localhost:8080/
          predicates:
           - RemoteAddr=192.168.200.1/24
```

如果请求的远程地址是以上地址，则此路由匹配

## 4.10 Weight路由匹配规则

该`weight`路由断言工厂有两个参数：`group`和`weight`（一个int）。权重是按组计算的，以下示例：

```yml
spring:
  application:
    name: hdnj-gateway

  cloud:
    gateway:
      routes:
        - id: weight_high
          uri: https://weighthigh.org
          predicates:
           - Weight=group1,8
        - id: weight_low
          uri: https://weightlow.org
          predicates:
           - Weight=group1,2
```

这条路线会将大约80%的流量转发到Weighthigh.org，将有大约20%流量转发到Weightlow.org。

