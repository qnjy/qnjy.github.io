---
title: Docker下logstash同步mysql和elasticsearch
abbrlink: 74932d71
date: 2021-06-29 16:04:10
tags:
categories:
---



# 1 配置elasticsearch环境

参考{% post_link ElasticSearch %}

<!--more-->

# 2 搭建logstash环境

<font color="ff000">elasticsearch和logstash版本要一致</font>

1. 拉取镜像

   ```dockerfile
   docker pull logstash:5.6.8
   ```

2. 创建容器，同时映射文件夹，这样可以把文件同步到容器内

   将/home/docker/logstash/文件夹映射到/etc/logstash/pipeline目录下

   ```
   docker run -dit --name logstash -v /home/docker/logstash/:/etc/logstash/pipeline logstash:5.6.8
   ```

3. 安装jdbc和elasticsearch插件

   通过` docker exec -it logstash /bin/bash `命令进入容器内，然后在下载插件

   进入bin目录，执行以下命令

   ```bash
   #下载jdbc插件
   logstash-plugin install logstash-input-jdbc
   #下载elasticsearch插件
   logstash-plugin install logstash-output-elasticsearch
   ```

4. 下载mysql-connector-java的jar包，放在刚刚配置的映射/home/docker/logstash/文件夹中，同时在这个文件夹下创建mysql.conf配置文件，内容如下

   ```conf
   input {
   	jdbc {
   	# mysql jdbc connection string to our backup databse 后面的test对应mysql中的test数据库
   	jdbc_connection_string =>"jdbc:mysql://8.140.127.197:3306/tensquare_article?characterEncoding=UTF8"
   	# the user we wish to excute our statement as
   	jdbc_user => "root"
   	jdbc_password => "root"
   	#这个jar包的地址是容器内的地址
   	jdbc_driver_library => "/etc/logstash/pipeline/mysql-connector-java-5.1.47.jar"
   	# the name of the driver class for mysql
   	jdbc_driver_class => "com.mysql.jdbc.Driver"
   	jdbc_paging_enabled => "true"
   	jdbc_page_size => "50000"
   	#以下对应着要执行的sql的绝对路径。
   	statement => "select id,title,content from tb_article"
   	#定时字段 各字段含义（由左至右）分、时、天、月、年，全部为*默认含义为每分钟都更新
   	schedule => "* * * * *"
   	}
   }
   
   output {
   elasticsearch {
       #ESIP地址与端口
       hosts => "8.140.127.197:9200"
       #ES索引名称（自己定义的）
       index => "tensquare"
       #自增ID编号
       document_id => "%{id}"
       document_type => "article"
       }
       stdout {
       #以JSON格式输出
       codec => json_lines
       }
   }
   ```

5. 执行，进行同步

   ```
   logstash -f /etc/logstash/pipeline/mysql.conf
   ```

   

# 报错问题

参考：https://blog.csdn.net/weixin_41676972/article/details/87773783
