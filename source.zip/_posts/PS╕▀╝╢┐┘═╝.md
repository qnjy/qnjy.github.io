---
title: PS高级抠图
categories:
  - PS技巧
abbrlink: 6be47898
date: 2021-08-06 23:06:28
tags:
---

# 1 色彩范围抠图

1. 选择色彩范围（选区预览选择灰度），使用吸管工具在背景上吸取一下，按shift或者alt自定义调整吸取颜色，要求背景纯白对比鲜明<!--more-->
2. 创建蒙版，选择画笔工具擦掉背景多余的部分
3. 调整蒙版，点击选择并遮住，进行调节，然后输出新建带有蒙版的图层
4. 使用画笔工具进行调节细节（44透明度，32流量）

<img src="https://cdn.jsdelivr.net/gh/qnjy/giteeimg/img/20210806-image-20210806233802910.png" alt="image-20210806233802910" style="zoom: 80%;" /><img src="https://cdn.jsdelivr.net/gh/qnjy/giteeimg/img/20210806-image-20210806233821384.png" alt="image-20210806233821384" style="zoom: 80%;" />

