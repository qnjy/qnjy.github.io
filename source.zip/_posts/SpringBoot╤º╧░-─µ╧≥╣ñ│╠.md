---
title: SpringBoot-逆向工程
tags:
  - SpringBoot学习
categories: SpringBoot学习
abbrlink: '1511e846'
date: 2021-01-11 10:57:36
---

　　之前建立实体类，需要手动慢慢建立，很没有效率，了解了逆向工程之后，确实很方便<!--more-->

# 1.返回json数据

```java
package com.gyl.springboot.web;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class IndexController {
    @RequestMapping(value = "/say")
    public @ResponseBody Object m(String message){
        return "Say:Hello" + message;
    }
    
    @RequestMapping(value = "/mapvalue")
    public @ResponseBody Map<String, Object> mapvalue() {
        Map<String, Object> retMap = new HashMap<String, Object>();
        retMap.put("message", "hello SpringBoot");
        return retMap;
    }
}
```

在浏览器中url后面加上`?message=World`

就会显示Say:HelloWorld

访问localhost:8080/mapvalue可以显示

message:hello SpringBoot

# 2.核心配置文件

## 2.1 三类配置文件比较

properties

```properties
server.port=9090
server.servlet.context-path=/
```

yml和yaml格式一样，只是名字不一样

```yml
server:
  port:
  servlet:
    context-path: /
```

当yml/properties文件同时存在时，以properties文件为准

# 3.多环境下核心配置文件

开发环境-->测试环境-->准生产环境-->生产环境

yml和properties一样，只是后缀不一样

主核心配置文件

`application.properties`

```properties
spring.profiles.active=dev
```

多配置文件要以application-开头

`application-dev.properties`开发环境

```properties
server.port=9090
server.servlet.context-path=/dev
```

`application-test.properties`测试环境

```properties
server.port=9090
server.servlet.context-path=/test
```

`application-ready.properties`准生产环境

```properties
server.port=9090
server.servlet.context-path=/ready
```

`application-product.properties`生产环境

```properties
server.port=9090
server.servlet.context-path=/product
```

# 4.集成jsp

首先，创建webapp资源文件夹，并设置该文件夹为web项目文件夹。

之后，在pom.xml中引入SpringBoot内嵌tomcat对jsp的解依赖

```xml
<dependency>
    <groupId>org.apache.tomcat.embed</groupId>
	<artifactId>tomcat-embed-jasper</artifactId>
</dependency>
```

然后，在pom.xml下指定编译路径在\<build>\</build>中

```xml
<resources>
	<resource>
        <!--源文件夹-->
    	<directory>src/main/webapp</directory>
        <!--指定编译到META-INF/resources-->
        <targetPath>META-INF/resources</targetPath>
        <!--指定源文件夹中的哪个资源要编译进行-->
        <includes>
        	<include>*.*</include>
        </includes>
    </resource>
</resources>
```

最后，在application.properties中配置视图解析器

```properties
spring.mvc.view.prefix=/
spring.mvc.view.suffix=.jsp
```

# 5.集成MyBatis依赖

导入MaBatis依赖支持

```xml
<!--MySQL驱动-->
<dependency>
    <groupId>mysql</groupId>
    <artifactId>mysql-connector-java</artifactId>
</dependency>

<!--MyBatis整合SpringBoot框架的起步依赖-->
<dependency>
    <groupId>org.mybatis.spring.boot</groupId>
    <artifactId>mybatis-spring-boot-starter</artifactId>
    <version>RELEASE</version>
</dependency>
```

## 5.1 MyBatis逆向工程

**1.GeneratorMapper.xml**

在根目录下创建GeneratorMapper.xml

```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE generatorConfiguration
        PUBLIC "-//mybatis.org//DTD MyBatis Generator Configuration 1.0//EN"
        "http://mybatis.org/dtd/mybatis-generator-config_1_0.dtd">

<generatorConfiguration>
    <!--指定连接数据库的JDBC 驱动包所在位置，指定到你本机的完整路径-->
    <classPathEntry
            location="D:\JavaTools\Maven\Mavenrespository\mysql\mysql-connector-java\8.0.22\mysql-connector-java-8.0.22.jar"/>
    <!--配置table表信息内容体，targetRuntime 指定采用MyBatis3的版本-->
    <context id="testTables" targetRuntime="MyBatis3">
        <!--抑制生成注释，由于生成的注释都是英文的，可以不让它生成-->
        <commentGenerator>
            <property name="suppressAllComments" value="true"/>
        </commentGenerator>
        <!--配置数据库连接信息-->
        <jdbcConnection driverClass="com.mysql.cj.jdbc.Driver"
                        connectionURL="jdbc:mysql://localhost:3306/springboot_student?useUnicode=true&amp;characterEncoding=utf-8&amp;useSSL=false&amp;serverTimezone=GMT%2B8"
                        userId="root"
                        password="root">
            <property name="nullCatalogMeansCurrent" value="true"/>

        </jdbcConnection>

        <!--生成model 类，targetPackage 指定 model 类的包名，targetProject 指定
        生成的 model放在eclipse的哪个工程下面-->
        <javaModelGenerator targetPackage="com.springboot.model"
                            targetProject="src/main/java">
            <property name="enableSubPackages" value="false"/>
            <property name="trimStrings" value="false"/>
        </javaModelGenerator>
        <!--生成 MyBatis的Mapper.xml文件，targetPackage 指定 mapper.xml文件的包名，targetProject 指定生成的 mapper.xml放在 eclipse的哪个工程下面
        -->
        <sqlMapGenerator targetPackage="com.springboot.mapper"
                         targetProject="src/main/java">
            <property name="enableSubPackages" value="false"/>
        </sqlMapGenerator>
        <!--生成 MyBatis的 Mapper接口类文件,targetPackage 指定 Mapper 接口类的包名，targetProject 指定生成的 Mapper 接口放在eclipse 的哪个工程下面
        -->
        <javaClientGenerator type="XMLMAPPER"
                             targetPackage="com.springboot.mapper"
                             targetProject="src/main/java">
            <property name="enableSubPackages" value="false"/>
        </javaClientGenerator>
        <!--数据库表名及对应的Java模型类名，数据库有多少张表就配置几个table-->
        <table tableName="t_student" domainObjectName="Student"
               enableCountByExample="false"
               enableUpdateByExample="false"
               enableDeleteByExample="false"
               enableSelectByExample="false"
               selectByExampleQueryId="false"/>
    </context>
</generatorConfiguration>
```

**2.在pom.xml文件中导入MyBatis-generator插件**

```xml
 <!--MyBatis整合SpringBoot框架的起步依赖-->
<dependency>
    <groupId>org.mybatis.spring.boot</groupId>
    <artifactId>mybatis-spring-boot-starter</artifactId>
    <version>2.1.4</version>
</dependency>
```

```xml
<plugin>
    <groupId>org.mybatis.generator</groupId>
    <artifactId>mybatis-generator-maven-plugin</artifactId>
    <version>1.3.6</version>
    <configuration>
    	<!--配置文件的位置-->
        <configurationFile>GeneratorMapper.xml</configurationFile>
        <verbose>true</verbose>
        <overwrite>true</overwrite>
    </configuration>
</plugin>
```

![6BsMTg.png](https://s3.ax1x.com/2021/03/15/6BsMTg.png)

然后查看生成的StudentMapper.xml

```xml
  <resultMap id="BaseResultMap" type="com.springboot.model.Student">
      <!--id标签只能修改主键字段-->
      <!--result除了主键以外的字段-->
      <!--
		column数据库中的字段名称	
 		property映射对象的属性名称
		jdbcType列中数据库中字段的类型（可以省略不写）
		-->
      <!--
		resultMap作用
		1.当数据库中字段名称与实体对象的属性名不一致时，可以进行转换
		2.当前查询的结果没有对象一个表的时候，可以自定义一个结果集		
		-->
      <!--
		数据库字段名称		实体对象属性名称
		user_name		userName
		product_type	productType
		-->
    <id column="id" jdbcType="INTEGER" property="id" />
    <result column="name" jdbcType="VARCHAR" property="name" />
    <result column="age" jdbcType="INTEGER" property="age" />
  </resultMap>
	<!--抽取公共部分，方便下面include引用-->
  <sql id="Base_Column_List">
    id, name, age
  </sql>
```

**3.指定资源文件夹**

在pom.xml文件中的build下添加，扫描StudentMapper.xml

```xml
<!--        手动指定文件夹为resources-->
    <resources>
        <resource>
            <directory>src/main/java</directory>
            <includes>
                <include>**/*.xml</include>
            </includes>
        </resource>
    </resources>
```

**4.配置application.properties文件**

```properties
#配置内嵌Tomcat端口号
server.port=9090 
#配置项目上下文根
server.servlet.context-path=/
#配置数据库的连接信息
# 注意这里的驱动类有变化
spring.datasource.driver-class-name=com.mysql.cj.jdbc.Driver
spring.datasource.url=jdbc:mysql://localhost:3306/springboot_student?useUnicode=true&characterEncoding=utf-8&useSSL=false&serverTimezone=GMT%2B8
spring.datasource.username=root
spring.datasource.password=root
```

## 5.2 业务逻辑

Controller-->Service-->ServiceImpl

先Controller

```java
@Controller
public class StudentController{
    @Autowired
    private StudentService studentService;
	
	@RequestMapping(value = "/student")
	public @ResponseBody Student queryStudentById(Integer id){
        //调用业务层方法
        Student student = studentService.queryStudentById(id);
		return student;
	}
}
```

然后写Service层

```java
public interface StudentService {
    //根据学生id查询详情
    Student queryStudentById(Integer id);  
}
```

再写ServiceImpl类

```java
@Service
public class StudentServiceImpl implements StudentService{
    @Autowired
    private StudentMapper studentMapper;
    @Override
    public Student queryStudentById(Integer id){
        return studentMapper.selectByPrimaryKey(id);
    }
}
```

在入口类上写上@MapperScan(basePackages = "")注解

## 5.3 MyBatis映射文件方法有两种

* 第一种

当接口类和xml文件在一块时，在pom.xml中的build标签中添加

```xml
<!--手动指定文件夹为resources-->
<resources>
    <resource>
        <directory>src/main/java</directory>
        <includes>
            <include>**/*.xml</include>
        </includes>
    </resource>
</resources>
```

* 第二种

在resource文件夹中新建mapper文件夹中，放入StudentMapper.xml，在application.properties中写入以下代码

```properties
#配置内嵌Tomcat端口号
server.port=9090 
#配置项目上下文根
server.servlet.context-path=/
#配置数据库的连接信息
# 注意这里的驱动类有变化
spring.datasource.driver-class-name=com.mysql.cj.jdbc.Driver
spring.datasource.url=jdbc:mysql://localhost:3306/springboot_student?useUnicode=true&characterEncoding=utf-8&useSSL=false&serverTimezone=GMT%2B8
spring.datasource.username=root
spring.datasource.password=root

#指定MyBatis映射文件路径
mybatis.mapper-locations=classpath:mapper/*.xml
```

# 6.集成Redis依赖

**1.在pom.xml中添加以下依赖**

```xml
<!--SpringBoot集成Redis起步依赖-->
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-data-redis</artifactId>
</dependency>
```

**2.配置application.properties**

```properties
#设置redis配置信息
spring.redis.host=localhost
spring.redis.port=6379
spring.redis.password=root
```

