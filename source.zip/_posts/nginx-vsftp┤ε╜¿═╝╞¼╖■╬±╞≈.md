---
title: nginx+vsftp搭建图片服务器
tags: nginx
abbrlink: dd124e24
date: 2021-01-15 15:58:19
categories:
---

　　在写小程序项目的时候需要用到图片服务器，没有云服务器，只能自己搭建，linux最好是静态ip，动态ip的话，如果虚拟机的地址发生变化，访问路径也在改变，影响做项目进展。<!--more-->

# 1.环境

　　nginx是C语言开发，建议在linux上运行，本教程使用Centos 7作为安装环境。先要安装如下东西:

**1.gcc**

`yum install gcc-c++ `

**2.pcre**

`yum install -y pcre pcre-devel`

**3.zlib**

`yum install -y zlib zlib-devel`

**4.openssl**

`yum install -y openssl openssl-devel`

**5.开启防火墙端口**

先把nginx和vsftp需要用到的端口先开启，以免后面出错

```
firewall-cmd --zone=public --add-port=80/tcp --permanent
firewall-cmd --zone=public --add-port=443/tcp --permanent
firewall-cmd --zone=public --add-port=22/tcp --permanent
firewall-cmd --zone=public --add-port=21/tcp --permanent
firewall-cmd --zone=public --add-port=30000-30999/tcp --permanent
```

逐条运行以上命令就可以。

# 2.安装nginx

**1.下载nginx**

```
wget -c https://nginx.org/download/nginx-1.8.0.tar.gz
```

可以上nginx官网看一下，把版本号改成自己需要的

**2.解压**

```
tar -zxvf nginx-1.8.0.tar.gz
cd nginx-1.8.0
```

**3.设置编译参数**

```
./configure \
--prefix=/usr/local/nginx \
--pid-path=/var/run/nginx/nginx.pid \
--lock-path=/var/lock/nginx.lock \
--error-log-path=/var/log/nginx/error.log \
--http-log-path=/var/log/nginx/access.log \
--with-http_gzip_static_module \
--http-client-body-temp-path=/var/temp/nginx/client \
--http-proxy-temp-path=/var/temp/nginx/proxy \
--http-fastcgi-temp-path=/var/temp/nginx/fastcgi \
--http-uwsgi-temp-path=/var/temp/nginx/uwsgi \
--http-scgi-temp-path=/var/temp/nginx/scgi
```

直接将这段代码复制粘贴的linux中执行就可以

**4.编译**

```
make
```

**5.安装**

```
make install
```

**6.启动nginx**

```
cd /usr/local/nginx/sbin
./nginx
```

执行这个命令后是没有任何提示的，然后在浏览器中访问虚拟机的ip，出现nginx欢迎页则安装成功。

**7.关闭nginx**

关闭nginx:
在刚才的sbin目录下执行:

```
./nginx -s stop
```

**遇到的坑**

第一次启动nginx没问题，但是如果重启虚拟机，再次到ngin的sbin目录下执行./nginx，出现以下错误

`"var/run/nginx/nginx.pid" no such file or directory`

**解决办法**

在linux中输入，修改nginx.conf配置文件

```
vi /usr/local/nginx/conf/nginx.conf
```

将`#pid	logs/nginx.pid`前面的#号去掉，之后`:wq`保存退出

# 3.vsftp的安装

**1.安装**

**2.添加ftp用户**

**3.给ftp用户添加密码**

输入两次密码后修改密码

**4.修改selinux**

* 查看状态

执行之后可以看到

```
allow_ftpd_full_access --> off
tftp_home_dir --> off
```

两个都是off，执行下面命令设置on

```
setsebool -P ftpd_full_access on
setsebool -P tftp_home_dir on
```

再次执行`getsebool -a | grep ftp`看到那两个状态是on就行了。

**5.关闭匿名访问**

```
vi /etc/vsftpd/vsftpd.conf
```

![sDhK3j.jpg](https://s3.ax1x.com/2021/01/16/sDhK3j.jpg)

还要在vsftp.conf文件最下面添加

```
pasv_min_port=30000
pasv_max_port=30999
```

**6.设置开机启动**

```
chkconfig vsftpd on
```

# 4.配置nginx为图片服务器

```
vi  /usr/local/nginx/conf/ nginx.conf
```

命令，打开nginx的配置文件:

![sDhMgs.jpg](https://s3.ax1x.com/2021/01/16/sDhMgs.jpg)

设置ftpuser文件夹可读权限，执行如下命令:

```
chmod -R 755 /home/ftpuser
```

可以使用xftp等文件传输工具将图片传送至虚拟机

![sDhO2j.jpg](https://s3.ax1x.com/2021/01/16/sDhO2j.jpg)

![sDhxrq.md.jpg](https://s3.ax1x.com/2021/01/16/sDhxrq.md.jpg)

