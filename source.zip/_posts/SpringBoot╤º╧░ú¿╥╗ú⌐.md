---
title: SpringBoot学习（一）
tags:
  - SpringBoot学习
categories: SpringBoot学习
abbrlink: 2507049e
date: 2020-11-22 08:35:31
---

　　在学校第一次学习SpringBoot的时候写的，跟着老师给的代码，好不容易运行的起来<!--more-->

# 创建SpringBoot项目

## 1.网页创建

打开浏览器访问[https://start.spring.io](https://start.spring.io)，进入以下界面<!--more--><img src="https://s3.ax1x.com/2020/11/22/D3qGgH.jpg" alt="D3qGgH.jpg" style="zoom:50%;" />



## 2.IDEA创建

点击File-New-Project

选择“Spring Initializr”，

<img src="https://s3.ax1x.com/2020/11/22/D3q3CD.jpg" alt="D3q3CD.jpg" style="zoom:50%;" />

点击next，选择

<img src="https://s3.ax1x.com/2020/12/03/DojCvD.jpg" alt="DojCvD.jpg" style="zoom:50%;" />

点击next

<img src="https://s3.ax1x.com/2020/12/03/DojiKe.jpg" alt="DojiKe.jpg" style="zoom:50%;" />

<img src="https://s3.ax1x.com/2020/12/03/DojFDH.jpg" alt="DojFDH.jpg" style="zoom:50%;" />

点击next选择项目的名字和位置

<img src="https://s3.ax1x.com/2020/12/03/Dojkbd.jpg" alt="Dojkbd.jpg" style="zoom:50%;" />

# 目录结构

## 1.main目录

创建好项目之后目录结构如下

<img src="https://s3.ax1x.com/2020/11/22/D3qJvd.jpg" alt="D3qJvd.jpg" style="zoom:50%;" />

| 目录名                          | 位置                            |
| ------------------------------- | ------------------------------- |
| 工程启动类(Application.java)    | 置于com.springboot.build        |
| 实体类(domain)                  | 置于com.springboot.domain       |
| 数据访问层(Dao)                 | 置于com.springboot.repository   |
| 数据服务层(Service)             | 置于com,springboot.service      |
| 数据服务接口的实现(serviceImpl) | 置于com.springboot.service.impl |
| 前端控制器(Controller)          | 置于com.springboot.controller   |
| 工具类(utils)                   | 置于com.springboot.utils        |
| 常量接口类(constant)            | 置于com.springboot.constant     |
| 配置信息类(config)              | 置于com.springboot.config       |

## 2.resources目录

<img src="https://s3.ax1x.com/2020/11/22/D3qtKA.jpg" alt="D3qtKA.jpg" style="zoom: 50%;" />

| 目录名                           | 作用                                                         |
| -------------------------------- | ------------------------------------------------------------ |
| static                           | 用于存放html、css、js、图片等静态资源                        |
| templates                        | 用于存放jsp、thymeleaf等模板文件                             |
| resources/application.properties | 用于存放程序的各种依赖模块的配置信息，比如 服务端口，数据库连接配置等 |

# 第一个springboot项目

demo1下新建Controller包，再新建HelloController类

<img src="https://s3.ax1x.com/2020/12/01/Df1TQH.jpg" alt="Df1TQH.jpg" style="zoom:50%;" />

在HelloController类中写入以下代码

```java
package com.example.demo1.Controller;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@SpringBootApplication
public class HelloController {

    @RequestMapping("/")
    String s(){
        return "Hello SpringBoot";
    }
}
```

运行，第一次运行右下角可能要加载很多东西

![Df1TQH.jpg](https://s3.ax1x.com/2020/12/01/Df1TQH.jpg)

# 访问项目

[![D3q88e.jpg](https://s3.ax1x.com/2020/11/22/D3q88e.jpg)](https://imgchr.com/i/D3q88e)

# 课堂代码实例：

​		这里我运行的过程很不顺利，在所有代码写完，开始运行时候，idea老是提示错误，后来在网上搜了一大堆，发现是maven版本和idea版本不兼容的问题，maven版本的发行日期一定要比idea的早，不然不能测试成功，懒得再破解idea，所以我把maven版本改为3.6.0版本。

## 1.创建数据库

数据库的建立这里不再赘述。以下是创建数据库的常用语句：

```
select 字段名1,字段名2 from 表名

insert into 表名[(列名1,列名2...)] values(列1数据,列2数据...);

update 表名 set 列名=列值,列2名=列2值...where 选择条件

delete from 表名 where 选择条件
```

可以使用可视化工具（navicat、sqlyog、sqlfont）创建mydata数据库，之后建表user，表user中有三个字段id int(11)、name varchar(255)、age int (11)，表中有一条数据，数据可以自己设定：

![DTQcB4.jpg](https://s3.ax1x.com/2020/12/03/DTQcB4.jpg)

## 2.使用springboot创建Web项目

点击File-New-Project

选择“Spring Initializr”，

![D3q3CD.jpg](https://s3.ax1x.com/2020/11/22/D3q3CD.jpg)

点击next，选择

![DojCvD.jpg](https://s3.ax1x.com/2020/12/03/DojCvD.jpg)

点击next

![DojiKe.jpg](https://s3.ax1x.com/2020/12/03/DojiKe.jpg)

<img src="https://s3.ax1x.com/2020/12/03/DojFDH.jpg" alt="DojFDH.jpg" style="zoom:67%;" />

点击next选择项目的名字和位置

<img src="https://s3.ax1x.com/2020/12/03/Dojkbd.jpg" alt="Dojkbd.jpg" style="zoom:67%;" /><img src="https://s3.ax1x.com/2020/12/03/Dojkbd.jpg" alt="Dojkbd.jpg" style="zoom:67%;" /><img src="https://s3.ax1x.com/2020/12/03/Dojkbd.jpg" alt="Dojkbd.jpg" style="zoom:67%;" />

点击finish

刚创建好的项目目录：

<img src="https://s3.ax1x.com/2020/11/22/D3qJvd.jpg" alt="D3qJvd.jpg" style="zoom:67%;" />

## 3.添加依赖

打开pom.xml，<font color="ff0000">新建好的springboot项目有默认依赖，添加以下依赖</font>

(1) SpringMVC支持（如果默认有就不需要添加）

依赖：spring-boot-starter-web

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
   <artifactId>spring-boot-starter-web</artifactId>
</dependency>
```

(2) 添加Druid依赖

```xml
<!-- https://mvnrepository.com/artifact/com.alibaba/druid-spring-boot-starter -->
<dependency>
    <groupId>com.alibaba</groupId>
        <artifactId>druid-spring-boot-starter</artifactId>
 <version>1.1.10</version>
</dependency>
```

(3) 添加Mysql依赖

<font color="ff0000">注意：</font>

<font color="ff0000">查看自己mysql的版本，如果电脑上装的是mysql5.0的使用以下代码添加mysql依赖</font>

```xml
<!-- https://mvnrepository.com/artifact/mysql/mysql-connector-java -->
<dependency>
    <groupId>mysql</groupId>
    <artifactId>mysql-connector-java</artifactId>
    <version>5.1.47</version>
</dependency>
```

<font color="ff0000">mysql8.0的使用以下代码添加mysql依赖</font>

```xml
<dependency>
    <groupId>mysql</groupId>
    <artifactId>mysql-connector-java</artifactId>
    <version>8.0.22</version>
</dependency>
```

<img src="https://s3.ax1x.com/2020/12/03/DTQ49x.jpg" alt="DTQ49x.jpg" style="zoom: 50%;" />

(4) 添加mybatis支持

```xml
<!-- https://mvnrepository.com/artifact/org.mybatis.spring.boot/mybatis-spring-boot-starter -->
<dependency>
    <groupId>org.mybatis.spring.boot</groupId>
  <artifactId>mybatis-spring-boot-starter</artifactId>
    <version>1.3.2</version>
</dependency>
```

(5) 添加junit依赖

```xml
<!--添加junit依赖-->
<dependency>
	<groupId>junit</groupId>
    <artifactId>junit</artifactId>
    <version>4.12</version>
    <scope>test</scope>
</dependency>
```

依赖导入完成之后，如果保存pom.xml文件没有自动下载，按下图操作，之后会自动加载，在IDEA右下方可以查看下载进度，如果没有换maven镜像会很慢，换镜像参考{%post_link Maven环境变量配置%}中的maven仓库配置。

<img src="https://s3.ax1x.com/2020/12/03/D76Aqe.jpg" alt="D76Aqe.jpg" style="zoom:67%;" />

## 4.创建实体类

(1) 在java的com.example.demo下新建beans包，在这个包下新建User类，<font color="FF0000">这个User一般是数据库中的表名！User类中的3的属性是User表中对应的3个字段，id，age，name</font>

<img src="https://s3.ax1x.com/2020/12/03/DTQRE9.jpg" alt="DTQRE9.jpg" style="zoom:67%;" />

```java
public class User {
    private int id;
    private String name;
    private int age;

    public User (){

    }

    public User(int id, String name, int age) {
        this.id = id;
        this.name = name;
        this.age = age;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    @Override
    public String toString() {
        return "id: " + id + "，" + "name:" + name + "，" + "age:" + age;
    }
}
```

(2) 创建接口（放在dao包下）

在demo11下新建dao包，新建接口UserDao

<img src="https://s3.ax1x.com/2020/12/03/DTQgHJ.jpg" alt="DTQgHJ.jpg" style="zoom:67%;" />

```java
package com.example.demo11.dao;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository

@Mapper

public interface UserDao{
    void insertUser(User user) throws Exception;

    List<User> findUser() throws Exception;

    User findUserById(int id) throws Exception;
}
```

User出现错误是因为没有导入之前写的User类，点击一下User，然后按住alt+Enter，选择第一个即可

<img src="https://s3.ax1x.com/2020/12/03/DTQD3V.jpg" alt="DTQD3V.jpg" style="zoom:67%;" />

<img src="https://s3.ax1x.com/2020/12/03/DTQ6uF.jpg" alt="DTQ6uF.jpg" style="zoom:67%;" />

## 5.全局配置文件中添加数据库连接池的连接属性

<font color="ff0000">注意：如果mysql版本是5.0的，将url和driver-class-name后面的内容按注释内容替换</font>

```yml
spring:
  datasource:
    druid:
      #mysql8.0使用 jdbc:mysql://localhost:3306/mydata?serverTimezone=Asia/Shanghai
      #mysql5.0使用 jdbc:mysql://localhost:3306/mydata
      url: jdbc:mysql://localhost:3306/mydata?serverTimezone=Asia/Shanghai
      #mysql8.x驱动 com.mysql.cj.jdbc.Driver
      #mysql5.x驱动 com.mysql.jdbc.Driver
      driver-class-name: com.mysql.cj.jdbc.Driver
      username: root
      password: root
      initial-size: 1
      min-idle: 1
      max-active: 20
mybatis:
  mapper-locations: classpath:mappers/*Mapper.xml
  type-aliases-package: com.example.demo11.beans;
```

<img src="https://s3.ax1x.com/2020/12/03/D7sTXD.jpg" alt="D7sTXD.jpg" style="zoom:80%;" />

## 

## 6.创建映射文件mapper

在resources下新建mappers包，包下新建userMapper.xml文件，粘贴以下内容

```xml
<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE mapper
        PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN"
        "http://mybatis.org/dtd/mybatis-3-mapper.dtd">
<mapper namespace="com.demo.dao.UserDao">
    <insert id="insertUser" parameterType="User" useGeneratedKeys="true" keyProperty="id">
      insert into user(id,name,age) values (#{id},#{name},#{age})
    </insert>

    <resultMap id="userset" type="User">
        <id column="id" property="id"></id>
        <result column="name" property="name"></result>
        <result column="age" property="age"></result>
    </resultMap>

    <select id="findUser" resultMap="userset" resultSets="java.util.List">
        select * from user;
    </select>

    <select id="findUserById" resultMap="userset">
         select * from user where id=#{id};
    </select>
</mapper>
```

<img src="https://s3.ax1x.com/2020/12/03/D7D1AI.jpg" alt="D7D1AI.jpg" style="zoom:67%;" />

下图位置就是上图说的位置

<img src="https://s3.ax1x.com/2020/12/03/D7DJ9f.jpg" alt="D7DJ9f.jpg" style="zoom:80%;" />

如果第四行出现报错，用以下方法解决，如果没有报错，跳过此步

点击File->Settings->Languages&Frameworks->Schemas and DTDs，点击右边的+号

<img src="https://s3.ax1x.com/2020/12/03/DTlSv8.jpg" alt="DTlSv8.jpg" style="zoom:67%;" />

将http://mybatis.org/dtd/mybatis-3-mapper.dtd链接输入进去确定即可

## 7.单元测试类

(1) 创建单元测试类：最好包名和类名一致

在test包下创建UserDaoTest包，在UserDaoTest包创建UserDaoTest类。

<font color="ff0000">注意前三行，最好删除，然后按照自己的路径，哪里红就在哪里用alt+Enter方法导包。</font>

<font color="ff0000">@SpringBootTest(classes = Demo11Application.class)，这一行中间的classes后面的是下图左边画框的内容</font>

![D72Px0.jpg](https://s3.ax1x.com/2020/12/03/D72Px0.jpg)

testInsertUser() 在User表中插入数据，不要让id列是0，因为id是主键

testfindUser() 查找mydata数据库中user表中所有数据

testfindUserById(x) 查出id是x的用户，不要让x的值是数据库id字段不存在的值，不然出现空指针异常。

<img src="https://s3.ax1x.com/2020/12/03/D7cMk9.jpg" alt="D7cMk9.jpg" style="zoom:80%;" />

```java
import com.example.demo11.Demo11Application;
import com.example.demo11.beans.User;
import com.example.demo11.dao.UserDao;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;
import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = Demo11Application.class)
public class UserDaoTest {
    @Resource
    private UserDao userDao;
    @Test
    public  void testInsertUser() throws Exception{
        User user=new User(2021,"wangwu",20);
        userDao.insertUser(user);
        System.out.println(user.getId());
        System.out.println("---------");
    }
    @Test
    public  void testfindUser()  throws  Exception{
        List<User> userList=userDao.findUser();
        for(int i=0;i<userList.size();i++)
        {
            System.out.println(userList.get(i).toString());
        }
    }
    @Test
    public void testfindUserById() throws  Exception{
        User user=userDao.findUserById(2);
        System.out.println(user.toString());
    }
}
```

