---
title: SpringBoot注解
tags:
  - SpringBoot学习
categories: SpringBoot框架
abbrlink: 2f294b8e
date: 2021-01-11 16:12:59
---

　　在开发过程中经常用到的注解<!--more-->

# 常用注解

| 注解                         | 作用                                                         |
| ---------------------------- | :----------------------------------------------------------- |
| @Controller注解              | 用于定义控制器类，在spring项目中由控制器负责将用户发来的URL请求转发到对应的服务接口（service层），一般这个注解在类中，通常方法需要配合注解@RequestMapping。 |
| @RequestMapping注解          | @RequestMapping(“/path”)表示该控制器处理所有“/path”的UR L请求。RequestMapping是一个用来处理请求地址映射的注解，可用于类或方法上。 |
| @ResponseBody注解            | 直接写入HTTP response body中。比如异步获取json数据，加上@Responsebody后，会直接返回json数据。该注解一般会配合@RequestMapping一起使用。 |
| @Conponent注解               |                                                              |
| @ConfigurationProperties注解 | 加入前缀区分properties文件获取的值                           |
| @Autowired注解               | 注解导入。可以自动收集所有的Spring组件，包括@Configuration类。我们经常使用@ComponentScan注解搜索beans，并结合@Autowired注解导入。如果没有配置的话，Spring Boot会扫描启动类所在包下以及子包下的使用了@Service,@Repository等注解的类。 |
| @Service注解                 |                                                              |
| @Mapper注解                  | 扫描DAO接口到Spring容器                                      |
| @MapperScan注解              | 开启扫描Mapper接口的包以及子目录                             |
| @Transactional注解           | 事务管理器                                                   |
| @RestController注解          | 相当于控制层类加上@Controller+方法上加@ResponseBody ，意味着当前控制层类中所有方法返还的都是JSON对象 |
| @Bean注解                    | 主要在配置类中，相当于\<beans>\<bean id="" class="">\</beans> |
|                              |                                                              |