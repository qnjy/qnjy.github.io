---
title: RabbitMQ消息中间件
categories: 中间件
abbrlink: b05f3d3d
date: 2021-05-07 20:28:47
tags:
---

# 1 RabbitMQ介绍

## 1.1 RabbitMQ

　　MQ全称为Message Queue，即消息队列，RabbitMQ是由erlang语言开发，基于AMQP（Advanced Message Queue高级消息队列协议）协议实现的消息队列，它是一种应用程序之间的通信方法，消息队列在分布式系统开发中应用非常广泛。RabbitMQ官方地址：http://www.rabbitmq.com<!--more-->

开发中消息队列通常有如下应用场景：

1、任务异步处理。

将不需要同步处理的并且耗时长的操作由消息队列通知消息接收方进行异步处理。提高了应用程序的响应时间。

2、应用程序解耦合

MQ相当于一个中介，生产方通过MQ与消费方交互，它将应用程序进行解耦合。



市场上还有哪些消息队列？

ActiveMQ、RabbitMQ、ZeroMQ、Kafka、MetaMQ、RocketMQ、Redis



为什么使用RabbitMQ呢？

1.使用简单，功能强大

2.基于AMQP协议

3.社区活跃，文档完善

4.高并发性能好，这主要得益于erlang语言

5.Springboot默认集成RabbitMQ

## 1.2 其他相关知识

### AMQP

　　AMQP，即Advanced Message Queuing Protocol，一个提供统一消息服务的应用层标准高级消息队列协议，是应用层协议的一个开放标准，为面向消息的中间件设计。基于此协议的客户端与消息中间件可传递消息，并不受客户端/中间件不同产品，不同的开发语言等条件的限制。Erlang中的实现有RabbitMQ等。

官方网站：http://www.amqp.org

### JMS

　　Java 消息服务（Java Message Service，JMS）应用程序接口应用程序接口是一个Java平台中关于面向消息中间件（MOM）的API，用于在两个应用程序之间，或分布式系统分布式系统中发送消息，进行异步通信异步通信。Java 消息服务是一个与具体平台无关的 API，绝大多数 MOM 提供商都对 JMS 提供支持。

**总结**

　　JMS是java提供的一套消息服务API标准，其目的是为所有的java应用程序提供统一的消息通信的标准，类似java的jdbc，只要遵循jms标准的应用程序之间都可以进行消息通信。它和AMQP有什么不同？jms是java语言专属的消息服务标准，它是在api层定义标准，并且只能用于java应用；而AMQP是在协议层定义的标准，是跨语言的。

# 2 快速入门

## 2.1 RabbitMQ工作原理

RabbitMQ的基本结构

![image-20210507205402014](https://cdn.jsdelivr.net/gh/qnjy/images/data/1620392042-image-20210507205402014.png)

组成部分说明：

* Broker：消息队列服务进程，此进程包括两个部分：Exchange和Queue。

  * Exchange：消息队列交换机，按一定的规则将消息路由转发到某个队列，对消息进行过滤。

  * Queue：消息队列，存储消息的队列，消息到达队列并转发给指定的消费方。

* Producer：消息生产者，即生产方客户端，生产方客户端将消费发送到MQ。

* Consumer：消息消费者，即消费方客户端，接受MQ转发的消息。

消息发布接收流程：

-------发送消息--------

1、生产者和Broker建立TCP连接。

2、生产者和Broker建立通道。

3、生产者通过通道消息发送Broker，由Exchange将消息进行转发。

-------接收消息--------

1、消费者和Broker建立TCP连接

2、消费者和Broker建立通道

3、消费者监听指定的Queue (队列)

4、当有消息到达Queue时Broker默认将消息推送给消费者。

5、消费者接收到消息。

## 2.2 下载安装

### 2.2.1 Windows下安装

参考安装步骤：https://blog.csdn.net/qq_47588845/article/details/107986373

### 2.2.2 Docker下安装

1.下载镜像

```dockerfile
docker pull rabbitmq:management
```

2.创建容器

```
docker run -d  -e RABBITMQ_DEFAULT_USER=admin -e RABBITMQ_DEFAULT_PASS=admin -p 15672:15672 -p 5672:5672 -p 25672:25672 -p 61613:61613 -p 1883:1883 --name rabbitmq　rabbitmq:management
```

说明：

**RABBITMQ_DEFAULT_USER=admin -e RABBITMQ_DEFAULT_PASS=admin：**指的是web管理平台的用户名和密码

**-p 15672:15672：**是控制平台docker映射到系统的对应端口

**-p 5672:5672：**是应用程序的访问端口

3.进入web管理界面

```
192.168.200.133:15672
```

刚刚设置的是admin，根据提示输入即可。如果不设置默认为guest

### 2.2.3 RabbitMQ端口解释

```
-   4369 (epmd), 25672 (Erlang distribution)
-   5672, 5671 (AMQP 0-9-1 without and with TLS)
-   15672 (if management plugin is enabled)
-   61613, 61614 (if STOMP is enabled)
-   1883, 8883 (if MQTT is enabled)
```

**4369 (epmd), 25672 (Erlang distribution)**

　　Epmd 是 Erlang Port Mapper Daemon 的缩写，在 Erlang 集群中相当于 dns 的作用，绑定在4369端口上。

**5672, 5671 (AMQP 0-9-1 without and with TLS)**

　　AMQP 是 Advanced Message Queuing Protocol 的缩写，一个提供统一消息服务的应用层标准高级消息队列协议，是应用层协议的一个开放标准，专为面向消息的中间件设计。基于此协议的客户端与消息中间件之间可以传递消息，并不受客户端/中间件不同产品、不同的开发语言等条件的限制。Erlang 中的实现有 RabbitMQ 等。

**15672 (if management plugin is enabled)**

　　通过 http://serverip:15672 访问 RabbitMQ 的 Web 管理界面，默认用户名密码都是 guest。（注意：RabbitMQ 3.0之前的版本默认端口是55672，下同）

**61613, 61614 (if STOMP is enabled)**

　　Stomp 是一个简单的消息文本协议，它的设计核心理念就是简单与可用性，官方文档，实践一下 Stomp 协议需要：

　　　　　1.一个支持 stomp 消息协议的 messaging server (譬如activemq，rabbitmq）；

　　　　　2.一个终端（譬如linux shell);

　　　　　3.一些基本命令与操作（譬如nc，telnet)

**1883, 8883 (if MQTT is enabled)**

　　MQTT 只是 IBM 推出的一个消息协议，基于 TCP/IP 的。两个 App 端发送和接收消息需要中间人，这个中间人就是消息服务器（比如ActiveMQ/RabbitMQ），三者通信协议就是 MQTT

可以通过配置RabbitMQ来使用其它端口。

**默认用户访问**

　　协商器创造了一个密码为guest的用户guest。未配置的客户端一般都会这些凭证。当访问localhost的时候这些凭证都会默认被使用，所以当从其它机器连接过来前你需要做点变动。访问控制文档里介绍了增加用户、删除用户、允许用户的远程访问等操作。

## 2.3 RabbitMQ角色分类



## 2.3 Springboot集成rabbitMQ

按照官方教程（http://www.rabbitmq.com/getstarted.html）测试helloworld

**1.添加依赖**

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-amqp</artifactId>
</dependency>

<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-web</artifactId>
</dependency>
```

**2.配置application.yml**

```yml
spring.rabbitmq.host=192.168.200.133
spring.rabbitmq.port=5672
spring.rabbitmq.username=admin
spring.rabbitmq.password=admin
```



