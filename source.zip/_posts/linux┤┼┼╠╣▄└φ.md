---
title: linux磁盘管理
tags:
  - Linux
categories: linux学习
abbrlink: af2754a4
date: 2020-11-10 08:19:30
---

　　一些linux对磁盘管理的基本命令<!--more-->

# 命令df和du

## 1.命令df

df查看已挂载磁盘的总容量、使用容量、剩余容量等，可以不加任何参数，默认是k单位显示。

![BqP9qH.jpg](https://s1.ax1x.com/2020/11/10/BqP9qH.jpg)

其中/、/boot是我们在安装系统时划分出来了。/dev、/dev/shm为内存分区，默认大小为内存大小的1/2，如果把文件存到这个分区，相当于存到了内存中，好处是读写非常快，坏处是系统重启文件就会丢失。/run、/sys/fs/cgroup等分区都是tmpfs，跟/dev/shm类似，为临时文件系统。

df常用的参数有-i -h -k -m等

-i 使用inodes显示结果

-h 使用合适的单位显示

-k -m分别是以k，m为单位显示

## 2.命令du

用来查看某个目录或文件所占空间的大小，其格式为du [-abckmsh] [文件或者目录名] 常用的参数：

-a:全部文件与目录大小都列出来。如不加任何选项和参数只列出目录大小

-b:列出的值以bytes为单位输出，默认以Kbytes

-c:最后加总

-k:以KB为单位输出

-m:以MB为单位输出

-s:只列出总和

-h:系统自动调节单位，例如文件太小就以k为单位，太大就用G为单位

# 磁盘的分区和格式化

fdisk linux下的硬盘分区工具，只能划分小于2TB的分区

fdisk [-l] [设备名字]

-l：后面不跟设备名会直接列出系统中所有的磁盘设备及分区表，加上设备名会列出该设备的分区表。

<img src="https://s1.ax1x.com/2020/11/10/BqPPZd.jpg" alt="BqPPZd.jpg" style="zoom:67%;" />

如果不加-l就会进入另一个模式，在该模式下，可以对磁盘进行分区操作。

刚进入该模式下，会有一个提示Command (m for help): 此时按m则会打印出帮助列表，如果你英文好，我想你不难理解这些字母的功能。笔者常用的有p, n,d, w, q.

<img src="https://s1.ax1x.com/2020/11/10/BqPpse.jpg" alt="BqPpse.jpg" style="zoom:67%;" />

P：打印当前磁盘的分区情况。

n：重新建立一个新的分区。

w：保存操作。

q：退出。

d：删除一个分区

# 格式化磁盘分区

## 1.命令mke2fs、mkfs.ext2、mkfs.ext3、mkfs.ext4和mkfs.xfs

前四个命令是一样的，以mkfs举例

mkfs [-t 文件系统格式] 装置文件名

-t可以接文件系统格式，例如ext3，ext2，vfat等（系统支持才会生效）