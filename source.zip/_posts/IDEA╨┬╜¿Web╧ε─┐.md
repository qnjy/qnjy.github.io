---
title: IDEA新建Web项目
tags:
  - 创建项目
abbrlink: f1926f41
date: 2020-12-11 09:56:22
---

　　这个是创建普通javaweb项目的步骤，建议使用maven创建，导包不用这么麻烦{%post_link Maven环境变量配置%}<!--more-->

# 1.创建web project

File->new Project

<img src="https://s3.ax1x.com/2020/12/13/reKhjJ.md.jpg" alt="reKhjJ.md.jpg" style="zoom:50%;" />

<img src="https://s3.ax1x.com/2020/12/13/reKW3F.jpg" alt="reKW3F.jpg" style="zoom:50%;" />

之后，在web/WEB-INF文件夹下面创建两个文件夹：classes和lib

lib存放第三方jar包，classes存放编译后输出的class文件

创建好的目录如下

![reKghT.jpg](https://s3.ax1x.com/2020/12/13/reKghT.jpg)

# 2.接下来需要配置文件夹路径

File->Project Structure->选择Module：

在Paths界面修改，把路径修改为刚刚创建的classes文件夹，最后点击Apply

<img src="https://s3.ax1x.com/2020/12/13/reKfc4.jpg" alt="reKfc4.jpg" style="zoom:50%;" />

再点击Dependencies->将Module SDK选择为自己的JDK->点击右边+号->选择Jars or Directories

<img src="https://s3.ax1x.com/2020/12/13/reK5u9.jpg" alt="reK5u9.jpg" style="zoom:50%;" />

------------------>

<img src="https://s3.ax1x.com/2020/12/13/reKIBR.jpg" alt="reKIBR.jpg" style="zoom:50%;" />

------------------>

![reKoH1.jpg](https://s3.ax1x.com/2020/12/13/reKoH1.jpg)

然后就OK了

# 3.配置Tomcat容器

(1) 打开菜单Run->选择Edit Configuration，也可以点击上方的Edit Configuration

<img src="https://s3.ax1x.com/2020/12/13/reK7Ax.jpg" alt="reK7Ax.jpg" style="zoom:50%;" />

(2) 点击+号->Tomcat Server->Local

<img src="https://s3.ax1x.com/2020/12/13/reKHN6.jpg" alt="reKHN6.jpg" style="zoom:50%;" />

(3) 在”Name“处创建Tomcat名字，点击”Application server“后面的”Configure“，选择本地安装的Tomcat路径->OK

<img src="https://s3.ax1x.com/2020/12/13/reKb4K.jpg" alt="reKb4K.jpg" style="zoom:50%;" />

(4) 至此，Tomcat部署完成

下一步在Tomcat中部署并运行项目

Run -> Edit Configurations，进入"Run/Debug Configurations"窗口 -> 选择刚刚建立的Tomcat容器 -> 选择Deployment -> 点击右边的“+”号 -> 选择Artifact-->选择web项目-->Application contex填一个名字-->ok.

<img src="https://s3.ax1x.com/2020/12/13/reKL9O.jpg" alt="reKL9O.jpg" style="zoom:50%;" />

(5) 编辑Index.jsp文件

<img src="https://s3.ax1x.com/2020/12/13/reKXge.jpg" alt="reKXge.jpg" style="zoom:50%;" />

(6) 访问Tomcat项目

<img src="https://s3.ax1x.com/2020/12/13/reKO3D.jpg" alt="reKO3D.jpg" style="zoom:50%;" />

# 4.Web项目结构