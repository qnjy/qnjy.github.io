---
title: Maven环境变量配置
tags:
  - Maven
  - 环境配置
  - 创建项目
categories: 环境配置
abbrlink: 4bd31b3a
date: 2020-11-19 18:18:57
---

　　maven的仓库镜像配置的本地仓库配置<!--more-->

# 下载

maven下载地址：http://maven.apache.org/download.cgi

![img](https://www.runoob.com/wp-content/uploads/2018/09/750D721E-0624-4C16-AD4B-9EA5D7F6289A.png)

# 配置

## 1.首先查看java安装

打开dos命令窗口输入java -version，如果没有配置，见{% post_link java环境变量配置 %}

![DKtiY6.jpg](https://s3.ax1x.com/2020/11/19/DKtiY6.jpg)

## 2.设置Maven环境变量

右键 "计算机"，选择 "属性"，之后点击 "高级系统设置"，点击"环境变量"，来设置环境变量，有以下系统变量需要配置：

1.新建系统变量 **MAVEN_HOME**，变量值：maven安装路径

以下是我的安装路径

![DK8GZt.jpg](https://s3.ax1x.com/2020/11/19/DK8GZt.jpg)

2.编辑系统变量 **Path**，添加变量值：;%MAVEN_HOME%\bin

![DK83qI.jpg](https://s3.ax1x.com/2020/11/19/DK83qI.jpg)

## 3.检测是否配置成功

在控制台输入如下命令，如果能看到 Maven 相关版本信息，则说明 Maven 已经安装成功：

mvn -v

![DK8JdP.jpg](https://s3.ax1x.com/2020/11/19/DK8JdP.jpg)

## 4.maven镜像

找到maven文件下的conf文件夹，打开用记事本setting.xml

找到

```xml
<settings xmlns="http://maven.apache.org/SETTINGS/1.0.0"
          xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
          xsi:schemaLocation="http://maven.apache.org/SETTINGS/1.0.0 http://maven.apache.org/xsd/settings-1.0.0.xsd">
```

在下面添加

```xml
<localRepository>自己建的仓库路径</localRepository>
```

<font color="FF0000">D:\JavaTools\Maven\Mavenrespository是我的路径</font>

![D71VEQ.jpg](https://s3.ax1x.com/2020/12/03/D71VEQ.jpg)

由于maven搜索下载全球的global仓库是在外国搭建，不稳定，所以更换镜像，使maven的加载速度提高。

```xml
<mirror>
    <id>alimaven</id>
    <name>aliyun maven</name>
    <url>http://maven.aliyun.com/nexus/content/groups/public/</url>
    <mirrorOf>central</mirrorOf>
</mirror>
```

找到下图所示的位置，将以上代码插入在红色方框中间

![DMGTsJ.jpg](https://s3.ax1x.com/2020/11/20/DMGTsJ.jpg)

## 5.idea中配置maven

打开file-Setting

<img src="https://s3.ax1x.com/2020/11/24/DtCY4g.jpg" alt="DtCY4g.jpg" style="zoom: 67%;" />

# 创建maven web项目（可忽略）

打开File-New-Project，<font color="ff0000">注意有两个webapp选项不要选错</font>

点击NEXT

<img src="https://s3.ax1x.com/2020/11/24/DtCJUS.jpg" alt="DtCJUS.jpg" style="zoom:67%;" />

点击NEXT，GroupId一般填写域名（com），ArtifactId一般填写姓名简拼

![DtCMjI.jpg](https://s3.ax1x.com/2020/11/24/DtCMjI.jpg)

添加的配置为archetypeCatalog=internal

点击NEXT

<img src="https://s3.ax1x.com/2020/11/24/DtCGE8.jpg" alt="DtCGE8.jpg" style="zoom:67%;" />

点击NEXT

<img src="https://s3.ax1x.com/2020/11/24/DtClut.jpg" alt="DtClut.jpg" style="zoom:67%;" />

点击Finish后项目开始创建在右下角查看进度

![DtC3Hf.jpg](https://s3.ax1x.com/2020/11/24/DtC3Hf.jpg)

# maven web模板项目结构介绍

![DtC1DP.jpg](https://s3.ax1x.com/2020/11/24/DtC1DP.jpg)

![DtC0uq.jpg](https://s3.ax1x.com/2020/11/24/DtC0uq.jpg)

![DtCdvn.jpg](https://s3.ax1x.com/2020/11/24/DtCdvn.jpg)

同样在main下新建test测试文件夹，再在此文件下下新建java测试源码文件夹和resource测试资源文件加夹。

![DtCNCQ.jpg](https://s3.ax1x.com/2020/11/24/DtCNCQ.jpg)

也可以右键项目-选择Open Module Settings打开项目配置页面更改

<img src="https://s3.ax1x.com/2020/11/24/DtCU3j.jpg" alt="DtCU3j.jpg" style="zoom:67%;" />

配置依赖jar包

<img src="https://s3.ax1x.com/2020/11/24/DtCags.jpg" alt="DtCags.jpg" style="zoom:67%;" />

以后需要什么jar包就可以直接导入依赖，如果不知道版本，在[点击这里](https://mvnrepository.com/)搜索需要的Jar包，以下是导入步骤

<img src="https://s3.ax1x.com/2020/12/13/reQNQg.jpg" alt="reQNQg.jpg" style="zoom:67%;" />

<img src="https://s3.ax1x.com/2020/12/13/reQtSS.jpg" alt="reQtSS.jpg" style="zoom:67%;" />

<img src="https://s3.ax1x.com/2020/12/13/reQJW8.jpg" alt="reQJW8.jpg" style="zoom:67%;" />

![reQUyQ.jpg](https://s3.ax1x.com/2020/12/13/reQUyQ.jpg)