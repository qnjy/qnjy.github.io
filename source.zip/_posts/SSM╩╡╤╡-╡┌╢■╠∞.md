---
title: SSM实训-第二天
abbrlink: 7006e19d
date: 2022-06-22 09:49:08
tags:
categories:
---

# 任务

1 SpringMVC框架引入项目，学习使用

2 维修模块和收费模块完成

------

mybatis-->持久层（数据模型层）M			优化与数据库的交互

SpringMVC—>控制层C							优化【请求--响应】操作



之前的控制层使用Servlet实现，有很多繁琐的地方

SpringMVC解决<font color='red'>**路径映射、请求接受、数据响应**</font>

<!--more-->

# 1 基础使用SpringMVC

1 导入jar（目前还没有采用maven，需要手动导入jar包）

2 配置文件spring-mvc.xml

```xml
<?xml version="1.0" encoding="UTF-8"?>
<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xmlns:mvc="http://www.springframework.org/schema/mvc"
       xmlns:context="http://www.springframework.org/schema/context"
       xsi:schemaLocation="http://www.springframework.org/schema/beans
                           http://www.springframework.org/schema/beans/spring-beans.xsd
                           http://www.springframework.org/schema/context
                           http://www.springframework.org/schema/context/spring-context.xsd
                           http://www.springframework.org/schema/mvc
                           http://www.springframework.org/schema/mvc/spring-mvc-3.0.xsd">

    <!-- 静态资源配置 -->
    <mvc:resources mapping="/admin/**" location="/admin/" />
    <mvc:resources mapping="/resources/**" location="/resources/" />

    <!-- 支持注解 -->
    <mvc:annotation-driven/>

    <!-- 扫描控制器 -->
    <context:component-scan base-package="com.xja.controller" />

    <!-- 支持 Post中的文件格式 Content-Type: multipart/form-data; -->
    <bean id="multipartResolver" class="org.springframework.web.multipart.commons.CommonsMultipartResolver" />
</beans>
```

web.xml

```xml
<?xml version="1.0" encoding="UTF-8"?>
<web-app xmlns="http://xmlns.jcp.org/xml/ns/javaee"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://xmlns.jcp.org/xml/ns/javaee http://xmlns.jcp.org/xml/ns/javaee/web-app_4_0.xsd"
         version="4.0">

    <!--    通过web服务器启动Spring容器-->
    <context-param>
        <param-name>contextConfigLocation</param-name>
        <param-value>classpath:spring-config.xml</param-value>
    </context-param>

    <listener>
        <listener-class>org.springframework.web.context.ContextLoaderListener</listener-class>
    </listener>

    <!-- springmvc配置 -->
    <servlet>
        <servlet-name>app</servlet-name>
        <servlet-class>org.springframework.web.servlet.DispatcherServlet</servlet-class>

        <init-param>
            <param-name>contextConfigLocation</param-name>
            <param-value>classpath:spring-mvc.xml</param-value>
        </init-param>
        <load-on-startup>1</load-on-startup>
    </servlet>

    <!--    dispatcherservlet 匹配所有请求-->
    <servlet-mapping>
        <servlet-name>app</servlet-name>
        <url-pattern>/</url-pattern>
    </servlet-mapping>

    <filter>
        <filter-name>CharacterEncodingFilter</filter-name>
        <filter-class>org.springframework.web.filter.CharacterEncodingFilter</filter-class>
        <init-param>
            <param-name>encoding</param-name>
            <param-value>utf-8</param-value>
        </init-param>
    </filter>

    <filter-mapping>
        <filter-name>CharacterEncodingFilter</filter-name>
        <url-pattern>/*</url-pattern>
    </filter-mapping>

</web-app>
```

------

# 2 维修申请编写：

**1 数据库repaireinfo**

```mysql
CREATE TABLE `repairinfo` (
    `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键自增',
    `repaircode` varchar(255) DEFAULT NULL COMMENT '维修单编号自定义规则：wxd+userid+时间戳',
    `content` varchar(255) DEFAULT NULL COMMENT '维修内容',
    `userid` int(11) DEFAULT NULL COMMENT '提交用户',
    `createdtime` varchar(255) DEFAULT NULL COMMENT '提交时间',
    `repairstatus` int(11) DEFAULT NULL COMMENT '维修状态 0未受理 1维修中 2维修完毕',
    `message` varchar(255) DEFAULT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4;
```

**2 功能设计** 

列表展示：

编号 维修单号 申请人 手机号 房间号 维修内容 申请时间 处理状态 操作

多条件查询：

维修单号 开始时间 结束时间 处理状态等

新增（待考虑添加，结合业务功能分析目前不需要）

删除（待考虑添加，目前不需要）

编辑功能

**3 模仿其他模块完成**

实现过程的总结：

1、mybatis的对象嵌套映射：resultmap+association

2、需要注意repairinfo和user表中select顺序-->决定createdtime字段是否填充正确

3、新增维修时、由int类型引起的外键约束失败--->改为Integer，默认值为null

4、在后台管理新增的维修，列表中无法显示-->将多表联查内连接改为外连接

# 3 维修处理编写

1 数据表设计

```mysql
CREATE TABLE `dorepair` (
    `dorepairid` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键自增',
    `repaircode` varchar(255) DEFAULT NULL COMMENT '维修申请单号',
    `staffid` int(11) DEFAULT NULL COMMENT '维修员编号',
    `dostatus` int(11) DEFAULT NULL COMMENT '维修状态1维修中 2维修结束',
    `doresult` varchar(255) DEFAULT NULL COMMENT '维修结果',
    `stars` int(11) DEFAULT NULL COMMENT '用户评分1 2 3 4 5',
    `checktime` varchar(255) DEFAULT NULL COMMENT '确认时间',
    `overtime` varchar(255) DEFAULT NULL COMMENT '完结时间',
    PRIMARY KEY (`dorepairid`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4;
```

2 向表中添加数据时候，需要注意与staff表的关联

3 功能要求

数据列表展示：

编号、维修单号、维修内容、维修员编号、维修员名字、维修状态、维修结果、确认时间、完结时间、用户评分、操作

**难点：（多表联查）**

​		resultmap+association完成映射

多条件查询:
维修单号、维修员姓名（模糊）、维修状态等

根据业务功能分析：不需要新增、删除、修改

# 4 知识点

mysql的内连接与外连接
